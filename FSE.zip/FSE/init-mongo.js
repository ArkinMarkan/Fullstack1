// MongoDB initialization script
db = db.getSiblingDB('moviebookingdb');

db.createUser({
  user: 'moviebookinguser',
  pwd: 'moviebookingpass',
  roles: [
    {
      role: 'readWrite',
      db: 'moviebookingdb'
    }
  ]
});

// Create indexes for better performance
db.users.createIndex({ "loginId": 1 }, { unique: true });
db.users.createIndex({ "email": 1 }, { unique: true });
db.movies.createIndex({ "movieName": 1, "theatreName": 1 }, { unique: true });
db.movies.createIndex({ "movieName": 1 });
db.movies.createIndex({ "theatreName": 1 });
db.movies.createIndex({ "status": 1 });
db.tickets.createIndex({ "userId": 1 });
db.tickets.createIndex({ "userLoginId": 1 });
db.tickets.createIndex({ "movieName": 1, "theatreName": 1 });
db.tickets.createIndex({ "bookingReference": 1 }, { unique: true });

print('Database initialization completed');
