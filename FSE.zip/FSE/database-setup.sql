# Movie Booking App - Database Setup SQL Script

# Run this script after installing MySQL
# Execute: mysql -u root -p < database-setup.sql

# Create database
CREATE DATABASE IF NOT EXISTS moviebookingdb
  CHARACTER SET utf8mb4 
  COLLATE utf8mb4_unicode_ci;

# Create application user
CREATE USER IF NOT EXISTS 'movieapp'@'localhost' IDENTIFIED BY 'movieapp123';

# Grant privileges
GRANT ALL PRIVILEGES ON moviebookingdb.* TO 'movieapp'@'localhost';

# Apply privileges
FLUSH PRIVILEGES;

# Use the database
USE moviebookingdb;

# Show confirmation
SELECT 'Database moviebookingdb created successfully' as Status;
SELECT 'User movieapp created with all privileges' as Status;
