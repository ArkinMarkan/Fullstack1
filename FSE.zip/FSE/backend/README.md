# Movie Booking Application - Backend

A comprehensive full-stack Movie Booking Application built with Spring Boot, MySQL, and React, featuring JWT authentication, role-based access control, and modern development practices.

## 🏗️ **Architecture Overview**

- **Backend**: Spring Boot 3.x with Java 17+
- **Database**: MySQL 8.0 with JPA/Hibernate
- **Caching**: Redis for session management and application caching
- **Security**: JWT-based authentication with role-based authorization
- **Documentation**: OpenAPI 3.0 (Swagger)
- **Testing**: JUnit 5 with Mockito
- **Build**: Maven 3.x
- **Containerization**: Docker & Docker Compose

## 📋 **Features Implemented**

### User Stories Completed:
- ✅ **US_01**: User Registration and Login with validation
- ✅ **US_02**: View & Search Movies functionality  
- ✅ **US_03**: Book Tickets for movies with seat selection
- ✅ **US_04**: Admin ticket management and status updates

### Technical Features:
- ✅ Composite primary key for Movie entity (movie_name, theatre_name)
- ✅ Role-based authentication (USER, ADMIN)
- ✅ JWT token-based security
- ✅ Redis caching and session management
- ✅ Rate limiting with Bucket4j
- ✅ Global exception handling
- ✅ Database migration with Liquibase
- ✅ Comprehensive validation
- ✅ Audit trail with JPA auditing
- ✅ Performance optimization with indexes and stored procedures

## 🚀 **Quick Start**

### Prerequisites
- Java 17+
- Maven 3.6+
- MySQL 8.0
- Redis 6.0+
- Docker (optional)

### Option 1: Local Development Setup

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd movie-booking-app/backend
   ```

2. **Setup MySQL Database**
   ```sql
   CREATE DATABASE moviebookingdb;
   CREATE USER 'movieapp'@'localhost' IDENTIFIED BY 'movieapp123';
   GRANT ALL PRIVILEGES ON moviebookingdb.* TO 'movieapp'@'localhost';
   FLUSH PRIVILEGES;
   ```

3. **Install Redis**
   ```bash
   # On Ubuntu/Debian
   sudo apt update
   sudo apt install redis-server
   sudo systemctl start redis-server
   
   # On macOS
   brew install redis
   brew services start redis
   
   # On Windows
   # Download and install from https://github.com/microsoftarchive/redis/releases
   ```

4. **Build and Run**
   ```bash
   mvn clean install
   mvn spring-boot:run
   ```

### Option 2: Docker Deployment

1. **Using Docker Compose** (Recommended)
   ```bash
   # From the project root directory
   docker-compose up -d
   ```

2. **Manual Docker Build**
   ```bash
   # Build the backend image
   cd backend
   docker build -t movie-booking-backend .
   
   # Run with external MySQL and Redis
   docker run -p 8080:8080 \
     -e SPRING_DATASOURCE_URL=jdbc:mysql://host.docker.internal:3306/moviebookingdb \
     -e SPRING_REDIS_HOST=host.docker.internal \
     movie-booking-backend
   ```

## 🔧 **Configuration Profiles**

The application supports multiple profiles:

- **mysql** (default): Local MySQL development
- **docker**: Docker deployment with service discovery
- **test**: H2 in-memory database for testing

## 📊 **API Endpoints**

### Authentication
- `POST /api/v1.0/moviebooking/register` - User registration
- `GET /api/v1.0/moviebooking/login` - User login
- `GET /api/v1.0/moviebooking/{username}/forgot` - Password reset

### Movies
- `GET /api/v1.0/moviebooking/all` - View all movies
- `GET /api/v1.0/moviebooking/movies/search/{moviename}` - Search movies
- `PUT /api/v1.0/moviebooking/{moviename}/update/{status}` - Update ticket status (Admin)
- `DELETE /api/v1.0/moviebooking/{moviename}/delete/{id}` - Delete movie (Admin)

### Tickets
- `POST /api/v1.0/moviebooking/{moviename}/add` - Book tickets
- `GET /api/v1.0/moviebooking/tickets/{username}` - View user tickets

## 🧪 **Testing**

### Run Unit Tests
```bash
mvn test
```

### Run Integration Tests
```bash
mvn verify
```

### Generate Test Reports
```bash
mvn surefire-report:report
# Reports available at: target/site/surefire-report.html
```

### Code Coverage
```bash
mvn jacoco:report
# Coverage report at: target/site/jacoco/index.html
```

## 📈 **Performance Features**

### Caching Strategy
- **Redis**: Session management and application-level caching
- **JPA Second Level Cache**: Entity caching
- **Query Result Caching**: Frequently accessed data

### Database Optimization
- **Composite Indexes**: Optimized for search patterns
- **Connection Pooling**: HikariCP for efficient connection management
- **Stored Procedures**: Complex business logic optimization
- **Database Triggers**: Automatic audit trail

### Rate Limiting
- **Bucket4j**: Token bucket algorithm for API rate limiting
- **Configurable limits**: 100 requests per minute (default)

## 🔒 **Security Features**

### Authentication & Authorization
- **JWT Tokens**: Stateless authentication
- **Role-based Access**: USER and ADMIN roles
- **Password Encryption**: BCrypt with strength 10
- **Session Management**: Redis-backed sessions

### Security Headers
- **CORS Configuration**: Configurable allowed origins
- **CSRF Protection**: Enabled for state-changing operations
- **Security Headers**: Standard security headers applied

## 🏗️ **Architecture Patterns**

### Design Patterns Used
- **Repository Pattern**: Data access abstraction
- **Service Layer Pattern**: Business logic encapsulation
- **DTO Pattern**: Data transfer object pattern
- **Builder Pattern**: Complex object construction
- **Strategy Pattern**: Multiple authentication strategies

### Dependency Injection
- **Constructor Injection**: MovieService (recommended)
- **Setter Injection**: TicketService (for demonstration)
- **Field Injection**: Configurations and utilities

## 📝 **Database Schema**

### Core Tables
- **movies**: Movie information with composite key
- **users**: User accounts and profiles  
- **tickets**: Ticket bookings and seat information
- **movie_show_times**: Show time schedules (collection table)

### Sample Data
The application initializes with:
- 2 sample movies: "Avengers Endgame" and "RRR"
- 2 theatres: "PVR Cinemas" and "INOX Multiplex"
- Admin user: `admin` / `admin123`
- Test user: `john_doe` / `password123`

## 🔍 **Monitoring & Observability**

### Health Checks
- **Application Health**: `/actuator/health`
- **Database Connectivity**: Automatic health indicators
- **Redis Connectivity**: Connection validation

### Metrics
- **Prometheus Metrics**: `/actuator/prometheus`
- **JVM Metrics**: Memory, threads, GC statistics
- **Application Metrics**: Custom business metrics

### Logging
- **Structured Logging**: JSON format for production
- **Log Levels**: Configurable per package
- **Audit Logs**: User actions and data changes

## 🚀 **Deployment**

### Production Checklist
- [ ] Configure production database credentials
- [ ] Set up Redis cluster for high availability
- [ ] Configure SSL/TLS certificates
- [ ] Set up monitoring and alerting
- [ ] Configure backup strategies
- [ ] Set up CI/CD pipeline
- [ ] Configure load balancer
- [ ] Set up log aggregation

### Environment Variables
```bash
SPRING_PROFILES_ACTIVE=mysql
SPRING_DATASOURCE_URL=jdbc:mysql://localhost:3306/moviebookingdb
SPRING_DATASOURCE_USERNAME=movieapp
SPRING_DATASOURCE_PASSWORD=movieapp123
SPRING_REDIS_HOST=localhost
SPRING_REDIS_PORT=6379
APP_JWT_SECRET=your-secret-key
```

## 🤝 **Development Guidelines**

### Code Quality
- **Checkstyle**: Code style enforcement
- **SpotBugs**: Static analysis for bug detection
- **JaCoCo**: Code coverage > 80%
- **SonarQube**: Code quality gates

### Best Practices
- **RESTful API Design**: Following REST principles
- **Exception Handling**: Centralized error handling
- **Validation**: Bean Validation (JSR-303)
- **Documentation**: OpenAPI/Swagger integration
- **Testing**: Unit and integration tests

## 📚 **Additional Resources**

- **API Documentation**: http://localhost:8080/swagger-ui.html
- **Actuator Endpoints**: http://localhost:8080/actuator
- **Health Check**: http://localhost:8080/actuator/health
- **Metrics**: http://localhost:8080/actuator/metrics

## 🐛 **Troubleshooting**

### Common Issues

1. **Database Connection Failed**
   - Verify MySQL is running: `sudo systemctl status mysql`
   - Check credentials in `application-mysql.properties`
   - Ensure database exists: `SHOW DATABASES;`

2. **Redis Connection Failed**
   - Verify Redis is running: `redis-cli ping`
   - Check Redis host/port configuration
   - Ensure Redis is accepting connections

3. **JWT Token Issues**
   - Verify JWT secret configuration
   - Check token expiration settings
   - Ensure proper Authorization header format

4. **Rate Limiting Issues**
   - Check rate limit configuration
   - Verify Bucket4j dependency
   - Review rate limiting logs

### Performance Tuning
- **JVM Settings**: `-Xms512m -Xmx1024m -XX:+UseG1GC`
- **Database Tuning**: Connection pool sizing
- **Redis Memory**: Adjust memory policies
- **Cache TTL**: Fine-tune cache expiration

---

**Version**: 1.0.0  
**Last Updated**: December 2025  
**Maintainer**: Movie Booking App Team
