package com.moviebookingapp.service;

import com.moviebookingapp.dto.UserRegistrationDto;
import com.moviebookingapp.dto.LoginRequestDto;
import com.moviebookingapp.dto.JwtResponseDto;
import com.moviebookingapp.exception.DuplicateResourceException;
import com.moviebookingapp.exception.UserNotFoundException;
import com.moviebookingapp.exception.ValidationException;
import com.moviebookingapp.model.User;
import com.moviebookingapp.repository.UserRepository;
import com.moviebookingapp.util.JwtUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

/**
 * Unit tests for UserService
 */
@ExtendWith(MockitoExtension.class)
class UserServiceTest {
    
    @Mock
    private UserRepository userRepository;
    
    @Mock
    private PasswordEncoder passwordEncoder;
    
    @Mock
    private AuthenticationManager authenticationManager;
    
    @Mock
    private JwtUtil jwtUtil;
    
    @InjectMocks
    private UserService userService;
    
    private UserRegistrationDto validRegistrationDto;
    private User validUser;
    
    @BeforeEach
    void setUp() {
        validRegistrationDto = new UserRegistrationDto();
        validRegistrationDto.setFirstName("John");
        validRegistrationDto.setLastName("Doe");
        validRegistrationDto.setEmail("john.doe@example.com");
        validRegistrationDto.setLoginId("john_doe");
        validRegistrationDto.setPassword("password123");
        validRegistrationDto.setConfirmPassword("password123");
        validRegistrationDto.setContactNumber("9876543210");
        
        validUser = new User();
        validUser.setId(123L);
        validUser.setFirstName("John");
        validUser.setLastName("Doe");
        validUser.setEmail("john.doe@example.com");
        validUser.setLoginId("john_doe");
        validUser.setPassword("encodedPassword");
        validUser.setContactNumber("9876543210");
        validUser.setRole(User.Role.USER);
    }
    
    @Test
    void registerUser_WithValidData_ShouldReturnUser() {
        // Arrange
        when(userRepository.existsByLoginId(anyString())).thenReturn(false);
        when(userRepository.existsByEmail(anyString())).thenReturn(false);
        when(passwordEncoder.encode(anyString())).thenReturn("encodedPassword");
        when(userRepository.save(any(User.class))).thenReturn(validUser);
        
        // Act
        User result = userService.registerUser(validRegistrationDto);
        
        // Assert
        assertNotNull(result);
        assertEquals(validUser.getLoginId(), result.getLoginId());
        assertEquals(validUser.getEmail(), result.getEmail());
        
        verify(userRepository).existsByLoginId(validRegistrationDto.getLoginId());
        verify(userRepository).existsByEmail(validRegistrationDto.getEmail());
        verify(passwordEncoder).encode(validRegistrationDto.getPassword());
        verify(userRepository).save(any(User.class));
    }
    
    @Test
    void registerUser_WithMismatchedPasswords_ShouldThrowValidationException() {
        // Arrange
        validRegistrationDto.setConfirmPassword("differentPassword");
        
        // Act & Assert
        assertThrows(ValidationException.class, () -> {
            userService.registerUser(validRegistrationDto);
        });
        
        verify(userRepository, never()).save(any(User.class));
    }
    
    @Test
    void registerUser_WithExistingLoginId_ShouldThrowDuplicateResourceException() {
        // Arrange
        when(userRepository.existsByLoginId(anyString())).thenReturn(true);
        
        // Act & Assert
        assertThrows(DuplicateResourceException.class, () -> {
            userService.registerUser(validRegistrationDto);
        });
        
        verify(userRepository, never()).save(any(User.class));
    }
    
    @Test
    void registerUser_WithExistingEmail_ShouldThrowDuplicateResourceException() {
        // Arrange
        when(userRepository.existsByLoginId(anyString())).thenReturn(false);
        when(userRepository.existsByEmail(anyString())).thenReturn(true);
        
        // Act & Assert
        assertThrows(DuplicateResourceException.class, () -> {
            userService.registerUser(validRegistrationDto);
        });
        
        verify(userRepository, never()).save(any(User.class));
    }
    
    @Test
    void authenticateUser_WithValidCredentials_ShouldReturnJwtResponse() {
        // Arrange
        LoginRequestDto loginRequest = new LoginRequestDto("john_doe", "password123");
        Authentication authentication = mock(Authentication.class);
        
        when(authenticationManager.authenticate(any(UsernamePasswordAuthenticationToken.class)))
                .thenReturn(authentication);
        when(authentication.getPrincipal()).thenReturn(validUser);
        when(jwtUtil.generateToken(authentication)).thenReturn("access-token");
        when(jwtUtil.generateRefreshToken(anyString())).thenReturn("refresh-token");
        
        // Act
        JwtResponseDto result = userService.authenticateUser(loginRequest);
        
        // Assert
        assertNotNull(result);
        assertEquals("access-token", result.getToken());
        assertEquals("refresh-token", result.getRefreshToken());
        assertEquals(validUser.getLoginId(), result.getLoginId());
        assertEquals(validUser.getRole().name(), result.getRole());
    }
    
    @Test
    void authenticateUser_WithInvalidCredentials_ShouldThrowAuthenticationException() {
        // Arrange
        LoginRequestDto loginRequest = new LoginRequestDto("john_doe", "wrongpassword");
        
        when(authenticationManager.authenticate(any(UsernamePasswordAuthenticationToken.class)))
                .thenThrow(new BadCredentialsException("Bad credentials"));
        
        // Act & Assert
        assertThrows(com.moviebookingapp.exception.AuthenticationException.class, () -> {
            userService.authenticateUser(loginRequest);
        });
    }
    
    @Test
    void findByLoginId_WithExistingUser_ShouldReturnUser() {
        // Arrange
        when(userRepository.findByLoginId(anyString())).thenReturn(Optional.of(validUser));
        
        // Act
        User result = userService.findByLoginId("john_doe");
        
        // Assert
        assertNotNull(result);
        assertEquals(validUser.getLoginId(), result.getLoginId());
    }
    
    @Test
    void findByLoginId_WithNonExistingUser_ShouldThrowUserNotFoundException() {
        // Arrange
        when(userRepository.findByLoginId(anyString())).thenReturn(Optional.empty());
        
        // Act & Assert
        assertThrows(UserNotFoundException.class, () -> {
            userService.findByLoginId("nonexistent");
        });
    }
    
    @Test
    void resetPassword_WithExistingUser_ShouldReturnTemporaryPassword() {
        // Arrange
        when(userRepository.findByLoginId(anyString())).thenReturn(Optional.of(validUser));
        when(passwordEncoder.encode(anyString())).thenReturn("encodedTempPassword");
        when(userRepository.save(any(User.class))).thenReturn(validUser);
        
        // Act
        String tempPassword = userService.resetPassword("john_doe");
        
        // Assert
        assertNotNull(tempPassword);
        assertEquals(8, tempPassword.length());
        
        verify(passwordEncoder).encode(anyString());
        verify(userRepository).save(validUser);
    }
    
    @Test
    void existsByLoginId_WithExistingLoginId_ShouldReturnTrue() {
        // Arrange
        when(userRepository.existsByLoginId(anyString())).thenReturn(true);
        
        // Act
        boolean exists = userService.existsByLoginId("john_doe");
        
        // Assert
        assertTrue(exists);
    }
    
    @Test
    void existsByEmail_WithExistingEmail_ShouldReturnTrue() {
        // Arrange
        when(userRepository.existsByEmail(anyString())).thenReturn(true);
        
        // Act
        boolean exists = userService.existsByEmail("john.doe@example.com");
        
        // Assert
        assertTrue(exists);
    }
}
