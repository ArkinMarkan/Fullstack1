package com.moviebookingapp.service;

import com.moviebookingapp.exception.MovieNotFoundException;
import com.moviebookingapp.exception.ValidationException;
import com.moviebookingapp.model.Movie;
import com.moviebookingapp.repository.MovieRepository;
import com.moviebookingapp.repository.TicketRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

/**
 * Unit tests for MovieService
 */
@ExtendWith(MockitoExtension.class)
class MovieServiceTest {

    @Mock
    private MovieRepository movieRepository;

    @Mock
    private TicketRepository ticketRepository;

    private MovieService movieService;

    @BeforeEach
    void setUp() {
        movieService = new MovieService(movieRepository, ticketRepository);
    }

    @Test
    void testGetAllMovies_Success() {
        // Arrange
        List<Movie> expectedMovies = Arrays.asList(
            new Movie("Avengers Endgame", "PVR Cinemas", 100),
            new Movie("RRR", "INOX Multiplex", 150)
        );
        when(movieRepository.findAll()).thenReturn(expectedMovies);

        // Act
        List<Movie> actualMovies = movieService.getAllMovies();

        // Assert
        assertEquals(expectedMovies.size(), actualMovies.size());
        assertEquals(expectedMovies, actualMovies);
        verify(movieRepository, times(1)).findAll();
    }

    @Test
    void testGetMovieByNameAndTheatre_Success() {
        // Arrange
        String movieName = "Avengers Endgame";
        String theatreName = "PVR Cinemas";
        Movie expectedMovie = new Movie(movieName, theatreName, 100);
        when(movieRepository.findByMovieNameAndTheatreName(movieName, theatreName))
            .thenReturn(Optional.of(expectedMovie));

        // Act
        Movie actualMovie = movieService.getMovieByNameAndTheatre(movieName, theatreName);

        // Assert
        assertEquals(expectedMovie, actualMovie);
        verify(movieRepository, times(1)).findByMovieNameAndTheatreName(movieName, theatreName);
    }

    @Test
    void testGetMovieByNameAndTheatre_NotFound() {
        // Arrange
        String movieName = "Non-existent Movie";
        String theatreName = "Non-existent Theatre";
        when(movieRepository.findByMovieNameAndTheatreName(movieName, theatreName))
            .thenReturn(Optional.empty());

        // Act & Assert
        assertThrows(MovieNotFoundException.class, () -> {
            movieService.getMovieByNameAndTheatre(movieName, theatreName);
        });
        verify(movieRepository, times(1)).findByMovieNameAndTheatreName(movieName, theatreName);
    }

    @Test
    void testAddMovie_Success() {
        // Arrange
        Movie newMovie = new Movie("New Movie", "New Theatre", 200);
        when(movieRepository.findByMovieNameAndTheatreName(anyString(), anyString()))
            .thenReturn(Optional.empty());
        when(movieRepository.save(any(Movie.class))).thenReturn(newMovie);

        // Act
        Movie savedMovie = movieService.addMovie(newMovie);

        // Assert
        assertEquals(newMovie, savedMovie);
        assertEquals(newMovie.getTotalTickets(), savedMovie.getAvailableTickets());
        assertEquals("BOOK_ASAP", savedMovie.getStatus());
        verify(movieRepository, times(1)).save(newMovie);
    }

    @Test
    void testAddMovie_AlreadyExists() {
        // Arrange
        Movie existingMovie = new Movie("Existing Movie", "Existing Theatre", 100);
        when(movieRepository.findByMovieNameAndTheatreName(anyString(), anyString()))
            .thenReturn(Optional.of(existingMovie));

        // Act & Assert
        assertThrows(ValidationException.class, () -> {
            movieService.addMovie(existingMovie);
        });
        verify(movieRepository, never()).save(any(Movie.class));
    }

    @Test
    void testAddMovie_InvalidData() {
        // Arrange
        Movie invalidMovie = new Movie("", "", null);

        // Act & Assert
        assertThrows(ValidationException.class, () -> {
            movieService.addMovie(invalidMovie);
        });
        verify(movieRepository, never()).save(any(Movie.class));
    }

    @Test
    void testUpdateTicketStatus_Success() {
        // Arrange
        String movieName = "Test Movie";
        String theatreName = "Test Theatre";
        String newStatus = "SOLD_OUT";
        Movie movie = new Movie(movieName, theatreName, 100);
        when(movieRepository.findByMovieNameAndTheatreName(movieName, theatreName))
            .thenReturn(Optional.of(movie));
        when(movieRepository.save(any(Movie.class))).thenReturn(movie);

        // Act
        Movie updatedMovie = movieService.updateTicketStatus(movieName, theatreName, newStatus);

        // Assert
        assertEquals(newStatus, updatedMovie.getStatus());
        verify(movieRepository, times(1)).save(movie);
    }

    @Test
    void testUpdateTicketStatus_InvalidStatus() {
        // Arrange
        String movieName = "Test Movie";
        String theatreName = "Test Theatre";
        String invalidStatus = "INVALID_STATUS";
        Movie movie = new Movie(movieName, theatreName, 100);
        when(movieRepository.findByMovieNameAndTheatreName(movieName, theatreName))
            .thenReturn(Optional.of(movie));

        // Act & Assert
        assertThrows(ValidationException.class, () -> {
            movieService.updateTicketStatus(movieName, theatreName, invalidStatus);
        });
        verify(movieRepository, never()).save(any(Movie.class));
    }

    @Test
    void testSearchMoviesByName_WithResults() {
        // Arrange
        String searchTerm = "Avengers";
        List<Movie> expectedMovies = Arrays.asList(
            new Movie("Avengers Endgame", "PVR Cinemas", 100)
        );
        when(movieRepository.findByMovieNameContainingIgnoreCase(searchTerm))
            .thenReturn(expectedMovies);

        // Act
        List<Movie> actualMovies = movieService.searchMoviesByName(searchTerm);

        // Assert
        assertEquals(expectedMovies.size(), actualMovies.size());
        assertEquals(expectedMovies, actualMovies);
        verify(movieRepository, times(1)).findByMovieNameContainingIgnoreCase(searchTerm);
    }

    @Test
    void testSearchMoviesByName_EmptySearch() {
        // Arrange
        List<Movie> allMovies = Arrays.asList(
            new Movie("Movie 1", "Theatre 1", 100),
            new Movie("Movie 2", "Theatre 2", 150)
        );
        when(movieRepository.findAll()).thenReturn(allMovies);

        // Act
        List<Movie> actualMovies = movieService.searchMoviesByName("");

        // Assert
        assertEquals(allMovies, actualMovies);
        verify(movieRepository, times(1)).findAll();
        verify(movieRepository, never()).findByMovieNameContainingIgnoreCase(anyString());
    }
}
