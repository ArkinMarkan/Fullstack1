package com.moviebookingapp.repository;

import com.moviebookingapp.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Repository interface for User entity with JPA/MySQL
 */
@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    
    /**
     * Find user by login ID
     */
    Optional<User> findByLoginId(String loginId);
    
    /**
     * Find user by email
     */
    Optional<User> findByEmail(String email);
    
    /**
     * Check if user exists by login ID
     */
    boolean existsByLoginId(String loginId);
    
    /**
     * Check if user exists by email
     */
    boolean existsByEmail(String email);
    
    /**
     * Find users by role
     */
    List<User> findByRole(User.Role role);
    
    /**
     * Find users by first name and last name (case insensitive)
     */
    @Query("SELECT u FROM User u WHERE LOWER(u.firstName) LIKE LOWER(CONCAT('%', :firstName, '%')) " +
           "AND LOWER(u.lastName) LIKE LOWER(CONCAT('%', :lastName, '%'))")
    List<User> findByFirstNameAndLastNameIgnoreCase(@Param("firstName") String firstName, 
                                                   @Param("lastName") String lastName);
    
    /**
     * Find users by contact number
     */
    Optional<User> findByContactNumber(String contactNumber);
    
    /**
     * Find enabled users
     */
    List<User> findByEnabled(boolean enabled);
    
    /**
     * Custom query to find users with specific criteria
     */
    @Query("SELECT u FROM User u WHERE " +
           "LOWER(u.loginId) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR " +
           "LOWER(u.email) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR " +
           "LOWER(u.firstName) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR " +
           "LOWER(u.lastName) LIKE LOWER(CONCAT('%', :searchTerm, '%'))")
    List<User> findBySearchTerm(@Param("searchTerm") String searchTerm);
    
    /**
     * Count users by role
     */
    @Query("SELECT COUNT(u) FROM User u WHERE u.role = :role")
    long countByRole(@Param("role") User.Role role);
    
    /**
     * Find users by registration date range
     */
    @Query("SELECT u FROM User u WHERE u.createdDate >= :startDate AND u.createdDate <= :endDate")
    List<User> findByRegistrationDateRange(@Param("startDate") java.time.LocalDateTime startDate,
                                          @Param("endDate") java.time.LocalDateTime endDate);
}
