package com.moviebookingapp.service;

import com.moviebookingapp.model.Movie;
import com.moviebookingapp.model.User;
import com.moviebookingapp.repository.MovieRepository;
import com.moviebookingapp.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

/**
 * Service to initialize sample data
 */
@Service
public class DataInitializationService implements CommandLineRunner {
    
    private static final Logger logger = LoggerFactory.getLogger(DataInitializationService.class);
    
    @Autowired
    private MovieRepository movieRepository;
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private PasswordEncoder passwordEncoder;
    
    @Override
    public void run(String... args) throws Exception {
        initializeSampleData();
    }
    
    /**
     * Initialize sample movies and users
     */
    public void initializeSampleData() {
        logger.info("Initializing sample data...");
        
        // Initialize sample movies
        initializeMovies();
        
        // Initialize admin user
        initializeUsers();
        
        logger.info("Sample data initialization completed");
    }
    
    /**
     * Initialize sample movies as per requirements
     */
    private void initializeMovies() {
        // Check if movies already exist
        if (movieRepository.count() > 0) {
            logger.info("Movies already exist, skipping movie initialization");
            return;
        }
        
        // Movie 1: Avengers Endgame in 2 theatres
        Movie movie1Theatre1 = new Movie("Avengers Endgame", "PVR Cinemas", 100);
        movie1Theatre1.setDescription("The final battle against Thanos");
        movie1Theatre1.setGenre("Action/Sci-Fi");
        movie1Theatre1.setLanguage("English");
        movie1Theatre1.setDuration(181);
        movie1Theatre1.setPosterUrl("https://example.com/avengers-endgame-poster.jpg");
        
        Movie movie1Theatre2 = new Movie("Avengers Endgame", "INOX Multiplex", 150);
        movie1Theatre2.setDescription("The final battle against Thanos");
        movie1Theatre2.setGenre("Action/Sci-Fi");
        movie1Theatre2.setLanguage("English");
        movie1Theatre2.setDuration(181);
        movie1Theatre2.setPosterUrl("https://example.com/avengers-endgame-poster.jpg");
        
        // Movie 2: RRR in 2 theatres
        Movie movie2Theatre1 = new Movie("RRR", "PVR Cinemas", 120);
        movie2Theatre1.setDescription("A fictional story about Indian revolutionaries");
        movie2Theatre1.setGenre("Action/Drama");
        movie2Theatre1.setLanguage("Telugu");
        movie2Theatre1.setDuration(187);
        movie2Theatre1.setPosterUrl("https://example.com/rrr-poster.jpg");
        
        Movie movie2Theatre2 = new Movie("RRR", "Cinepolis", 80);
        movie2Theatre2.setDescription("A fictional story about Indian revolutionaries");
        movie2Theatre2.setGenre("Action/Drama");
        movie2Theatre2.setLanguage("Telugu");
        movie2Theatre2.setDuration(187);
        movie2Theatre2.setPosterUrl("https://example.com/rrr-poster.jpg");
        
        // Save movies
        movieRepository.save(movie1Theatre1);
        movieRepository.save(movie1Theatre2);
        movieRepository.save(movie2Theatre1);
        movieRepository.save(movie2Theatre2);
        
        logger.info("Sample movies created successfully");
    }
    
    /**
     * Initialize admin and sample users
     */
    private void initializeUsers() {
        // Check if users already exist
        if (userRepository.count() > 0) {
            logger.info("Users already exist, skipping user initialization");
            return;
        }
        
        // Create admin user
        User admin = new User();
        admin.setFirstName("System");
        admin.setLastName("Administrator");
        admin.setEmail("admin@moviebooking.com");
        admin.setLoginId("admin");
        admin.setPassword(passwordEncoder.encode("admin123"));
        admin.setContactNumber("9999999999");
        admin.setRole(User.Role.ADMIN);
        
        userRepository.save(admin);
        
        // Create sample regular user
        User user = new User();
        user.setFirstName("John");
        user.setLastName("Doe");
        user.setEmail("john.doe@example.com");
        user.setLoginId("john_doe");
        user.setPassword(passwordEncoder.encode("password123"));
        user.setContactNumber("9876543210");
        user.setRole(User.Role.USER);
        
        userRepository.save(user);
        
        logger.info("Sample users created successfully");
        logger.info("Admin credentials - LoginID: admin, Password: admin123");
        logger.info("User credentials - LoginID: john_doe, Password: password123");
    }
}
