package com.moviebookingapp.exception;

import com.moviebookingapp.dto.ApiResponseDto;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;

import jakarta.validation.ConstraintViolationException;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Global exception handler for the application
 */
@RestControllerAdvice
public class GlobalExceptionHandler {
    
    /**
     * Handle validation errors from request body
     */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ApiResponseDto<Map<String, String>>> handleValidationExceptions(
            MethodArgumentNotValidException ex, WebRequest request) {
        
        Map<String, String> errors = new HashMap<>();
        ex.getBindingResult().getAllErrors().forEach((error) -> {
            String fieldName = ((FieldError) error).getField();
            String errorMessage = error.getDefaultMessage();
            errors.put(fieldName, errorMessage);
        });
        
        ApiResponseDto<Map<String, String>> response = ApiResponseDto.error(
            "Validation failed", errors);
        response.setPath(request.getDescription(false));
        
        return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
    }
    
    /**
     * Handle constraint violation exceptions
     */
    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<ApiResponseDto<Map<String, String>>> handleConstraintViolation(
            ConstraintViolationException ex, WebRequest request) {
        
        Map<String, String> errors = ex.getConstraintViolations().stream()
            .collect(Collectors.toMap(
                violation -> violation.getPropertyPath().toString(),
                violation -> violation.getMessage(),
                (existing, replacement) -> existing
            ));
        
        ApiResponseDto<Map<String, String>> response = ApiResponseDto.error(
            "Constraint violation", errors);
        response.setPath(request.getDescription(false));
        
        return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
    }
    
    /**
     * Handle user not found exception
     */
    @ExceptionHandler(UserNotFoundException.class)
    public ResponseEntity<ApiResponseDto<Object>> handleUserNotFound(
            UserNotFoundException ex, WebRequest request) {
        
        ApiResponseDto<Object> response = ApiResponseDto.error(ex.getMessage());
        response.setPath(request.getDescription(false));
        
        return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
    }
    
    /**
     * Handle movie not found exception
     */
    @ExceptionHandler(MovieNotFoundException.class)
    public ResponseEntity<ApiResponseDto<Object>> handleMovieNotFound(
            MovieNotFoundException ex, WebRequest request) {
        
        ApiResponseDto<Object> response = ApiResponseDto.error(ex.getMessage());
        response.setPath(request.getDescription(false));
        
        return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
    }
    
    /**
     * Handle ticket booking exception
     */
    @ExceptionHandler(TicketBookingException.class)
    public ResponseEntity<ApiResponseDto<Object>> handleTicketBooking(
            TicketBookingException ex, WebRequest request) {
        
        ApiResponseDto<Object> response = ApiResponseDto.error(ex.getMessage(), ex.getDetails());
        response.setPath(request.getDescription(false));
        
        return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
    }
    
    /**
     * Handle authentication exception
     */
    @ExceptionHandler({AuthenticationException.class, BadCredentialsException.class})
    public ResponseEntity<ApiResponseDto<Object>> handleAuthentication(
            RuntimeException ex, WebRequest request) {
        
        ApiResponseDto<Object> response = ApiResponseDto.error(
            "Authentication failed: " + ex.getMessage());
        response.setPath(request.getDescription(false));
        
        return new ResponseEntity<>(response, HttpStatus.UNAUTHORIZED);
    }
    
    /**
     * Handle authorization exception
     */
    @ExceptionHandler({AuthorizationException.class, AccessDeniedException.class})
    public ResponseEntity<ApiResponseDto<Object>> handleAuthorization(
            RuntimeException ex, WebRequest request) {
        
        ApiResponseDto<Object> response = ApiResponseDto.error(
            "Access denied: " + ex.getMessage());
        response.setPath(request.getDescription(false));
        
        return new ResponseEntity<>(response, HttpStatus.FORBIDDEN);
    }
    
    /**
     * Handle validation exception
     */
    @ExceptionHandler(ValidationException.class)
    public ResponseEntity<ApiResponseDto<Object>> handleValidation(
            ValidationException ex, WebRequest request) {
        
        ApiResponseDto<Object> response = ApiResponseDto.error(ex.getMessage(), ex.getDetails());
        response.setPath(request.getDescription(false));
        
        return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
    }
    
    /**
     * Handle duplicate resource exception
     */
    @ExceptionHandler(DuplicateResourceException.class)
    public ResponseEntity<ApiResponseDto<Object>> handleDuplicateResource(
            DuplicateResourceException ex, WebRequest request) {
        
        ApiResponseDto<Object> response = ApiResponseDto.error(ex.getMessage());
        response.setPath(request.getDescription(false));
        
        return new ResponseEntity<>(response, HttpStatus.CONFLICT);
    }
    
    /**
     * Handle illegal argument exception
     */
    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<ApiResponseDto<Object>> handleIllegalArgument(
            IllegalArgumentException ex, WebRequest request) {
        
        ApiResponseDto<Object> response = ApiResponseDto.error(
            "Invalid argument: " + ex.getMessage());
        response.setPath(request.getDescription(false));
        
        return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
    }
    
    /**
     * Handle general movie booking exception
     */
    @ExceptionHandler(MovieBookingException.class)
    public ResponseEntity<ApiResponseDto<Object>> handleMovieBooking(
            MovieBookingException ex, WebRequest request) {
        
        ApiResponseDto<Object> response = ApiResponseDto.error(ex.getMessage(), ex.getDetails());
        response.setPath(request.getDescription(false));
        
        HttpStatus status = determineHttpStatus(ex.getErrorCode());
        return new ResponseEntity<>(response, status);
    }
    
    /**
     * Handle all other exceptions
     */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ApiResponseDto<Object>> handleGlobalException(
            Exception ex, WebRequest request) {
        
        ApiResponseDto<Object> response = ApiResponseDto.error(
            "An unexpected error occurred: " + ex.getMessage());
        response.setPath(request.getDescription(false));
        
        return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
    }
    
    /**
     * Determine HTTP status based on error code
     */
    private HttpStatus determineHttpStatus(String errorCode) {
        if (errorCode == null) {
            return HttpStatus.INTERNAL_SERVER_ERROR;
        }
        
        return switch (errorCode) {
            case "USER_NOT_FOUND", "MOVIE_NOT_FOUND" -> HttpStatus.NOT_FOUND;
            case "AUTHENTICATION_ERROR" -> HttpStatus.UNAUTHORIZED;
            case "AUTHORIZATION_ERROR" -> HttpStatus.FORBIDDEN;
            case "VALIDATION_ERROR", "TICKET_BOOKING_ERROR" -> HttpStatus.BAD_REQUEST;
            case "DUPLICATE_RESOURCE" -> HttpStatus.CONFLICT;
            default -> HttpStatus.INTERNAL_SERVER_ERROR;
        };
    }
}
