package com.moviebookingapp.model;

import java.io.Serializable;
import java.util.Objects;

/**
 * Composite key class for Movie entity (movieName + theatreName)
 */
public class MovieCompositeKey implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private String movieName;
    private String theatreName;
    
    // Default constructor
    public MovieCompositeKey() {}
    
    public MovieCompositeKey(String movieName, String theatreName) {
        this.movieName = movieName;
        this.theatreName = theatreName;
    }
    
    // Getters and setters
    public String getMovieName() {
        return movieName;
    }
    
    public void setMovieName(String movieName) {
        this.movieName = movieName;
    }
    
    public String getTheatreName() {
        return theatreName;
    }
    
    public void setTheatreName(String theatreName) {
        this.theatreName = theatreName;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        MovieCompositeKey that = (MovieCompositeKey) o;
        return Objects.equals(movieName, that.movieName) && 
               Objects.equals(theatreName, that.theatreName);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(movieName, theatreName);
    }
    
    @Override
    public String toString() {
        return "MovieCompositeKey{" +
                "movieName='" + movieName + '\'' +
                ", theatreName='" + theatreName + '\'' +
                '}';
    }
}
