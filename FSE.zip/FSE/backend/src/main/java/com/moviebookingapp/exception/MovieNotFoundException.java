package com.moviebookingapp.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Exception for movie not found scenarios
 */
@ResponseStatus(HttpStatus.NOT_FOUND)
public class MovieNotFoundException extends MovieBookingException {
    
    private String movieName;
    private String theatreName;
    
    public MovieNotFoundException(String message) {
        super("MOVIE_NOT_FOUND", message);
    }
    
    public MovieNotFoundException(String movieName, String theatreName) {
        super("MOVIE_NOT_FOUND", "Movie not found: " + movieName + " at " + theatreName);
        this.movieName = movieName;
        this.theatreName = theatreName;
    }
    
    public MovieNotFoundException(String movieName, String theatreName, String message) {
        super("MOVIE_NOT_FOUND", message);
        this.movieName = movieName;
        this.theatreName = theatreName;
    }
    
    public String getMovieName() {
        return movieName;
    }
    
    public String getTheatreName() {
        return theatreName;
    }
}
