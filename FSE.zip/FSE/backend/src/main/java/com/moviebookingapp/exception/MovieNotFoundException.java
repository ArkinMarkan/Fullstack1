package com.moviebookingapp.exception;

/**
 * Exception for movie not found scenarios
 */
public class MovieNotFoundException extends MovieBookingException {
    public MovieNotFoundException(String message) {
        super("MOVIE_NOT_FOUND", message);
    }
}
