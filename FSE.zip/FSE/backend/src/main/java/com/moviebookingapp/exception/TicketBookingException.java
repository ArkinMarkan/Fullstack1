package com.moviebookingapp.exception;

/**
 * Exception for ticket booking scenarios
 */
public class TicketBookingException extends MovieBookingException {
    public TicketBookingException(String message) {
        super("TICKET_BOOKING_ERROR", message);
    }
    
    public TicketBookingException(String message, Object details) {
        super("TICKET_BOOKING_ERROR", message, details);
    }
}
