package com.moviebookingapp.repository;

import com.moviebookingapp.model.Ticket;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * Repository interface for Ticket entity with JPA/MySQL
 */
@Repository
public interface TicketRepository extends JpaRepository<Ticket, Long> {
    
    /**
     * Find tickets by user ID
     */
    List<Ticket> findByUserId(Long userId);
    
    /**
     * Find tickets by user login ID
     */
    List<Ticket> findByUserLoginId(String userLoginId);
    
    /**
     * Find tickets by movie name and theatre name
     */
    List<Ticket> findByMovieNameAndTheatreName(String movieName, String theatreName);
    
    /**
     * Find tickets by movie name
     */
    List<Ticket> findByMovieName(String movieName);
    
    /**
     * Find tickets by theatre name
     */
    List<Ticket> findByTheatreName(String theatreName);
    
    /**
     * Find tickets by status
     */
    List<Ticket> findByStatus(Ticket.TicketStatus status);
    
    /**
     * Find confirmed tickets
     */
    @Query("{'status': 'CONFIRMED'}")
    List<Ticket> findConfirmedTickets();
    
    /**
     * Find tickets by booking reference
     */
    Optional<Ticket> findByBookingReference(String bookingReference);
    
    /**
     * Count total tickets booked for a movie and theatre
     */
    @Query(value = "{'movieName': ?0, 'theatreName': ?1, 'status': 'CONFIRMED'}", count = true)
    long countBookedTicketsByMovieAndTheatre(String movieName, String theatreName);
    
    /**
     * Sum number of tickets for a movie and theatre
     */
    @Aggregation(pipeline = {
        "{ $match: { 'movieName': ?0, 'theatreName': ?1, 'status': 'CONFIRMED' } }",
        "{ $group: { _id: null, totalTickets: { $sum: '$numberOfTickets' } } }"
    })
    Optional<TicketSummary> sumTicketsByMovieAndTheatre(String movieName, String theatreName);
    
    /**
     * Find tickets booked within a date range
     */
    List<Ticket> findByBookedAtBetween(LocalDateTime startDate, LocalDateTime endDate);
    
    /**
     * Find tickets by user and status
     */
    List<Ticket> findByUserIdAndStatus(String userId, Ticket.TicketStatus status);
    
    /**
     * Find tickets with specific seat numbers for a movie and theatre
     */
    @Query("{'movieName': ?0, 'theatreName': ?1, 'seatNumbers': {$in: ?2}, 'status': 'CONFIRMED'}")
    List<Ticket> findByMovieTheatreAndSeatNumbers(String movieName, String theatreName, List<String> seatNumbers);
    
    /**
     * Get booking statistics by movie
     */
    @Aggregation(pipeline = {
        "{ $match: { 'status': 'CONFIRMED' } }",
        "{ $group: { _id: '$movieName', totalBookings: { $sum: 1 }, totalTickets: { $sum: '$numberOfTickets' } } }",
        "{ $sort: { totalTickets: -1 } }"
    })
    List<MovieBookingStats> getBookingStatsByMovie();
    
    /**
     * Get booking statistics by theatre
     */
    @Aggregation(pipeline = {
        "{ $match: { 'status': 'CONFIRMED' } }",
        "{ $group: { _id: '$theatreName', totalBookings: { $sum: 1 }, totalTickets: { $sum: '$numberOfTickets' } } }",
        "{ $sort: { totalTickets: -1 } }"
    })
    List<TheatreBookingStats> getBookingStatsByTheatre();
    
    /**
     * Get user booking history
     */
    @Query("{'userId': ?0}")
    List<Ticket> findUserBookingHistory(String userId);
    
    /**
     * Delete tickets older than specified date
     */
    void deleteByBookedAtBefore(LocalDateTime date);
    
    /**
     * Interface for ticket summary projection
     */
    interface TicketSummary {
        Integer getTotalTickets();
    }
    
    /**
     * Interface for movie booking statistics
     */
    interface MovieBookingStats {
        String getId(); // movieName
        Integer getTotalBookings();
        Integer getTotalTickets();
    }
    
    /**
     * Interface for theatre booking statistics
     */
    interface TheatreBookingStats {
        String getId(); // theatreName
        Integer getTotalBookings();
        Integer getTotalTickets();
    }
}
