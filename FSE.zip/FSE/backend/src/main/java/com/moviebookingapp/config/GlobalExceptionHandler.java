package com.moviebookingapp.config;

import com.moviebookingapp.dto.ApiResponseDto;
import com.moviebookingapp.exception.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

/**
 * Global exception handler for the Movie Booking Application
 */
@RestControllerAdvice
public class GlobalExceptionHandler {
    
    private static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);
    
    /**
     * Handle validation errors
     */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ApiResponseDto<Map<String, String>>> handleValidationExceptions(
            MethodArgumentNotValidException ex) {
        
        Map<String, String> errors = new HashMap<>();
        ex.getBindingResult().getAllErrors().forEach((error) -> {
            String fieldName = ((FieldError) error).getField();
            String errorMessage = error.getDefaultMessage();
            errors.put(fieldName, errorMessage);
        });
        
        logger.warn("Validation errors: {}", errors);
        
        ApiResponseDto<Map<String, String>> response = ApiResponseDto.error(
            "Validation failed", errors);
        
        return ResponseEntity.badRequest().body(response);
    }
    
    /**
     * Handle custom validation exceptions
     */
    @ExceptionHandler(ValidationException.class)
    public ResponseEntity<ApiResponseDto<Void>> handleValidationException(
            ValidationException ex, WebRequest request) {
        
        logger.warn("Validation exception: {}", ex.getMessage());
        
        ApiResponseDto<Void> response = ApiResponseDto.error(ex.getMessage(), null);
        return ResponseEntity.badRequest().body(response);
    }
    
    /**
     * Handle movie not found exceptions
     */
    @ExceptionHandler(MovieNotFoundException.class)
    public ResponseEntity<ApiResponseDto<Void>> handleMovieNotFoundException(
            MovieNotFoundException ex, WebRequest request) {
        
        logger.warn("Movie not found: {}", ex.getMessage());
        
        ApiResponseDto<Void> response = ApiResponseDto.error(ex.getMessage(), null);
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
    }
    
    /**
     * Handle user not found exceptions
     */
    @ExceptionHandler(UserNotFoundException.class)
    public ResponseEntity<ApiResponseDto<Void>> handleUserNotFoundException(
            UserNotFoundException ex, WebRequest request) {
        
        logger.warn("User not found: {}", ex.getMessage());
        
        ApiResponseDto<Void> response = ApiResponseDto.error(ex.getMessage(), null);
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
    }
    
    /**
     * Handle duplicate resource exceptions
     */
    @ExceptionHandler(DuplicateResourceException.class)
    public ResponseEntity<ApiResponseDto<Void>> handleDuplicateResourceException(
            DuplicateResourceException ex, WebRequest request) {
        
        logger.warn("Duplicate resource: {}", ex.getMessage());
        
        ApiResponseDto<Void> response = ApiResponseDto.error(ex.getMessage(), null);
        return ResponseEntity.status(HttpStatus.CONFLICT).body(response);
    }
    
    /**
     * Handle ticket booking exceptions
     */
    @ExceptionHandler(TicketBookingException.class)
    public ResponseEntity<ApiResponseDto<Void>> handleTicketBookingException(
            TicketBookingException ex, WebRequest request) {
        
        logger.warn("Ticket booking error: {}", ex.getMessage());
        
        ApiResponseDto<Void> response = ApiResponseDto.error(ex.getMessage(), null);
        return ResponseEntity.badRequest().body(response);
    }
    
    /**
     * Handle authentication exceptions
     */
    @ExceptionHandler({AuthenticationException.class, BadCredentialsException.class})
    public ResponseEntity<ApiResponseDto<Void>> handleAuthenticationException(
            Exception ex, WebRequest request) {
        
        logger.warn("Authentication error: {}", ex.getMessage());
        
        ApiResponseDto<Void> response = ApiResponseDto.error(
            "Authentication failed. Please check your credentials.", null);
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(response);
    }
    
    /**
     * Handle access denied exceptions
     */
    @ExceptionHandler(AccessDeniedException.class)
    public ResponseEntity<ApiResponseDto<Void>> handleAccessDeniedException(
            AccessDeniedException ex, WebRequest request) {
        
        logger.warn("Access denied: {}", ex.getMessage());
        
        ApiResponseDto<Void> response = ApiResponseDto.error(
            "Access denied. Insufficient permissions.", null);
        return ResponseEntity.status(HttpStatus.FORBIDDEN).body(response);
    }
    
    /**
     * Handle all other exceptions
     */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ApiResponseDto<String>> handleGlobalException(
            Exception ex, WebRequest request) {
        
        logger.error("Unexpected error occurred", ex);
        
        // In production, don't expose internal error details
        String errorMessage = "An unexpected error occurred. Please try again later.";
        String errorDetails = ex.getClass().getSimpleName() + ": " + ex.getMessage();
        
        ApiResponseDto<String> response = ApiResponseDto.error(errorMessage, errorDetails);
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
    }
}
