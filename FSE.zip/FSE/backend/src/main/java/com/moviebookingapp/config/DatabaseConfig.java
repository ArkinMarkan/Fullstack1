package com.moviebookingapp.config;

import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * Database configuration for MySQL with JPA
 * Uses Spring Boot autoconfiguration with application-mysql.properties
 */
@Configuration
@EnableJpaRepositories(basePackages = "com.moviebookingapp.repository")
@EnableJpaAuditing
@EnableTransactionManagement
@EnableCaching
public class DatabaseConfig {
    // Spring Boot will handle DataSource configuration through application properties
}
