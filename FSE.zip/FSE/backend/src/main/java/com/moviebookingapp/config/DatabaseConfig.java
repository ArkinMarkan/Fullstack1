package com.moviebookingapp.config;

import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * Database configuration for MySQL with JPA
 * Uses Spring Boot autoconfiguration with application-mysql.properties
 */
@Configuration
@EnableTransactionManagement
@EnableCaching
public class DatabaseConfig {
    // Spring Boot will handle DataSource and JPA repository configuration through application properties
}
