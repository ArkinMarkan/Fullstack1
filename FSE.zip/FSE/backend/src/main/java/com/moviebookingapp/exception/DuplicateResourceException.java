package com.moviebookingapp.exception;

/**
 * Exception for duplicate resource scenarios
 */
public class DuplicateResourceException extends MovieBookingException {
    public DuplicateResourceException(String message) {
        super("DUPLICATE_RESOURCE", message);
    }
}
