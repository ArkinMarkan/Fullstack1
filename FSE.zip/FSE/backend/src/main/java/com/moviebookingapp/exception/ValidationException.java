package com.moviebookingapp.exception;

/**
 * Exception for validation scenarios
 */
public class ValidationException extends MovieBookingException {
    public ValidationException(String message) {
        super("VALIDATION_ERROR", message);
    }
    
    public ValidationException(String message, Object details) {
        super("VALIDATION_ERROR", message, details);
    }
}
