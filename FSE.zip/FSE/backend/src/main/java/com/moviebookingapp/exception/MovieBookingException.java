package com.moviebookingapp.exception;

/**
 * Custom exception for movie booking related errors
 */
public class MovieBookingException extends RuntimeException {
    
    private String errorCode;
    private Object details;
    
    public MovieBookingException(String message) {
        super(message);
    }
    
    public MovieBookingException(String message, Throwable cause) {
        super(message, cause);
    }
    
    public MovieBookingException(String errorCode, String message) {
        super(message);
        this.errorCode = errorCode;
    }
    
    public MovieBookingException(String errorCode, String message, Object details) {
        super(message);
        this.errorCode = errorCode;
        this.details = details;
    }
    
    public String getErrorCode() {
        return errorCode;
    }
    
    public Object getDetails() {
        return details;
    }
}
