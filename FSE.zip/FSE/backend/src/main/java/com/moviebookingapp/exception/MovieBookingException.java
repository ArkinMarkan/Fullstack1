package com.moviebookingapp.exception;

/**
 * Custom exception for movie booking related errors
 */
public class MovieBookingException extends RuntimeException {
    
    private String errorCode;
    private Object details;
    
    public MovieBookingException(String message) {
        super(message);
    }
    
    public MovieBookingException(String message, Throwable cause) {
        super(message, cause);
    }
    
    public MovieBookingException(String errorCode, String message) {
        super(message);
        this.errorCode = errorCode;
    }
    
    public MovieBookingException(String errorCode, String message, Object details) {
        super(message);
        this.errorCode = errorCode;
        this.details = details;
    }
    
    public String getErrorCode() {
        return errorCode;
    }
    
    public Object getDetails() {
        return details;
    }
}

/**
 * Exception for user not found scenarios
 */
class UserNotFoundException extends MovieBookingException {
    public UserNotFoundException(String message) {
        super("USER_NOT_FOUND", message);
    }
}

/**
 * Exception for movie not found scenarios
 */
class MovieNotFoundException extends MovieBookingException {
    public MovieNotFoundException(String message) {
        super("MOVIE_NOT_FOUND", message);
    }
}

/**
 * Exception for ticket booking scenarios
 */
class TicketBookingException extends MovieBookingException {
    public TicketBookingException(String message) {
        super("TICKET_BOOKING_ERROR", message);
    }
    
    public TicketBookingException(String message, Object details) {
        super("TICKET_BOOKING_ERROR", message, details);
    }
}

/**
 * Exception for authentication scenarios
 */
class AuthenticationException extends MovieBookingException {
    public AuthenticationException(String message) {
        super("AUTHENTICATION_ERROR", message);
    }
}

/**
 * Exception for authorization scenarios
 */
class AuthorizationException extends MovieBookingException {
    public AuthorizationException(String message) {
        super("AUTHORIZATION_ERROR", message);
    }
}

/**
 * Exception for validation scenarios
 */
class ValidationException extends MovieBookingException {
    public ValidationException(String message) {
        super("VALIDATION_ERROR", message);
    }
    
    public ValidationException(String message, Object details) {
        super("VALIDATION_ERROR", message, details);
    }
}

/**
 * Exception for duplicate resource scenarios
 */
class DuplicateResourceException extends MovieBookingException {
    public DuplicateResourceException(String message) {
        super("DUPLICATE_RESOURCE", message);
    }
}
