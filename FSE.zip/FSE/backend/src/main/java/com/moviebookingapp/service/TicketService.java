package com.moviebookingapp.service;

import com.moviebookingapp.dto.TicketBookingDto;
import com.moviebookingapp.exception.TicketBookingException;
import com.moviebookingapp.exception.ValidationException;
import com.moviebookingapp.model.Movie;
import com.moviebookingapp.model.Ticket;
import com.moviebookingapp.model.User;
import com.moviebookingapp.repository.TicketRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Service class for ticket booking operations
 */
@Service
@Transactional
public class TicketService {
    
    private static final Logger logger = LoggerFactory.getLogger(TicketService.class);
    
    private TicketRepository ticketRepository;
    private MovieService movieService;
    private UserService userService;
    
    // Setter-based dependency injection
    @Autowired
    public void setTicketRepository(TicketRepository ticketRepository) {
        this.ticketRepository = ticketRepository;
    }
    
    @Autowired
    public void setMovieService(MovieService movieService) {
        this.movieService = movieService;
    }
    
    @Autowired
    public void setUserService(UserService userService) {
        this.userService = userService;
    }
    
    /**
     * Book tickets for a movie
     */
    @CacheEvict(value = {"tickets", "movies", "statistics"}, allEntries = true)
    public Ticket bookTicket(TicketBookingDto bookingDto, String userLoginId) {
        logger.info("Booking {} tickets for movie: {} at theatre: {} by user: {}", 
            bookingDto.getNumberOfTickets(), bookingDto.getMovieName(), 
            bookingDto.getTheatreName(), userLoginId);
        
        // Validate booking data
        validateBookingData(bookingDto);
        
        // Get user details
        User user = userService.findByLoginId(userLoginId);
        
        // Get movie details and check availability
        Movie movie = movieService.getMovieByNameAndTheatre(
            bookingDto.getMovieName(), bookingDto.getTheatreName());
        
        // Check if movie is available for booking
        if (!"BOOK_ASAP".equals(movie.getStatus())) {
            throw new TicketBookingException("Movie is not available for booking. Current status: " + movie.getStatus());
        }
        
        // Check seat availability
        validateSeatAvailability(bookingDto, movie);
        
        // Create ticket
        Ticket ticket = new Ticket(
            bookingDto.getMovieName(),
            bookingDto.getTheatreName(),
            bookingDto.getNumberOfTickets(),
            bookingDto.getSeatNumbers(),
            user.getId(),
            user.getLoginId()
        );
        
        // Save ticket first
        Ticket savedTicket = ticketRepository.save(ticket);
        
        // Update movie available tickets
        try {
            movieService.updateAvailableTickets(
                bookingDto.getMovieName(), 
                bookingDto.getTheatreName(), 
                bookingDto.getNumberOfTickets()
            );
        } catch (Exception e) {
            // If movie update fails, rollback ticket creation
            ticketRepository.delete(savedTicket);
            throw new TicketBookingException("Failed to update movie tickets: " + e.getMessage());
        }
        
        logger.info("Ticket booked successfully with reference: {}", 
            savedTicket.getBookingReference());
        
        return savedTicket;
    }
    
    /**
     * Get tickets by user login ID
     */
    @Cacheable(value = "tickets", key = "#userLoginId")
    public List<Ticket> getTicketsByUser(String userLoginId) {
        logger.info("Fetching tickets for user: {}", userLoginId);
        return ticketRepository.findByUserLoginId(userLoginId);
    }
    
    /**
     * Get all booked tickets for a movie
     */
    @Cacheable(value = "tickets", key = "#movieName + '_' + #theatreName + '_booked'")
    public List<Ticket> getBookedTicketsByMovie(String movieName, String theatreName) {
        logger.info("Fetching booked tickets for movie: {} at theatre: {}", movieName, theatreName);
        return ticketRepository.findByMovieNameAndTheatreName(movieName, theatreName)
                .stream()
                .filter(ticket -> ticket.getStatus() == Ticket.TicketStatus.CONFIRMED)
                .collect(Collectors.toList());
    }
    
    /**
     * Get ticket by booking reference
     */
    @Cacheable(value = "tickets", key = "#bookingReference")
    public Ticket getTicketByBookingReference(String bookingReference) {
        return ticketRepository.findByBookingReference(bookingReference)
                .orElseThrow(() -> new TicketBookingException("Ticket not found with booking reference: " + bookingReference));
    }
    
    /**
     * Cancel ticket
     */
    @CacheEvict(value = {"tickets", "movies", "statistics"}, allEntries = true)
    public Ticket cancelTicket(String bookingReference, String userLoginId) {
        logger.info("Cancelling ticket with reference: {} by user: {}", bookingReference, userLoginId);
        
        Ticket ticket = getTicketByBookingReference(bookingReference);
        
        // Verify user owns the ticket
        if (!ticket.getUserLoginId().equals(userLoginId)) {
            throw new TicketBookingException("You can only cancel your own tickets");
        }
        
        // Check if ticket is already cancelled
        if (ticket.getStatus() != Ticket.TicketStatus.CONFIRMED) {
            throw new TicketBookingException("Ticket is already cancelled or expired");
        }
        
        // Cancel ticket
        ticket.cancel();
        Ticket savedTicket = ticketRepository.save(ticket);
        
        // Recalculate movie ticket availability
        try {
            movieService.recalculateTicketStatus(ticket.getMovieName(), ticket.getTheatreName());
        } catch (Exception e) {
            logger.warn("Failed to recalculate movie status after ticket cancellation: {}", e.getMessage());
        }
        
        logger.info("Ticket cancelled successfully: {}", bookingReference);
        return savedTicket;
    }
    
    /**
     * Get booking statistics by movie
     */
    @Cacheable(value = "statistics", key = "'booking_stats_movie'")
    public List<TicketRepository.MovieBookingStats> getBookingStatsByMovie() {
        return ticketRepository.getBookingStatsByMovie();
    }
    
    /**
     * Get booking statistics by theatre
     */
    @Cacheable(value = "statistics", key = "'booking_stats_theatre'")
    public List<TicketRepository.TheatreBookingStats> getBookingStatsByTheatre() {
        return ticketRepository.getBookingStatsByTheatre();
    }
    
    /**
     * Get user booking history
     */
    @Cacheable(value = "tickets", key = "#userId + '_history'")
    public List<Ticket> getUserBookingHistory(String userId) {
        return ticketRepository.findUserBookingHistory(userId);
    }
    
    /**
     * Count total booked tickets for a movie
     */
    @Cacheable(value = "statistics", key = "#movieName + '_' + #theatreName + '_count'")
    public long countBookedTickets(String movieName, String theatreName) {
        return ticketRepository.countBookedTicketsByMovieAndTheatre(movieName, theatreName);
    }
    
    /**
     * Get all tickets (Admin only)
     */
    @Cacheable(value = "tickets", key = "'all'")
    public List<Ticket> getAllTickets() {
        return ticketRepository.findAll();
    }
    
    /**
     * Get confirmed tickets
     */
    @Cacheable(value = "tickets", key = "'confirmed'")
    public List<Ticket> getConfirmedTickets() {
        return ticketRepository.findConfirmedTickets();
    }
    
    /**
     * Validate booking data
     */
    private void validateBookingData(TicketBookingDto bookingDto) {
        if (!bookingDto.isValidSeatCount()) {
            throw new ValidationException("Number of tickets must match number of seats selected");
        }
        
        if (bookingDto.getNumberOfTickets() > 10) {
            throw new ValidationException("Maximum 10 tickets can be booked at once");
        }
        
        // Check for duplicate seat numbers
        Set<String> uniqueSeats = bookingDto.getSeatNumbers().stream()
                .collect(Collectors.toSet());
        
        if (uniqueSeats.size() != bookingDto.getSeatNumbers().size()) {
            throw new ValidationException("Duplicate seat numbers are not allowed");
        }
    }
    
    /**
     * Validate seat availability
     */
    private void validateSeatAvailability(TicketBookingDto bookingDto, Movie movie) {
        // Check if enough tickets are available
        if (movie.getAvailableTickets() < bookingDto.getNumberOfTickets()) {
            throw new TicketBookingException(
                String.format("Only %d tickets available, requested %d", 
                    movie.getAvailableTickets(), bookingDto.getNumberOfTickets()));
        }
        
        // Check if selected seats are already booked
        List<Ticket> existingTicketsWithSeats = ticketRepository.findByMovieTheatreAndSeatNumbers(
            bookingDto.getMovieName(), 
            bookingDto.getTheatreName(), 
            bookingDto.getSeatNumbers()
        );
        
        if (!existingTicketsWithSeats.isEmpty()) {
            Set<String> bookedSeats = existingTicketsWithSeats.stream()
                    .flatMap(ticket -> ticket.getSeatNumbers().stream())
                    .filter(seat -> bookingDto.getSeatNumbers().contains(seat))
                    .collect(Collectors.toSet());
            
            throw new TicketBookingException("Following seats are already booked: " + bookedSeats);
        }
    }
}
