package com.moviebookingapp.exception;

/**
 * Exception for user not found scenarios
 */
public class UserNotFoundException extends MovieBookingException {
    public UserNotFoundException(String message) {
        super("USER_NOT_FOUND", message);
    }
}
