package com.moviebookingapp.exception;

/**
 * Exception for authorization scenarios
 */
public class AuthorizationException extends MovieBookingException {
    public AuthorizationException(String message) {
        super("AUTHORIZATION_ERROR", message);
    }
}
