package com.moviebookingapp.exception;

/**
 * Exception for authentication scenarios
 */
public class AuthenticationException extends MovieBookingException {
    
    public AuthenticationException(String message) {
        super("AUTHENTICATION_ERROR", message);
    }
}
