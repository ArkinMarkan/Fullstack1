package com.moviebookingapp.repository;

import com.moviebookingapp.model.Movie;
import com.moviebookingapp.model.MovieCompositeKey;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Repository interface for Movie entity with JPA/MySQL
 */
@Repository
public interface MovieRepository extends JpaRepository<Movie, MovieCompositeKey> {
    
    /**
     * Find movie by movie name and theatre name (composite key)
     */
    Optional<Movie> findByMovieNameAndTheatreName(String movieName, String theatreName);
    
    /**
     * Find movies by movie name
     */
    List<Movie> findByMovieName(String movieName);
    
    /**
     * Find movies by theatre name
     */
    List<Movie> findByTheatreName(String theatreName);
    
    /**
     * Find movies by status
     */
    List<Movie> findByStatus(String status);
    
    /**
     * Find available movies (status = BOOK_ASAP)
     */
    @Query("SELECT m FROM Movie m WHERE m.status = 'BOOK_ASAP'")
    List<Movie> findAvailableMovies();
    
    /**
     * Find sold out movies
     */
    @Query("SELECT m FROM Movie m WHERE m.status = 'SOLD_OUT'")
    List<Movie> findSoldOutMovies();
    
    /**
     * Search movies by movie name (case insensitive, partial match)
     */
    @Query("SELECT m FROM Movie m WHERE LOWER(m.movieName) LIKE LOWER(CONCAT('%', :movieName, '%'))")
    List<Movie> findByMovieNameContainingIgnoreCase(@Param("movieName") String movieName);
    
    /**
     * Search movies by theatre name (case insensitive, partial match)
     */
    @Query("SELECT m FROM Movie m WHERE LOWER(m.theatreName) LIKE LOWER(CONCAT('%', :theatreName, '%'))")
    List<Movie> findByTheatreNameContainingIgnoreCase(@Param("theatreName") String theatreName);
    
    /**
     * Find movies with available tickets greater than specified number
     */
    @Query("SELECT m FROM Movie m WHERE m.availableTickets > :minTickets")
    List<Movie> findMoviesWithAvailableTickets(@Param("minTickets") int minTickets);
    
    /**
     * Find movies by genre
     */
    @Query("SELECT m FROM Movie m WHERE LOWER(m.genre) LIKE LOWER(CONCAT('%', :genre, '%'))")
    List<Movie> findByGenreIgnoreCase(@Param("genre") String genre);
    
    /**
     * Find movies by language
     */
    @Query("SELECT m FROM Movie m WHERE LOWER(m.language) LIKE LOWER(CONCAT('%', :language, '%'))")
    List<Movie> findByLanguageIgnoreCase(@Param("language") String language);
    
    /**
     * Custom query to get movie statistics using JPQL
     */
    @Query("SELECT m.movieName as id, COUNT(m) as totalTheatres, SUM(m.totalTickets) as totalTickets, SUM(m.availableTickets) as availableTickets " +
           "FROM Movie m GROUP BY m.movieName")
    List<MovieStats> getMovieStatistics();
    
    /**
     * Find distinct movie names
     */
    @Query("SELECT DISTINCT m.movieName FROM Movie m")
    List<String> findDistinctMovieNames();
    
    /**
     * Find distinct theatre names
     */
    @Query("SELECT DISTINCT m.theatreName FROM Movie m")
    List<String> findDistinctTheatreNames();
    
    /**
     * Complex search query for movies using JPQL
     */
    @Query("SELECT m FROM Movie m WHERE " +
           "LOWER(m.movieName) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR " +
           "LOWER(m.theatreName) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR " +
           "LOWER(m.genre) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR " +
           "LOWER(m.language) LIKE LOWER(CONCAT('%', :searchTerm, '%'))")
    List<Movie> searchMovies(@Param("searchTerm") String searchTerm);
    
    /**
     * Interface for movie statistics projection
     */
    interface MovieStats {
        String getId(); // movieName
        Long getTotalTheatres();
        Long getTotalTickets();
        Long getAvailableTickets();
    }
}
