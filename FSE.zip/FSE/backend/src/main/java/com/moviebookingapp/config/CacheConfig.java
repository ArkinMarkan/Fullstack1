package com.moviebookingapp.config;

import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.concurrent.ConcurrentMapCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Cache Configuration using In-Memory Caching
 */
@Configuration
@EnableCaching
public class CacheConfig {
    
    /**
     * Configure In-Memory Cache Manager
     */
    @Bean
    public CacheManager cacheManager() {
        ConcurrentMapCacheManager cacheManager = new ConcurrentMapCacheManager();
        
        // Set cache names
        cacheManager.setCacheNames(
            java.util.Arrays.asList(
                "movies", 
                "users", 
                "tickets", 
                "search", 
                "statistics",
                "moviesByName", 
                "usersByLoginId"
            )
        );
        
        cacheManager.setAllowNullValues(false);
        return cacheManager;
    }
}
