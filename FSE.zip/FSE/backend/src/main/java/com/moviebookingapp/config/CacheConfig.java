package com.moviebookingapp.config;

import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.cache.RedisCacheConfiguration;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.serializer.GenericJackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.RedisSerializationContext;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

/**
 * Cache Configuration using Redis
 */
@Configuration
@EnableCaching
public class CacheConfig {
    
    /**
     * Configure Redis Cache Manager
     */
    @Bean
    public CacheManager cacheManager(RedisConnectionFactory redisConnectionFactory) {
        RedisCacheConfiguration defaultConfig = RedisCacheConfiguration.defaultCacheConfig()
                .entryTtl(Duration.ofHours(1)) // Default TTL: 1 hour
                .serializeValuesWith(
                    RedisSerializationContext.SerializationPair
                        .fromSerializer(new GenericJackson2JsonRedisSerializer()))
                .disableCachingNullValues();
        
        // Configure specific cache settings
        Map<String, RedisCacheConfiguration> cacheConfigurations = new HashMap<>();
        
        // Movies cache - 30 minutes TTL
        cacheConfigurations.put("movies", defaultConfig
            .entryTtl(Duration.ofMinutes(30)));
        
        // Users cache - 15 minutes TTL
        cacheConfigurations.put("users", defaultConfig
            .entryTtl(Duration.ofMinutes(15)));
        
        // Tickets cache - 5 minutes TTL
        cacheConfigurations.put("tickets", defaultConfig
            .entryTtl(Duration.ofMinutes(5)));
        
        // Search results cache - 10 minutes TTL
        cacheConfigurations.put("search", defaultConfig
            .entryTtl(Duration.ofMinutes(10)));
        
        // Statistics cache - 2 hours TTL
        cacheConfigurations.put("statistics", defaultConfig
            .entryTtl(Duration.ofHours(2)));
        
        // Additional cache configurations for backward compatibility
        cacheConfigurations.put("moviesByName", defaultConfig
            .entryTtl(Duration.ofMinutes(30)));
        
        cacheConfigurations.put("usersByLoginId", defaultConfig
            .entryTtl(Duration.ofMinutes(15)));
        
        return RedisCacheManager.builder(redisConnectionFactory)
                .cacheDefaults(defaultConfig)
                .withInitialCacheConfigurations(cacheConfigurations)
                .build();
    }
}
