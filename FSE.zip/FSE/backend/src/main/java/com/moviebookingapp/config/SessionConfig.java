package com.moviebookingapp.config;

import org.springframework.context.annotation.Configuration;

/**
 * Session configuration (Redis-based session management temporarily disabled)
 */
@Configuration
// @EnableRedisHttpSession(maxInactiveIntervalInSeconds = 3600) // Temporarily disabled
public class SessionConfig {
    // Session configuration disabled for now to avoid Redis conflicts
    // Will re-enable once Redis setup is properly configured
}
