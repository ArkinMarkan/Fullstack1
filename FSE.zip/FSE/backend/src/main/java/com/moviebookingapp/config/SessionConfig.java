package com.moviebookingapp.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.session.data.redis.config.annotation.web.http.EnableRedisHttpSession;

/**
 * Session configuration for Redis-based session management
 */
@Configuration
@EnableRedisHttpSession(maxInactiveIntervalInSeconds = 3600) // 1 hour session timeout
public class SessionConfig {
    // Session configuration only - cache manager is defined in CacheConfig.java
}
