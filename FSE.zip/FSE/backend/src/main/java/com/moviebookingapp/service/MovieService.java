package com.moviebookingapp.service;

import com.moviebookingapp.exception.MovieNotFoundException;
import com.moviebookingapp.exception.ValidationException;
import com.moviebookingapp.model.Movie;
import com.moviebookingapp.repository.MovieRepository;
import com.moviebookingapp.repository.TicketRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

/**
 * Service class for movie management operations
 */
@Service
@Transactional
public class MovieService {
    
    private static final Logger logger = LoggerFactory.getLogger(MovieService.class);
    
    private final MovieRepository movieRepository;
    private final TicketRepository ticketRepository;
    
    // Constructor-based dependency injection
    public MovieService(MovieRepository movieRepository, TicketRepository ticketRepository) {
        this.movieRepository = movieRepository;
        this.ticketRepository = ticketRepository;
    }
    
    /**
     * Get all movies
     */
    @Cacheable(value = "movies", key = "'all'")
    public List<Movie> getAllMovies() {
        logger.info("Fetching all movies");
        return movieRepository.findAll();
    }
    
    /**
     * Get available movies (status = BOOK_ASAP)
     */
    @Cacheable(value = "movies", key = "'available'")
    public List<Movie> getAvailableMovies() {
        logger.info("Fetching available movies");
        return movieRepository.findAvailableMovies();
    }
    
    /**
     * Search movies by name (case insensitive, partial match)
     */
    @Cacheable(value = "search", key = "#movieName")
    public List<Movie> searchMoviesByName(String movieName) {
        logger.info("Searching movies by name: {}", movieName);
        
        if (movieName == null || movieName.trim().isEmpty()) {
            return getAllMovies();
        }
        
        return movieRepository.findByMovieNameContainingIgnoreCase(movieName.trim());
    }
    
    /**
     * Get movie by name and theatre
     */
    @Cacheable(value = "movies", key = "#movieName + '_' + #theatreName")
    public Movie getMovieByNameAndTheatre(String movieName, String theatreName) {
        return movieRepository.findByMovieNameAndTheatreName(movieName, theatreName)
                .orElseThrow(() -> new MovieNotFoundException(
                    String.format("Movie '%s' not found in theatre '%s'", movieName, theatreName)));
    }
    
    /**
     * Get movies by name (all theatres)
     */
    @Cacheable(value = "movies", key = "#movieName + '_all_theatres'")
    public List<Movie> getMoviesByName(String movieName) {
        List<Movie> movies = movieRepository.findByMovieName(movieName);
        if (movies.isEmpty()) {
            throw new MovieNotFoundException("No movies found with name: " + movieName);
        }
        return movies;
    }
    
    /**
     * Add new movie
     */
    @CacheEvict(value = {"movies", "search"}, allEntries = true)
    public Movie addMovie(Movie movie) {
        logger.info("Adding new movie: {} at theatre: {}", movie.getMovieName(), movie.getTheatreName());
        
        // Validate movie data
        validateMovieData(movie);
        
        // Check if movie already exists in the theatre
        Optional<Movie> existingMovie = movieRepository.findByMovieNameAndTheatreName(
            movie.getMovieName(), movie.getTheatreName());
        
        if (existingMovie.isPresent()) {
            throw new ValidationException(
                String.format("Movie '%s' already exists in theatre '%s'", 
                    movie.getMovieName(), movie.getTheatreName()));
        }
        
        // Set initial available tickets equal to total tickets
        movie.setAvailableTickets(movie.getTotalTickets());
        movie.updateStatus();
        
        Movie savedMovie = movieRepository.save(movie);
        logger.info("Movie added successfully: {} at {}", savedMovie.getMovieName(), savedMovie.getTheatreName());
        
        return savedMovie;
    }
    
    /**
     * Update movie ticket status
     */
    @CacheEvict(value = {"movies", "search", "statistics"}, allEntries = true)
    public Movie updateTicketStatus(String movieName, String theatreName, String status) {
        logger.info("Updating ticket status for movie: {} at theatre: {} to status: {}", 
            movieName, theatreName, status);
        
        Movie movie = getMovieByNameAndTheatre(movieName, theatreName);
        
        // Validate status
        if (!"BOOK_ASAP".equals(status) && !"SOLD_OUT".equals(status)) {
            throw new ValidationException("Invalid status. Must be 'BOOK_ASAP' or 'SOLD_OUT'");
        }
        
        movie.setStatus(status);
        Movie savedMovie = movieRepository.save(movie);
        
        logger.info("Ticket status updated successfully for movie: {}", movieName);
        return savedMovie;
    }
    
    /**
     * Update movie available tickets after booking
     */
    @CacheEvict(value = {"movies", "search", "statistics"}, allEntries = true)
    public Movie updateAvailableTickets(String movieName, String theatreName, int ticketsBooked) {
        logger.info("Updating available tickets for movie: {} at theatre: {}, tickets booked: {}", 
            movieName, theatreName, ticketsBooked);
        
        Movie movie = getMovieByNameAndTheatre(movieName, theatreName);
        
        if (movie.getAvailableTickets() < ticketsBooked) {
            throw new ValidationException("Not enough tickets available. Available: " + 
                movie.getAvailableTickets() + ", Requested: " + ticketsBooked);
        }
        
        movie.bookTickets(ticketsBooked);
        Movie savedMovie = movieRepository.save(movie);
        
        logger.info("Available tickets updated. Remaining: {}", savedMovie.getAvailableTickets());
        return savedMovie;
    }
    
    /**
     * Recalculate and update movie ticket status based on bookings
     */
    @CacheEvict(value = {"movies", "search", "statistics"}, allEntries = true)
    public Movie recalculateTicketStatus(String movieName, String theatreName) {
        logger.info("Recalculating ticket status for movie: {} at theatre: {}", movieName, theatreName);
        
        Movie movie = getMovieByNameAndTheatre(movieName, theatreName);
        
        // Get total booked tickets from ticket repository
        Optional<TicketRepository.TicketSummary> ticketSummary = 
            ticketRepository.sumTicketsByMovieAndTheatre(movieName, theatreName);
        
        int bookedTickets = ticketSummary.map(TicketRepository.TicketSummary::getTotalTickets).orElse(0);
        int availableTickets = movie.getTotalTickets() - bookedTickets;
        
        movie.setAvailableTickets(Math.max(0, availableTickets));
        movie.updateStatus();
        
        Movie savedMovie = movieRepository.save(movie);
        logger.info("Ticket status recalculated. Available tickets: {}, Status: {}", 
            savedMovie.getAvailableTickets(), savedMovie.getStatus());
        
        return savedMovie;
    }
    
    /**
     * Delete movie
     */
    @CacheEvict(value = {"movies", "search", "statistics"}, allEntries = true)
    public void deleteMovie(String movieName, String theatreName) {
        logger.info("Deleting movie: {} at theatre: {}", movieName, theatreName);
        
        Movie movie = getMovieByNameAndTheatre(movieName, theatreName);
        
        // Check if there are any active bookings
        long activeBookings = ticketRepository.countBookedTicketsByMovieAndTheatre(movieName, theatreName);
        if (activeBookings > 0) {
            throw new ValidationException("Cannot delete movie with active bookings. Active bookings: " + activeBookings);
        }
        
        movieRepository.delete(movie);
        logger.info("Movie deleted successfully: {}", movieName);
    }
    
    /**
     * Get movie statistics
     */
    @Cacheable(value = "statistics", key = "'movie_stats'")
    public List<MovieRepository.MovieStats> getMovieStatistics() {
        return movieRepository.getMovieStatistics();
    }
    
    /**
     * Search movies by multiple criteria
     */
    @Cacheable(value = "search", key = "#searchTerm + '_multi'")
    public List<Movie> searchMovies(String searchTerm) {
        logger.info("Searching movies with term: {}", searchTerm);
        
        if (searchTerm == null || searchTerm.trim().isEmpty()) {
            return getAllMovies();
        }
        
        return movieRepository.searchMovies(searchTerm.trim());
    }
    
    /**
     * Get distinct movie names
     */
    @Cacheable(value = "movies", key = "'distinct_names'")
    public List<String> getDistinctMovieNames() {
        return movieRepository.findDistinctMovieNames();
    }
    
    /**
     * Get distinct theatre names
     */
    @Cacheable(value = "movies", key = "'distinct_theatres'")
    public List<String> getDistinctTheatreNames() {
        return movieRepository.findDistinctTheatreNames();
    }
    
    /**
     * Validate movie data
     */
    private void validateMovieData(Movie movie) {
        if (movie.getMovieName() == null || movie.getMovieName().trim().isEmpty()) {
            throw new ValidationException("Movie name is required");
        }
        
        if (movie.getTheatreName() == null || movie.getTheatreName().trim().isEmpty()) {
            throw new ValidationException("Theatre name is required");
        }
        
        if (movie.getTotalTickets() == null || movie.getTotalTickets() <= 0) {
            throw new ValidationException("Total tickets must be greater than 0");
        }
    }
}
