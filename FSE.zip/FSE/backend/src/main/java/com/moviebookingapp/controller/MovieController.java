package com.moviebookingapp.controller;

import com.moviebookingapp.dto.ApiResponseDto;
import com.moviebookingapp.model.Movie;
import com.moviebookingapp.repository.MovieRepository;
import com.moviebookingapp.service.MovieService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Controller for movie operations
 */
@RestController
@RequestMapping("/api/v1.0/moviebooking")
@Tag(name = "Movies", description = "Movie management APIs")
@CrossOrigin(origins = "*", maxAge = 3600)
public class MovieController {
    
    private static final Logger logger = LoggerFactory.getLogger(MovieController.class);
    
    @Autowired
    private MovieService movieService;
    
    /**
     * Get all movies
     * GET /api/v1.0/moviebooking/all
     */
    @GetMapping("/all")
    @Operation(summary = "Get all movies", description = "Get list of all movies in all theatres")
    public ResponseEntity<ApiResponseDto<List<Movie>>> getAllMovies() {
        
        logger.info("Request received to fetch all movies");
        
        List<Movie> movies = movieService.getAllMovies();
        
        ApiResponseDto<List<Movie>> response = ApiResponseDto.success(
            "Movies fetched successfully", movies);
        
        return ResponseEntity.ok(response);
    }
    
    /**
     * Search movies by name
     * GET /api/v1.0/moviebooking/movies/search/{moviename}
     */
    @GetMapping("/movies/search/{moviename}")
    @Operation(summary = "Search movies by name", description = "Search movies by partial or complete movie name")
    public ResponseEntity<ApiResponseDto<List<Movie>>> searchMoviesByName(
            @PathVariable String moviename) {
        
        logger.info("Search request received for movie: {}", moviename);
        
        List<Movie> movies = movieService.searchMoviesByName(moviename);
        
        String message = movies.isEmpty() ? 
            "No movies found with name: " + moviename : 
            "Movies found successfully";
        
        ApiResponseDto<List<Movie>> response = ApiResponseDto.success(message, movies);
        
        return ResponseEntity.ok(response);
    }
    
    /**
     * Update ticket status (Admin only)
     * PUT /api/v1.0/moviebooking/{moviename}/update/{status}
     */
    @PutMapping("/{moviename}/update/{status}")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Update ticket status", description = "Update ticket status for a movie (Admin only)")
    public ResponseEntity<ApiResponseDto<Movie>> updateTicketStatus(
            @PathVariable String moviename,
            @PathVariable String status,
            @RequestParam String theatreName) {
        
        logger.info("Ticket status update request for movie: {}, theatre: {}, status: {}", 
            moviename, theatreName, status);
        
        Movie updatedMovie = movieService.updateTicketStatus(moviename, theatreName, status);
        
        ApiResponseDto<Movie> response = ApiResponseDto.success(
            "Ticket status updated successfully", updatedMovie);
        
        return ResponseEntity.ok(response);
    }
    
    /**
     * Delete movie (Admin only)
     * DELETE /api/v1.0/moviebooking/{moviename}/delete/{theatreName}
     */
    @DeleteMapping("/{moviename}/delete/{theatreName}")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Delete movie", description = "Delete a movie from theatre (Admin only)")
    public ResponseEntity<ApiResponseDto<String>> deleteMovie(
            @PathVariable String moviename,
            @PathVariable String theatreName) {
        
        logger.info("Delete request for movie: {}, theatre: {}", moviename, theatreName);
        
        movieService.deleteMovie(moviename, theatreName);
        
        ApiResponseDto<String> response = ApiResponseDto.success(
            "Movie deleted successfully", 
            "Movie '" + moviename + "' deleted from theatre '" + theatreName + "'");
        
        return ResponseEntity.ok(response);
    }
    
    /**
     * Get available movies
     * GET /api/v1.0/moviebooking/available
     */
    @GetMapping("/available")
    @Operation(summary = "Get available movies", description = "Get list of available movies for booking")
    public ResponseEntity<ApiResponseDto<List<Movie>>> getAvailableMovies() {
        
        logger.info("Request received to fetch available movies");
        
        List<Movie> movies = movieService.getAvailableMovies();
        
        ApiResponseDto<List<Movie>> response = ApiResponseDto.success(
            "Available movies fetched successfully", movies);
        
        return ResponseEntity.ok(response);
    }
    
    /**
     * Search movies (enhanced search)
     * GET /api/v1.0/moviebooking/search
     */
    @GetMapping("/search")
    @Operation(summary = "Enhanced movie search", description = "Search movies by name, theatre, genre, or language")
    public ResponseEntity<ApiResponseDto<List<Movie>>> searchMovies(
            @RequestParam String q) {
        
        logger.info("Enhanced search request received with query: {}", q);
        
        List<Movie> movies = movieService.searchMovies(q);
        
        String message = movies.isEmpty() ? 
            "No movies found for query: " + q : 
            "Movies found successfully";
        
        ApiResponseDto<List<Movie>> response = ApiResponseDto.success(message, movies);
        
        return ResponseEntity.ok(response);
    }
    
    /**
     * Get movie statistics (Admin only)
     * GET /api/v1.0/moviebooking/statistics
     */
    @GetMapping("/statistics")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Get movie statistics", description = "Get movie statistics (Admin only)")
    public ResponseEntity<ApiResponseDto<List<MovieRepository.MovieStats>>> getMovieStatistics() {
        
        logger.info("Movie statistics request received");
        
        List<MovieRepository.MovieStats> statistics = movieService.getMovieStatistics();
        
        ApiResponseDto<List<MovieRepository.MovieStats>> response = ApiResponseDto.success(
            "Movie statistics fetched successfully", statistics);
        
        return ResponseEntity.ok(response);
    }
    
    /**
     * Recalculate ticket status (Admin only)
     * POST /api/v1.0/moviebooking/{moviename}/recalculate
     */
    @PostMapping("/{moviename}/recalculate")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Recalculate ticket status", description = "Recalculate movie ticket status based on bookings")
    public ResponseEntity<ApiResponseDto<Movie>> recalculateTicketStatus(
            @PathVariable String moviename,
            @RequestParam String theatreName) {
        
        logger.info("Recalculate request for movie: {}, theatre: {}", moviename, theatreName);
        
        Movie updatedMovie = movieService.recalculateTicketStatus(moviename, theatreName);
        
        ApiResponseDto<Movie> response = ApiResponseDto.success(
            "Ticket status recalculated successfully", updatedMovie);
        
        return ResponseEntity.ok(response);
    }
    
    /**
     * Add new movie (Admin only)
     * POST /api/v1.0/moviebooking/admin/add
     */
    @PostMapping("/admin/add")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Add movie", description = "Add a new movie to a theatre (Admin only)")
    public ResponseEntity<ApiResponseDto<Movie>> addMovie(@RequestBody Movie movie) {
        logger.info("Admin add movie request for: {} at {}", movie.getMovieName(), movie.getTheatreName());
        Movie saved = movieService.addMovie(movie);
        ApiResponseDto<Movie> response = ApiResponseDto.success("Movie added successfully", saved);
        return ResponseEntity.ok(response);
    }
}
