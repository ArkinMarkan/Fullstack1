package com.moviebookingapp.dto;

import jakarta.validation.constraints.NotBlank;

/**
 * DTO for user login request
 */
public class LoginRequestDto {
    
    @NotBlank(message = "Login ID is mandatory")
    private String loginId;
    
    @NotBlank(message = "Password is mandatory")
    private String password;
    
    // Constructors
    public LoginRequestDto() {}
    
    public LoginRequestDto(String loginId, String password) {
        this.loginId = loginId;
        this.password = password;
    }
    
    // Getters and Setters
    public String getLoginId() {
        return loginId;
    }
    
    public void setLoginId(String loginId) {
        this.loginId = loginId;
    }
    
    public String getPassword() {
        return password;
    }
    
    public void setPassword(String password) {
        this.password = password;
    }
    
    @Override
    public String toString() {
        return "LoginRequestDto{" +
                "loginId='" + loginId + '\'' +
                '}';
    }
}

/**
 * DTO for JWT authentication response
 */
class JwtResponseDto {
    
    private String token;
    private String refreshToken;
    private String type = "Bearer";
    private String loginId;
    private String firstName;
    private String lastName;
    private String email;
    private String role;
    
    // Constructors
    public JwtResponseDto() {}
    
    public JwtResponseDto(String token, String refreshToken, String loginId, 
                         String firstName, String lastName, String email, String role) {
        this.token = token;
        this.refreshToken = refreshToken;
        this.loginId = loginId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.role = role;
    }
    
    // Getters and Setters
    public String getToken() {
        return token;
    }
    
    public void setToken(String token) {
        this.token = token;
    }
    
    public String getRefreshToken() {
        return refreshToken;
    }
    
    public void setRefreshToken(String refreshToken) {
        this.refreshToken = refreshToken;
    }
    
    public String getType() {
        return type;
    }
    
    public void setType(String type) {
        this.type = type;
    }
    
    public String getLoginId() {
        return loginId;
    }
    
    public void setLoginId(String loginId) {
        this.loginId = loginId;
    }
    
    public String getFirstName() {
        return firstName;
    }
    
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    
    public String getLastName() {
        return lastName;
    }
    
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    
    public String getEmail() {
        return email;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    
    public String getRole() {
        return role;
    }
    
    public void setRole(String role) {
        this.role = role;
    }
}
