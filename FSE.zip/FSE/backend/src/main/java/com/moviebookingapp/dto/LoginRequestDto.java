package com.moviebookingapp.dto;

import jakarta.validation.constraints.NotBlank;

/**
 * DTO for user login request
 */
public class LoginRequestDto {
    
    @NotBlank(message = "Login ID is mandatory")
    private String loginId;
    
    @NotBlank(message = "Password is mandatory")
    private String password;
    
    // Constructors
    public LoginRequestDto() {}
    
    public LoginRequestDto(String loginId, String password) {
        this.loginId = loginId;
        this.password = password;
    }
    
    // Getters and Setters
    public String getLoginId() {
        return loginId;
    }
    
    public void setLoginId(String loginId) {
        this.loginId = loginId;
    }
    
    public String getPassword() {
        return password;
    }
    
    public void setPassword(String password) {
        this.password = password;
    }
    
    @Override
    public String toString() {
        return "LoginRequestDto{" +
                "loginId='" + loginId + '\'' +
                '}';
    }
}
