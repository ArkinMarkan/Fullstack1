-- Insert sample movies
INSERT INTO movies (movie_name, theatre_name, total_tickets, available_tickets, status, description, genre, language, duration, poster_url) 
VALUES 
('Avengers Endgame', 'PVR Cinemas', 100, 100, 'BOOK_ASAP', 'The final battle against Thanos', 'Action/Sci-Fi', 'English', 181, 'https://example.com/avengers-endgame-poster.jpg'),
('Avengers Endgame', 'INOX Multiplex', 150, 150, 'BOOK_ASAP', 'The final battle against Thanos', 'Action/Sci-Fi', 'English', 181, 'https://example.com/avengers-endgame-poster.jpg'),
('RRR', 'PVR Cinemas', 120, 120, 'BOOK_ASAP', 'A fictional story about Indian revolutionaries', 'Action/Drama', 'Telugu', 187, 'https://example.com/rrr-poster.jpg'),
('RRR', 'Cinepolis', 80, 80, 'BOOK_ASAP', 'A fictional story about Indian revolutionaries', 'Action/Drama', 'Telugu', 187, 'https://example.com/rrr-poster.jpg');

-- Insert sample users (password is bcrypt encoded for 'admin123' and 'password123')
-- Note: The actual encoded passwords need to be generated using bcrypt with strength 10
-- For admin123: $2a$10$xJrm8VNl3S0Sp7ub.IWj8eaKJjZNHhQD9X3iY6A.9sTsE.T.D5E16
-- For password123: $2a$10$kKW/U8xBKCv8zJoHhqK2HOTgQ4y6J0Ykl4jE8VxDpJgKQPJNpQhzq
INSERT INTO users (first_name, last_name, email, login_id, password, contact_number, role, enabled) 
VALUES 
('System', 'Administrator', 'admin@moviebooking.com', 'admin', '$2a$10$xJrm8VNl3S0Sp7ub.IWj8eaKJjZNHhQD9X3iY6A.9sTsE.T.D5E16', '9999999999', 'ADMIN', true),
('John', 'Doe', 'john.doe@example.com', 'john_doe', '$2a$10$kKW/U8xBKCv8zJoHhqK2HOTgQ4y6J0Ykl4jE8VxDpJgKQPJNpQhzq', '9876543210', 'USER', true);
