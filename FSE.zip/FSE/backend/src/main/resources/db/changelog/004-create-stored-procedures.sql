-- Stored procedures for common operations

DELIMITER //

-- Procedure to get movie statistics
CREATE PROCEDURE GetMovieStatistics()
BEGIN
    SELECT 
        m.movie_name,
        m.theatre_name,
        m.total_tickets,
        m.available_tickets,
        (m.total_tickets - m.available_tickets) as booked_tickets,
        ROUND((m.total_tickets - m.available_tickets) * 100.0 / m.total_tickets, 2) as occupancy_percentage,
        m.status,
        COUNT(t.id) as total_bookings,
        SUM(t.number_of_tickets) as total_tickets_booked
    FROM movies m
    LEFT JOIN tickets t ON m.movie_name = t.movie_name AND m.theatre_name = t.theatre_name AND t.status = 'CONFIRMED'
    GROUP BY m.movie_name, m.theatre_name, m.total_tickets, m.available_tickets, m.status
    ORDER BY occupancy_percentage DESC;
END //

-- Procedure to get user booking summary
CREATE PROCEDURE GetUserBookingSummary(IN user_login_id VARCHAR(50))
BEGIN
    SELECT 
        u.login_id,
        u.first_name,
        u.last_name,
        COUNT(t.id) as total_bookings,
        SUM(t.number_of_tickets) as total_tickets_booked,
        SUM(CASE WHEN t.status = 'CONFIRMED' THEN t.number_of_tickets ELSE 0 END) as confirmed_tickets,
        SUM(CASE WHEN t.status = 'CANCELLED' THEN t.number_of_tickets ELSE 0 END) as cancelled_tickets
    FROM users u
    LEFT JOIN tickets t ON u.login_id = t.user_login_id
    WHERE u.login_id = user_login_id
    GROUP BY u.login_id, u.first_name, u.last_name;
END //

-- Procedure to update movie availability after booking
CREATE PROCEDURE UpdateMovieAvailability(
    IN p_movie_name VARCHAR(255),
    IN p_theatre_name VARCHAR(255),
    IN p_tickets_booked INT
)
BEGIN
    DECLARE current_available INT DEFAULT 0;
    
    -- Get current available tickets
    SELECT available_tickets INTO current_available 
    FROM movies 
    WHERE movie_name = p_movie_name AND theatre_name = p_theatre_name;
    
    -- Update available tickets
    UPDATE movies 
    SET available_tickets = GREATEST(0, available_tickets - p_tickets_booked),
        status = CASE 
            WHEN (available_tickets - p_tickets_booked) <= 0 THEN 'SOLD_OUT' 
            ELSE 'BOOK_ASAP' 
        END,
        modified_date = CURRENT_TIMESTAMP
    WHERE movie_name = p_movie_name AND theatre_name = p_theatre_name;
    
END //

DELIMITER ;
