-- liquibase formatted sql

-- changeset moviebookingapp:001-create-initial-schema
-- comment: Create initial database schema for Movie Booking Application

-- Create Users table
CREATE TABLE users (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    login_id VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    contact_number VARCHAR(20) NOT NULL,
    role ENUM('USER', 'ADMIN') NOT NULL DEFAULT 'USER',
    account_non_expired BOOLEAN DEFAULT TRUE,
    account_non_locked BOOLEAN DEFAULT TRUE,
    credentials_non_expired BOOLEAN DEFAULT TRUE,
    enabled BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Create Movies table with composite primary key
CREATE TABLE movies (
    movie_name VARCHAR(100) NOT NULL,
    theatre_name VARCHAR(100) NOT NULL,
    id BIGINT AUTO_INCREMENT UNIQUE,
    total_tickets INTEGER NOT NULL CHECK (total_tickets >= 1),
    available_tickets INTEGER NOT NULL CHECK (available_tickets >= 0),
    status VARCHAR(20) DEFAULT 'BOOK_ASAP',
    description TEXT,
    genre VARCHAR(100),
    language VARCHAR(50),
    duration INTEGER,
    rating DECIMAL(3,1),
    release_date TIMESTAMP,
    ticket_price DECIMAL(10,2),
    poster_url VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (movie_name, theatre_name),
    CONSTRAINT chk_status CHECK (status IN ('BOOK_ASAP', 'SOLD_OUT')),
    CONSTRAINT chk_rating CHECK (rating >= 0 AND rating <= 10)
);

-- Create Movie Show Times table
CREATE TABLE movie_show_times (
    movie_name VARCHAR(100) NOT NULL,
    theatre_name VARCHAR(100) NOT NULL,
    show_time VARCHAR(20) NOT NULL,
    FOREIGN KEY (movie_name, theatre_name) REFERENCES movies(movie_name, theatre_name) ON DELETE CASCADE
);

-- Create Tickets table
CREATE TABLE tickets (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    movie_name VARCHAR(100) NOT NULL,
    theatre_name VARCHAR(100) NOT NULL,
    number_of_tickets INTEGER NOT NULL CHECK (number_of_tickets BETWEEN 1 AND 10),
    user_id BIGINT NOT NULL,
    user_login_id VARCHAR(50) NOT NULL,
    status ENUM('CONFIRMED', 'CANCELLED', 'PENDING') DEFAULT 'CONFIRMED',
    total_price DECIMAL(10,2),
    booking_reference VARCHAR(50),
    show_date_time TIMESTAMP,
    booking_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (movie_name, theatre_name) REFERENCES movies(movie_name, theatre_name) ON DELETE CASCADE
);

-- Create Ticket Seat Numbers table
CREATE TABLE ticket_seat_numbers (
    ticket_id BIGINT NOT NULL,
    seat_number VARCHAR(10) NOT NULL,
    FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE
);

-- Create Spring Session tables for session management
CREATE TABLE SPRING_SESSION (
    PRIMARY_ID CHAR(36) NOT NULL,
    SESSION_ID CHAR(36) NOT NULL,
    CREATION_TIME BIGINT NOT NULL,
    LAST_ACCESS_TIME BIGINT NOT NULL,
    MAX_INACTIVE_INTERVAL INT NOT NULL,
    EXPIRY_TIME BIGINT NOT NULL,
    PRINCIPAL_NAME VARCHAR(100),
    CONSTRAINT SPRING_SESSION_PK PRIMARY KEY (PRIMARY_ID)
);

CREATE UNIQUE INDEX SPRING_SESSION_IX1 ON SPRING_SESSION (SESSION_ID);
CREATE INDEX SPRING_SESSION_IX2 ON SPRING_SESSION (EXPIRY_TIME);
CREATE INDEX SPRING_SESSION_IX3 ON SPRING_SESSION (PRINCIPAL_NAME);

CREATE TABLE SPRING_SESSION_ATTRIBUTES (
    SESSION_PRIMARY_ID CHAR(36) NOT NULL,
    ATTRIBUTE_NAME VARCHAR(200) NOT NULL,
    ATTRIBUTE_BYTES LONGBLOB NOT NULL,
    CONSTRAINT SPRING_SESSION_ATTRIBUTES_PK PRIMARY KEY (SESSION_PRIMARY_ID, ATTRIBUTE_NAME),
    CONSTRAINT SPRING_SESSION_ATTRIBUTES_FK FOREIGN KEY (SESSION_PRIMARY_ID) REFERENCES SPRING_SESSION(PRIMARY_ID) ON DELETE CASCADE
);
