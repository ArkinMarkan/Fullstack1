-- liquibase formatted sql

-- changeset moviebookingapp:003-create-indexes
-- comment: Create database indexes for better performance

-- Index on movie search columns
CREATE INDEX idx_movies_name_theatre ON movies(movie_name, theatre_name);
CREATE INDEX idx_movies_status ON movies(status);
CREATE INDEX idx_movies_name ON movies(movie_name);
CREATE INDEX idx_movies_theatre ON movies(theatre_name);

-- Index on user search columns  
CREATE INDEX idx_users_login_id ON users(login_id);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_contact ON users(contact_number);
CREATE INDEX idx_users_role ON users(role);
CREATE INDEX idx_users_enabled ON users(enabled);

-- Index on ticket search columns
CREATE INDEX idx_tickets_user_login ON tickets(user_login_id);
CREATE INDEX idx_tickets_movie_theatre ON tickets(movie_name, theatre_name);
CREATE INDEX idx_tickets_booking_ref ON tickets(booking_reference);
CREATE INDEX idx_tickets_status ON tickets(status);
CREATE INDEX idx_tickets_booking_date ON tickets(booking_date);

-- Index on audit columns for all tables
CREATE INDEX idx_movies_created_at ON movies(created_at);
CREATE INDEX idx_movies_updated_at ON movies(updated_at);
CREATE INDEX idx_users_created_at ON users(created_at);
CREATE INDEX idx_users_updated_at ON users(updated_at);
CREATE INDEX idx_tickets_updated_at ON tickets(updated_at);
