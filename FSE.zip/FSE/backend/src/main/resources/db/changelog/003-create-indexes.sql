-- Create indexes for better performance

-- Index on movie search columns
CREATE INDEX idx_movies_name_theatre ON movies(movie_name, theatre_name);
CREATE INDEX idx_movies_status ON movies(status);
CREATE INDEX idx_movies_name ON movies(movie_name);
CREATE INDEX idx_movies_theatre ON movies(theatre_name);

-- Index on user search columns
CREATE INDEX idx_users_login_id ON users(login_id);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_contact ON users(contact_number);
CREATE INDEX idx_users_role ON users(role);
CREATE INDEX idx_users_enabled ON users(enabled);

-- Index on ticket search columns
CREATE INDEX idx_tickets_user_login ON tickets(user_login_id);
CREATE INDEX idx_tickets_movie_theatre ON tickets(movie_name, theatre_name);
CREATE INDEX idx_tickets_booking_ref ON tickets(booking_reference);
CREATE INDEX idx_tickets_status ON tickets(status);
CREATE INDEX idx_tickets_booking_date ON tickets(booking_date);

-- Index on audit columns for all tables
CREATE INDEX idx_movies_created_date ON movies(created_date);
CREATE INDEX idx_movies_modified_date ON movies(modified_date);
CREATE INDEX idx_users_created_date ON users(created_date);
CREATE INDEX idx_users_modified_date ON users(modified_date);
CREATE INDEX idx_tickets_created_date ON tickets(created_date);
CREATE INDEX idx_tickets_modified_date ON tickets(modified_date);
