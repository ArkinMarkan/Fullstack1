-- ===============================================
-- MOVIE BOOKING APPLICATION - FIXED DATABASE SETUP
-- ===============================================
-- Complete MySQL Database Setup Script - FIXED VERSION
-- Removes all problematic syntax issues
-- Date: December 16, 2025
-- ===============================================

-- STEP 1: CREATE DATABASE AND USER
-- ===============================================

-- Create the main database
CREATE DATABASE IF NOT EXISTS moviebookingdb 
    CHARACTER SET utf8mb4 
    COLLATE utf8mb4_unicode_ci;

-- Create application user with proper credentials (matching backend config)
CREATE USER IF NOT EXISTS 'movieapp'@'localhost' IDENTIFIED BY 'MovieApp123!';

-- Grant all privileges on moviebookingdb to the application user
GRANT ALL PRIVILEGES ON moviebookingdb.* TO 'movieapp'@'localhost';

-- Apply the privilege changes
FLUSH PRIVILEGES;

-- Switch to the moviebookingdb database
USE moviebookingdb;

-- ===============================================
-- STEP 2: CREATE CORE TABLES
-- ===============================================

-- 2.1 Create Users Table (for US_01 - Registration and Login)
-- ===============================================
CREATE TABLE users (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    login_id VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    contact_number VARCHAR(20) NOT NULL,
    role ENUM('USER', 'ADMIN') NOT NULL DEFAULT 'USER',
    account_non_expired BOOLEAN DEFAULT TRUE,
    account_non_locked BOOLEAN DEFAULT TRUE,
    credentials_non_expired BOOLEAN DEFAULT TRUE,
    enabled BOOLEAN DEFAULT TRUE,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    modified_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    -- Constraints for data validation
    CONSTRAINT chk_email_format CHECK (email REGEXP '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$'),
    CONSTRAINT chk_contact_format CHECK (contact_number REGEXP '^[0-9]{10,15}$'),
    CONSTRAINT chk_login_id_length CHECK (CHAR_LENGTH(login_id) >= 3)
);

-- 2.2 Create Movies Table (Core requirement - Composite Primary Key)
-- ===============================================
-- As per documentation: "Movie name and theatre name should be of composite primary key"
CREATE TABLE movies (
    -- Composite Primary Key fields (as per requirement)
    movie_name VARCHAR(100) NOT NULL,
    theatre_name VARCHAR(100) NOT NULL,
    
    -- Additional fields for movie management
    id BIGINT AUTO_INCREMENT UNIQUE,
    total_tickets INTEGER NOT NULL CHECK (total_tickets >= 1),
    available_tickets INTEGER NOT NULL CHECK (available_tickets >= 0),
    status VARCHAR(20) DEFAULT 'BOOK_ASAP',
    
    -- Extended movie information
    description TEXT,
    genre VARCHAR(100),
    language VARCHAR(50),
    duration INTEGER,
    rating DECIMAL(3,1),
    release_date TIMESTAMP,
    ticket_price DECIMAL(10,2) DEFAULT 250.00,
    poster_url VARCHAR(255),
    
    -- Audit fields
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    modified_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    -- Primary Key Constraint (Composite as per requirement)
    PRIMARY KEY (movie_name, theatre_name),
    
    -- Data validation constraints
    CONSTRAINT chk_status CHECK (status IN ('BOOK_ASAP', 'SOLD_OUT')),
    CONSTRAINT chk_rating CHECK (rating >= 0 AND rating <= 10),
    CONSTRAINT chk_available_tickets CHECK (available_tickets <= total_tickets),
    CONSTRAINT chk_ticket_price CHECK (ticket_price >= 0)
);

-- 2.3 Create Tickets Table (for US_03 - Book Tickets)
-- ===============================================
-- Foreign key relationship with Movies table as per requirement
CREATE TABLE tickets (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    
    -- Foreign key references to Movies table (composite key)
    movie_name VARCHAR(100) NOT NULL,
    theatre_name VARCHAR(100) NOT NULL,
    
    -- Ticket booking details
    number_of_tickets INTEGER NOT NULL CHECK (number_of_tickets >= 1 AND number_of_tickets <= 10),
    seat_numbers JSON,
    
    -- User information
    user_id BIGINT NOT NULL,
    user_login_id VARCHAR(50) NOT NULL,
    
    -- Booking details
    booking_reference VARCHAR(20) UNIQUE NOT NULL,
    status ENUM('CONFIRMED', 'CANCELLED', 'EXPIRED') DEFAULT 'CONFIRMED',
    total_price DECIMAL(10,2),
    booking_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- Audit fields
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    modified_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    -- Foreign key constraints
    FOREIGN KEY (movie_name, theatre_name) REFERENCES movies(movie_name, theatre_name) 
        ON DELETE RESTRICT ON UPDATE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) 
        ON DELETE RESTRICT ON UPDATE CASCADE,
    
    -- Additional constraints
    CONSTRAINT chk_booking_ref_format CHECK (booking_reference REGEXP '^MB[0-9]{10}$')
);

-- 2.4 Create Movie Show Times Table (Additional functionality)
-- ===============================================
CREATE TABLE movie_show_times (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    movie_name VARCHAR(100) NOT NULL,
    theatre_name VARCHAR(100) NOT NULL,
    show_time TIME NOT NULL,
    show_date DATE NOT NULL,
    screen_number VARCHAR(10),
    
    -- Foreign key to movies table
    FOREIGN KEY (movie_name, theatre_name) REFERENCES movies(movie_name, theatre_name) 
        ON DELETE CASCADE ON UPDATE CASCADE,
    
    -- Unique constraint to prevent duplicate shows
    UNIQUE KEY unique_show (movie_name, theatre_name, show_date, show_time)
);

CREATE TABLE ticket_seat_numbers ( ticket_id BIGINT NOT NULL, seat_number VARCHAR(50) NOT NULL, PRIMARY KEY (ticket_id, seat_number), FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE ON UPDATE CASCADE );

-- ===============================================
-- STEP 3: CREATE PERFORMANCE INDEXES
-- ===============================================

-- Indexes for Movies table
CREATE INDEX idx_movies_status ON movies(status);
CREATE INDEX idx_movies_genre ON movies(genre);
CREATE INDEX idx_movies_language ON movies(language);
CREATE INDEX idx_movies_rating ON movies(rating);
CREATE INDEX idx_movies_name ON movies(movie_name);
CREATE INDEX idx_movies_theatre ON movies(theatre_name);

-- Indexes for Users table
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_login_id ON users(login_id);
CREATE INDEX idx_users_role ON users(role);
CREATE INDEX idx_users_enabled ON users(enabled);
CREATE INDEX idx_users_contact ON users(contact_number);

-- Indexes for Tickets table
CREATE INDEX idx_tickets_user_id ON tickets(user_id);
CREATE INDEX idx_tickets_user_login ON tickets(user_login_id);
CREATE INDEX idx_tickets_movie_theatre ON tickets(movie_name, theatre_name);
CREATE INDEX idx_tickets_booking_ref ON tickets(booking_reference);
CREATE INDEX idx_tickets_status ON tickets(status);
CREATE INDEX idx_tickets_booking_date ON tickets(booking_date);

-- Indexes for audit columns (for reporting)
CREATE INDEX idx_movies_created ON movies(created_at);
CREATE INDEX idx_users_created ON users(created_at);
CREATE INDEX idx_tickets_created ON tickets(created_date);

-- ===============================================
-- STEP 4: INSERT SAMPLE DATA (As per requirement)
-- ===============================================
-- Requirement: "2 movies with 2 theatres assigned"

-- 4.1 Insert Sample Users
-- ===============================================
-- Admin user for US_04 (Admin functionality)
INSERT INTO users (first_name, last_name, email, login_id, password, contact_number, role) VALUES
('System', 'Administrator', 'admin@moviebooking.com', 'admin', 
 '$2a$10$xJrm8VNl3S0Sp7ub.IWj8eaKJjZNHhQD9X3iY6A.9sTsE.T.D5E16', -- Password: admin123
 '9999999999', 'ADMIN'),

-- Regular user for testing
('John', 'Doe', 'john.doe@example.com', 'john_doe', 
 '$2a$10$kKW/U8xBKCv8zJoHhqK2HOTgQ4y6J0Ykl4jE8VxDpJgKQPJNpQhzq', -- Password: password123
 '9876543210', 'USER'),

-- Additional test user
('Jane', 'Smith', 'jane.smith@example.com', 'jane_smith',
 '$2a$10$kKW/U8xBKCv8zJoHhqK2HOTgQ4y6J0Ykl4jE8VxDpJgKQPJNpQhzq', -- Password: password123
 '9876543211', 'USER');

-- 4.2 Insert Sample Movies (2 movies x 2 theatres = 4 entries)
-- ===============================================
-- Movie 1: Avengers Endgame in 2 theatres
INSERT INTO movies (movie_name, theatre_name, total_tickets, available_tickets, status, description, genre, language, duration, rating, ticket_price, poster_url) VALUES
('Avengers Endgame', 'PVR Cinemas', 100, 100, 'BOOK_ASAP', 
 'The final battle against Thanos in the epic conclusion to the Infinity Saga', 
 'Action/Sci-Fi', 'English', 181, 8.4, 350.00, 'https://example.com/avengers-endgame-poster.jpg'),

('Avengers Endgame', 'INOX Multiplex', 150, 150, 'BOOK_ASAP',
 'The final battle against Thanos in the epic conclusion to the Infinity Saga', 
 'Action/Sci-Fi', 'English', 181, 8.4, 400.00, 'https://example.com/avengers-endgame-poster.jpg'),

-- Movie 2: RRR in 2 theatres
('RRR', 'PVR Cinemas', 120, 120, 'BOOK_ASAP',
 'A fictional story about two legendary revolutionaries and their journey away from home before they started fighting for their country in the 1920s',
 'Action/Drama', 'Telugu', 187, 8.1, 300.00, 'https://example.com/rrr-poster.jpg'),

('RRR', 'Cinepolis', 80, 80, 'BOOK_ASAP',
 'A fictional story about two legendary revolutionaries and their journey away from home before they started fighting for their country in the 1920s',
 'Action/Drama', 'Telugu', 187, 8.1, 280.00, 'https://example.com/rrr-poster.jpg');

-- 4.3 Insert Sample Show Times
-- ===============================================
INSERT INTO movie_show_times (movie_name, theatre_name, show_time, show_date, screen_number) VALUES
-- Avengers Endgame shows
('Avengers Endgame', 'PVR Cinemas', '10:00:00', CURDATE(), 'Screen 1'),
('Avengers Endgame', 'PVR Cinemas', '14:00:00', CURDATE(), 'Screen 1'),
('Avengers Endgame', 'PVR Cinemas', '18:00:00', CURDATE(), 'Screen 1'),
('Avengers Endgame', 'PVR Cinemas', '21:30:00', CURDATE(), 'Screen 1'),

('Avengers Endgame', 'INOX Multiplex', '11:00:00', CURDATE(), 'Screen 2'),
('Avengers Endgame', 'INOX Multiplex', '15:30:00', CURDATE(), 'Screen 2'),
('Avengers Endgame', 'INOX Multiplex', '19:00:00', CURDATE(), 'Screen 2'),

-- RRR shows
('RRR', 'PVR Cinemas', '09:30:00', CURDATE(), 'Screen 3'),
('RRR', 'PVR Cinemas', '13:30:00', CURDATE(), 'Screen 3'),
('RRR', 'PVR Cinemas', '17:30:00', CURDATE(), 'Screen 3'),
('RRR', 'PVR Cinemas', '21:00:00', CURDATE(), 'Screen 3'),

('RRR', 'Cinepolis', '12:00:00', CURDATE(), 'Screen 1'),
('RRR', 'Cinepolis', '16:00:00', CURDATE(), 'Screen 1'),
('RRR', 'Cinepolis', '20:00:00', CURDATE(), 'Screen 1');

-- ===============================================
-- STEP 5: CREATE STORED PROCEDURES (SIMPLIFIED)
-- ===============================================

DELIMITER //

-- 5.1 Procedure to get movie statistics (for US_04 - Admin functionality)
CREATE PROCEDURE GetMovieStatistics()
BEGIN
    SELECT 
        m.movie_name,
        m.theatre_name,
        m.total_tickets,
        m.available_tickets,
        (m.total_tickets - m.available_tickets) as booked_tickets,
        ROUND((m.total_tickets - m.available_tickets) * 100.0 / m.total_tickets, 2) as occupancy_percentage,
        m.status,
        m.ticket_price,
        COUNT(t.id) as total_bookings,
        COALESCE(SUM(t.number_of_tickets), 0) as total_tickets_booked,
        COALESCE(SUM(t.total_price), 0) as total_revenue
    FROM movies m
    LEFT JOIN tickets t ON m.movie_name = t.movie_name 
                        AND m.theatre_name = t.theatre_name 
                        AND t.status = 'CONFIRMED'
    GROUP BY m.movie_name, m.theatre_name, m.total_tickets, m.available_tickets, m.status, m.ticket_price
    ORDER BY occupancy_percentage DESC;
END //

-- 5.2 Procedure to get user booking summary
CREATE PROCEDURE GetUserBookingSummary(IN user_login_id VARCHAR(50))
BEGIN
    SELECT 
        u.login_id,
        u.first_name,
        u.last_name,
        u.email,
        COUNT(t.id) as total_bookings,
        COALESCE(SUM(t.number_of_tickets), 0) as total_tickets_booked,
        SUM(CASE WHEN t.status = 'CONFIRMED' THEN t.number_of_tickets ELSE 0 END) as confirmed_tickets,
        SUM(CASE WHEN t.status = 'CANCELLED' THEN t.number_of_tickets ELSE 0 END) as cancelled_tickets,
        COALESCE(SUM(CASE WHEN t.status = 'CONFIRMED' THEN t.total_price ELSE 0 END), 0) as total_spent
    FROM users u
    LEFT JOIN tickets t ON u.id = t.user_id
    WHERE u.login_id = user_login_id
    GROUP BY u.id, u.login_id, u.first_name, u.last_name, u.email;
END //

-- 5.3 Procedure to update movie availability after booking (for ticket booking process)
CREATE PROCEDURE UpdateMovieAvailability(
    IN p_movie_name VARCHAR(100),
    IN p_theatre_name VARCHAR(100),
    IN p_tickets_booked INT
)
BEGIN
    DECLARE current_available INT DEFAULT 0;
    DECLARE new_available INT DEFAULT 0;
    
    -- Get current available tickets
    SELECT available_tickets INTO current_available 
    FROM movies 
    WHERE movie_name = p_movie_name AND theatre_name = p_theatre_name;
    
    -- Calculate new availability
    SET new_available = GREATEST(0, current_available - p_tickets_booked);
    
    -- Update movie availability and status
    UPDATE movies 
    SET 
        available_tickets = new_available,
        status = CASE 
            WHEN new_available <= 0 THEN 'SOLD_OUT' 
            ELSE 'BOOK_ASAP' 
        END,
        modified_date = CURRENT_TIMESTAMP
    WHERE movie_name = p_movie_name AND theatre_name = p_theatre_name;
    
    -- Return updated movie info
    SELECT 
        movie_name, 
        theatre_name, 
        total_tickets, 
        available_tickets, 
        status,
        CONCAT('Updated availability: ', new_available, ' tickets remaining') as message
    FROM movies 
    WHERE movie_name = p_movie_name AND theatre_name = p_theatre_name;
END //

-- 5.4 Function to generate unique booking reference (SIMPLIFIED)
CREATE FUNCTION GenerateBookingReference() 
RETURNS VARCHAR(20)
READS SQL DATA
DETERMINISTIC
BEGIN
    DECLARE booking_ref VARCHAR(20);
    DECLARE ref_exists INT DEFAULT 1;
    DECLARE counter INT DEFAULT 0;
    
    WHILE ref_exists > 0 AND counter < 100 DO
        SET booking_ref = CONCAT('MB', LPAD(FLOOR(RAND() * 10000000000), 10, '0'));
        SELECT COUNT(*) INTO ref_exists FROM tickets WHERE booking_reference = booking_ref;
        SET counter = counter + 1;
    END WHILE;
    
    RETURN booking_ref;
END //

DELIMITER ;

-- ===============================================
-- STEP 6: CREATE SIMPLIFIED TRIGGERS (BASIC VERSION)
-- ===============================================

DELIMITER //

-- 6.1 Trigger to automatically generate booking reference
CREATE TRIGGER tr_tickets_before_insert 
BEFORE INSERT ON tickets
FOR EACH ROW
BEGIN
    -- Generate unique booking reference if not provided
    IF NEW.booking_reference IS NULL OR NEW.booking_reference = '' THEN
        SET NEW.booking_reference = CONCAT('MB', UNIX_TIMESTAMP(), LPAD(NEW.user_id, 4, '0'));
    END IF;
    
    -- Calculate total amount based on ticket price and number of tickets
    IF NEW.total_price IS NULL THEN
        SET NEW.total_price = (
            SELECT ticket_price * NEW.number_of_tickets
            FROM movies 
            WHERE movie_name = NEW.movie_name AND theatre_name = NEW.theatre_name
            LIMIT 1
        );
    END IF;
END //

DELIMITER ;

-- ===============================================
-- STEP 7: CREATE VIEWS (For Easy Data Access)
-- ===============================================

-- 7.1 View for available movies (US_02 - View Movies)
CREATE VIEW vw_available_movies AS
SELECT 
    m.movie_name,
    m.theatre_name,
    m.total_tickets,
    m.available_tickets,
    m.status,
    m.description,
    m.genre,
    m.language,
    m.duration,
    m.rating,
    m.ticket_price,
    m.poster_url
FROM movies m
WHERE m.status = 'BOOK_ASAP' AND m.available_tickets > 0
ORDER BY m.movie_name, m.theatre_name;

-- 7.2 View for booking statistics (Admin dashboard)
CREATE VIEW vw_booking_statistics AS
SELECT 
    m.movie_name,
    m.theatre_name,
    m.total_tickets,
    m.available_tickets,
    (m.total_tickets - m.available_tickets) as tickets_sold,
    ROUND((m.total_tickets - m.available_tickets) * 100.0 / m.total_tickets, 2) as occupancy_rate,
    COUNT(t.id) as total_bookings,
    COALESCE(SUM(t.total_price), 0) as total_revenue,
    m.status
FROM movies m
LEFT JOIN tickets t ON m.movie_name = t.movie_name 
                    AND m.theatre_name = t.theatre_name 
                    AND t.status = 'CONFIRMED'
GROUP BY m.movie_name, m.theatre_name, m.total_tickets, m.available_tickets, m.status
ORDER BY occupancy_rate DESC, total_revenue DESC;

-- ===============================================
-- STEP 8: VERIFICATION QUERIES
-- ===============================================

-- 8.1 Verify table structure
SELECT 'Tables created successfully' as Status;
SHOW TABLES;

-- 8.2 Verify sample data
SELECT 'Sample data verification' as Status;
SELECT COUNT(*) as users_count FROM users;
SELECT COUNT(*) as movies_count FROM movies;
SELECT COUNT(*) as show_times_count FROM movie_show_times;

-- 8.3 Verify composite primary key
SELECT 'Composite Primary Key verification' as Status;
SHOW INDEX FROM movies WHERE Key_name = 'PRIMARY';

-- 8.4 Verify foreign key relationships
SELECT 'Foreign Key constraints verification' as Status;
SELECT 
    CONSTRAINT_NAME,
    TABLE_NAME,
    COLUMN_NAME,
    REFERENCED_TABLE_NAME,
    REFERENCED_COLUMN_NAME
FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
WHERE REFERENCED_TABLE_SCHEMA = 'moviebookingdb'
AND REFERENCED_TABLE_NAME IS NOT NULL;

-- ===============================================
-- STEP 9: SECURITY SETUP
-- ===============================================

-- 9.1 Create read-only user for reporting
CREATE USER IF NOT EXISTS 'movieapp_readonly'@'localhost' IDENTIFIED BY 'ReadOnly123!';
GRANT SELECT ON moviebookingdb.* TO 'movieapp_readonly'@'localhost';

-- 9.2 Create backup user
CREATE USER IF NOT EXISTS 'movieapp_backup'@'localhost' IDENTIFIED BY 'Backup123!';
GRANT SELECT, LOCK TABLES ON moviebookingdb.* TO 'movieapp_backup'@'localhost';

-- Apply security changes
FLUSH PRIVILEGES;

-- ===============================================
-- SETUP COMPLETE
-- ===============================================

SELECT 'Movie Booking Database Setup Completed Successfully!' as Status;
SELECT 'Database: moviebookingdb' as Info;
SELECT 'Tables: users, movies (composite PK), tickets, movie_show_times' as Tables;
SELECT 'Sample Data: 3 users, 4 movie entries (2 movies x 2 theatres)' as SampleData;
SELECT 'Features: Stored procedures, triggers, views, indexes' as Features;
SELECT 'Users: movieapp (main), movieapp_readonly (reports), movieapp_backup (backup)' as DatabaseUsers;

-- Test login credentials:
-- Admin: admin / admin123
-- User: john_doe / password123
-- User: jane_smith / password123
