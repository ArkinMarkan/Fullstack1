-- =============================================================================
-- MOVIE BOOKING APPLICATION - COMPLETE DATABASE SETUP SCRIPT
-- =============================================================================
-- This script creates a complete MySQL database with all necessary tables,
-- sample data, indexes, stored procedures, triggers, and views.
-- =============================================================================

-- 1. DATABASE SETUP
-- =================
DROP DATABASE IF EXISTS movie_booking_app;
CREATE DATABASE movie_booking_app CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE movie_booking_app;

-- 2. CREATE TABLES
-- ================

-- 2.1 Users Table
CREATE TABLE users (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    login_id VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    contact_number VARCHAR(20) NOT NULL,
    role ENUM('USER', 'ADMIN') NOT NULL DEFAULT 'USER',
    account_non_expired BOOLEAN DEFAULT TRUE,
    account_non_locked BOOLEAN DEFAULT TRUE,
    credentials_non_expired BOOLEAN DEFAULT TRUE,
    enabled BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    -- Constraints for data validation
    CONSTRAINT chk_email_format CHECK (email REGEXP '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$'),
    CONSTRAINT chk_contact_format CHECK (contact_number REGEXP '^[0-9]{10,15}$'),
    CONSTRAINT chk_login_id_length CHECK (CHAR_LENGTH(login_id) >= 3)
);

-- 2.2 Movies Table (Composite Primary Key as per requirement)
CREATE TABLE movies (
    -- Composite Primary Key fields
    movie_name VARCHAR(100) NOT NULL,
    theatre_name VARCHAR(100) NOT NULL,
    
    -- Additional fields
    id BIGINT AUTO_INCREMENT UNIQUE,
    total_tickets INTEGER NOT NULL CHECK (total_tickets >= 1),
    available_tickets INTEGER NOT NULL CHECK (available_tickets >= 0),
    status VARCHAR(20) DEFAULT 'BOOK_ASAP',
    description TEXT,
    genre VARCHAR(100),
    language VARCHAR(50),
    duration INTEGER,
    rating DECIMAL(3,1),
    release_date TIMESTAMP,
    ticket_price DECIMAL(10,2) DEFAULT 250.00,
    poster_url VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    -- Primary Key Constraint (Composite as per requirement)
    PRIMARY KEY (movie_name, theatre_name),
    
    -- Data validation constraints
    CONSTRAINT chk_status CHECK (status IN ('BOOK_ASAP', 'SOLD_OUT')),
    CONSTRAINT chk_rating CHECK (rating >= 0 AND rating <= 10),
    CONSTRAINT chk_available_tickets CHECK (available_tickets <= total_tickets),
    CONSTRAINT chk_ticket_price CHECK (ticket_price >= 0)
);

-- 2.3 Movie Show Times Table
CREATE TABLE movie_show_times (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    movie_name VARCHAR(100) NOT NULL,
    theatre_name VARCHAR(100) NOT NULL,
    show_time TIME NOT NULL,
    show_date DATE NOT NULL,
    screen_number VARCHAR(10),
    
    FOREIGN KEY (movie_name, theatre_name) REFERENCES movies(movie_name, theatre_name) 
        ON DELETE CASCADE ON UPDATE CASCADE,
    
    UNIQUE KEY unique_show (movie_name, theatre_name, show_date, show_time)
);

-- 2.4 Tickets Table
CREATE TABLE tickets (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    movie_name VARCHAR(100) NOT NULL,
    theatre_name VARCHAR(100) NOT NULL,
    number_of_tickets INTEGER NOT NULL CHECK (number_of_tickets >= 1 AND number_of_tickets <= 10),
    user_id BIGINT NOT NULL,
    user_login_id VARCHAR(50) NOT NULL,
    booking_reference VARCHAR(20) UNIQUE NOT NULL,
    status ENUM('CONFIRMED', 'CANCELLED', 'EXPIRED') DEFAULT 'CONFIRMED',
    total_amount DECIMAL(10,2),
    show_date_time TIMESTAMP,
    booking_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    -- Foreign key constraints
    FOREIGN KEY (movie_name, theatre_name) REFERENCES movies(movie_name, theatre_name) 
        ON DELETE RESTRICT ON UPDATE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) 
        ON DELETE RESTRICT ON UPDATE CASCADE,
    
    -- Additional constraints
    CONSTRAINT chk_booking_ref_format CHECK (booking_reference REGEXP '^MB[0-9]{10}$')
);

-- 2.5 Ticket Seat Numbers Table
CREATE TABLE ticket_seat_numbers (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    ticket_id BIGINT NOT NULL,
    seat_number VARCHAR(10) NOT NULL,
    
    FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE,
    UNIQUE KEY unique_seat_per_ticket (ticket_id, seat_number)
);

-- 2.6 Spring Session Tables (for session management)
CREATE TABLE SPRING_SESSION (
    PRIMARY_ID CHAR(36) NOT NULL,
    SESSION_ID CHAR(36) NOT NULL,
    CREATION_TIME BIGINT NOT NULL,
    LAST_ACCESS_TIME BIGINT NOT NULL,
    MAX_INACTIVE_INTERVAL INT NOT NULL,
    EXPIRY_TIME BIGINT NOT NULL,
    PRINCIPAL_NAME VARCHAR(100),
    CONSTRAINT SPRING_SESSION_PK PRIMARY KEY (PRIMARY_ID)
);

CREATE TABLE SPRING_SESSION_ATTRIBUTES (
    SESSION_PRIMARY_ID CHAR(36) NOT NULL,
    ATTRIBUTE_NAME VARCHAR(200) NOT NULL,
    ATTRIBUTE_BYTES LONGBLOB NOT NULL,
    CONSTRAINT SPRING_SESSION_ATTRIBUTES_PK PRIMARY KEY (SESSION_PRIMARY_ID, ATTRIBUTE_NAME),
    CONSTRAINT SPRING_SESSION_ATTRIBUTES_FK FOREIGN KEY (SESSION_PRIMARY_ID) 
        REFERENCES SPRING_SESSION(PRIMARY_ID) ON DELETE CASCADE
);

-- 3. CREATE INDEXES FOR PERFORMANCE
-- ==================================

-- Users table indexes
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_login_id ON users(login_id);
CREATE INDEX idx_users_role ON users(role);

-- Movies table indexes
CREATE INDEX idx_movies_status ON movies(status);
CREATE INDEX idx_movies_genre ON movies(genre);
CREATE INDEX idx_movies_language ON movies(language);
CREATE INDEX idx_movies_rating ON movies(rating);
CREATE INDEX idx_movies_release_date ON movies(release_date);

-- Tickets table indexes
CREATE INDEX idx_tickets_user_id ON tickets(user_id);
CREATE INDEX idx_tickets_booking_date ON tickets(booking_date);
CREATE INDEX idx_tickets_status ON tickets(status);
CREATE INDEX idx_tickets_movie_theatre ON tickets(movie_name, theatre_name);

-- Spring Session indexes
CREATE UNIQUE INDEX SPRING_SESSION_IX1 ON SPRING_SESSION (SESSION_ID);
CREATE INDEX SPRING_SESSION_IX2 ON SPRING_SESSION (EXPIRY_TIME);
CREATE INDEX SPRING_SESSION_IX3 ON SPRING_SESSION (PRINCIPAL_NAME);

-- 4. INSERT SAMPLE DATA
-- =====================

-- 4.1 Sample Users (US_01 - User Registration)
INSERT INTO users (first_name, last_name, email, login_id, password, contact_number, role) VALUES
-- Regular users (password is BCrypt encoded for 'password123')
('John', 'Doe', 'john.doe@email.com', 'johndoe', '$2a$10$Xl0yhvzLIaJCDdKBS.Gx/.Gb67YzXHmnLQ5b/5iu9KpF6/T2HFDwm', '9876543210', 'USER'),
('Jane', 'Smith', 'jane.smith@email.com', 'janesmith', '$2a$10$Xl0yhvzLIaJCDdKBS.Gx/.Gb67YzXHmnLQ5b/5iu9KpF6/T2HFDwm', '8765432109', 'USER'),
('Mike', 'Johnson', 'mike.johnson@email.com', 'mikejohnson', '$2a$10$Xl0yhvzLIaJCDdKBS.Gx/.Gb67YzXHmnLQ5b/5iu9KpF6/T2HFDwm', '7654321098', 'USER'),

-- Admin user (password is BCrypt encoded for 'admin123')
('Admin', 'User', 'admin@moviebooking.com', 'admin', '$2a$10$Xl0yhvzLIaJCDdKBS.Gx/.Gb67YzXHmnLQ5b/5iu9KpF6/T2HFDwm', '9999999999', 'ADMIN');

-- 4.2 Sample Movies (US_02 - View All Movies, as per requirement: 2 movies in 2 theatres)
INSERT INTO movies (movie_name, theatre_name, total_tickets, available_tickets, status, description, genre, language, duration, rating, release_date, ticket_price, poster_url) VALUES
-- Movie 1 in Theatre 1
('Avengers: Endgame', 'PVR Cinemas', 100, 85, 'BOOK_ASAP', 
 'The culmination of the Marvel Cinematic Universe saga', 'Action/Adventure', 'English', 181, 8.4, 
 '2019-04-26 00:00:00', 350.00, 'https://example.com/avengers-endgame.jpg'),

-- Movie 1 in Theatre 2  
('Avengers: Endgame', 'INOX Multiplex', 120, 95, 'BOOK_ASAP', 
 'The culmination of the Marvel Cinematic Universe saga', 'Action/Adventure', 'English', 181, 8.4, 
 '2019-04-26 00:00:00', 320.00, 'https://example.com/avengers-endgame.jpg'),

-- Movie 2 in Theatre 1
('Spider-Man: No Way Home', 'PVR Cinemas', 80, 60, 'BOOK_ASAP', 
 'Spider-Man faces his greatest challenge yet in this multiverse adventure', 'Action/Adventure', 'English', 148, 8.2, 
 '2021-12-17 00:00:00', 300.00, 'https://example.com/spiderman-no-way-home.jpg'),

-- Movie 2 in Theatre 2
('Spider-Man: No Way Home', 'INOX Multiplex', 100, 75, 'BOOK_ASAP', 
 'Spider-Man faces his greatest challenge yet in this multiverse adventure', 'Action/Adventure', 'English', 148, 8.2, 
 '2021-12-17 00:00:00', 280.00, 'https://example.com/spiderman-no-way-home.jpg');

-- 4.3 Sample Show Times
INSERT INTO movie_show_times (movie_name, theatre_name, show_time, show_date, screen_number) VALUES
-- Avengers: Endgame shows
('Avengers: Endgame', 'PVR Cinemas', '10:00:00', '2024-02-15', 'Screen 1'),
('Avengers: Endgame', 'PVR Cinemas', '14:30:00', '2024-02-15', 'Screen 1'),
('Avengers: Endgame', 'PVR Cinemas', '19:00:00', '2024-02-15', 'Screen 1'),
('Avengers: Endgame', 'INOX Multiplex', '11:00:00', '2024-02-15', 'Screen 2'),
('Avengers: Endgame', 'INOX Multiplex', '15:30:00', '2024-02-15', 'Screen 2'),
('Avengers: Endgame', 'INOX Multiplex', '20:00:00', '2024-02-15', 'Screen 2'),

-- Spider-Man: No Way Home shows
('Spider-Man: No Way Home', 'PVR Cinemas', '09:30:00', '2024-02-15', 'Screen 3'),
('Spider-Man: No Way Home', 'PVR Cinemas', '13:00:00', '2024-02-15', 'Screen 3'),
('Spider-Man: No Way Home', 'PVR Cinemas', '17:30:00', '2024-02-15', 'Screen 3'),
('Spider-Man: No Way Home', 'INOX Multiplex', '10:30:00', '2024-02-15', 'Screen 4'),
('Spider-Man: No Way Home', 'INOX Multiplex', '14:00:00', '2024-02-15', 'Screen 4'),
('Spider-Man: No Way Home', 'INOX Multiplex', '18:30:00', '2024-02-15', 'Screen 4');

-- 4.4 Sample Tickets (US_03 - Book Tickets)
INSERT INTO tickets (movie_name, theatre_name, number_of_tickets, user_id, user_login_id, booking_reference, status, total_amount, show_date_time) VALUES
('Avengers: Endgame', 'PVR Cinemas', 2, 1, 'johndoe', 'MB1234567890', 'CONFIRMED', 700.00, '2024-02-15 19:00:00'),
('Spider-Man: No Way Home', 'INOX Multiplex', 3, 2, 'janesmith', 'MB1234567891', 'CONFIRMED', 840.00, '2024-02-15 18:30:00'),
('Avengers: Endgame', 'INOX Multiplex', 1, 3, 'mikejohnson', 'MB1234567892', 'CONFIRMED', 320.00, '2024-02-15 20:00:00');

-- 4.5 Sample Seat Numbers
INSERT INTO ticket_seat_numbers (ticket_id, seat_number) VALUES
(1, 'A1'), (1, 'A2'),
(2, 'B5'), (2, 'B6'), (2, 'B7'),
(3, 'C10');

-- 5. CREATE STORED PROCEDURES
-- ============================

DELIMITER //

-- 5.1 Procedure to get available movies
CREATE PROCEDURE GetAvailableMovies()
BEGIN
    SELECT 
        movie_name,
        theatre_name,
        total_tickets,
        available_tickets,
        status,
        genre,
        language,
        duration,
        rating,
        ticket_price,
        poster_url,
        release_date
    FROM movies 
    WHERE status = 'BOOK_ASAP' AND available_tickets > 0
    ORDER BY movie_name, theatre_name;
END //

-- 5.2 Procedure to book tickets
CREATE PROCEDURE BookTickets(
    IN p_movie_name VARCHAR(100),
    IN p_theatre_name VARCHAR(100),
    IN p_user_id BIGINT,
    IN p_user_login_id VARCHAR(50),
    IN p_number_of_tickets INT,
    IN p_booking_reference VARCHAR(20),
    OUT p_result VARCHAR(100)
)
BEGIN
    DECLARE available_count INT DEFAULT 0;
    DECLARE ticket_price_val DECIMAL(10,2) DEFAULT 0;
    DECLARE total_amount_val DECIMAL(10,2) DEFAULT 0;
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SET p_result = 'BOOKING_FAILED';
    END;
    
    START TRANSACTION;
    
    -- Check available tickets
    SELECT available_tickets, ticket_price
    INTO available_count, ticket_price_val
    FROM movies
    WHERE movie_name = p_movie_name AND theatre_name = p_theatre_name
    FOR UPDATE;
    
    IF available_count >= p_number_of_tickets THEN
        -- Calculate total amount
        SET total_amount_val = ticket_price_val * p_number_of_tickets;
        
        -- Update available tickets
        UPDATE movies 
        SET available_tickets = available_tickets - p_number_of_tickets
        WHERE movie_name = p_movie_name AND theatre_name = p_theatre_name;
        
        -- Insert ticket booking
        INSERT INTO tickets (movie_name, theatre_name, number_of_tickets, user_id, user_login_id, 
                           booking_reference, total_amount)
        VALUES (p_movie_name, p_theatre_name, p_number_of_tickets, p_user_id, p_user_login_id, 
                p_booking_reference, total_amount_val);
        
        COMMIT;
        SET p_result = 'BOOKING_SUCCESSFUL';
    ELSE
        ROLLBACK;
        SET p_result = 'INSUFFICIENT_TICKETS';
    END IF;
END //

-- 5.3 Procedure to get user bookings
CREATE PROCEDURE GetUserBookings(IN p_user_id BIGINT)
BEGIN
    SELECT 
        t.id as ticket_id,
        t.movie_name,
        t.theatre_name,
        t.number_of_tickets,
        t.booking_reference,
        t.status,
        t.total_amount,
        t.show_date_time,
        t.booking_date,
        GROUP_CONCAT(ts.seat_number) as seat_numbers
    FROM tickets t
    LEFT JOIN ticket_seat_numbers ts ON t.id = ts.ticket_id
    WHERE t.user_id = p_user_id
    GROUP BY t.id
    ORDER BY t.booking_date DESC;
END //

DELIMITER ;

-- 6. CREATE TRIGGERS
-- ===================

DELIMITER //

-- 6.1 Trigger to update movie status when tickets are sold out
CREATE TRIGGER update_movie_status_after_booking
    AFTER UPDATE ON movies
    FOR EACH ROW
BEGIN
    IF NEW.available_tickets = 0 AND OLD.available_tickets > 0 THEN
        UPDATE movies 
        SET status = 'SOLD_OUT' 
        WHERE movie_name = NEW.movie_name AND theatre_name = NEW.theatre_name;
    ELSEIF NEW.available_tickets > 0 AND OLD.available_tickets = 0 THEN
        UPDATE movies 
        SET status = 'BOOK_ASAP' 
        WHERE movie_name = NEW.movie_name AND theatre_name = NEW.theatre_name;
    END IF;
END //

-- 6.2 Trigger to validate ticket booking
CREATE TRIGGER validate_ticket_booking
    BEFORE INSERT ON tickets
    FOR EACH ROW
BEGIN
    DECLARE available_count INT;
    
    SELECT available_tickets INTO available_count
    FROM movies
    WHERE movie_name = NEW.movie_name AND theatre_name = NEW.theatre_name;
    
    IF available_count < NEW.number_of_tickets THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Not enough tickets available';
    END IF;
END //

DELIMITER ;

-- 7. CREATE VIEWS FOR REPORTING
-- ==============================

-- 7.1 View for movie summary
CREATE VIEW movie_summary AS
SELECT 
    m.movie_name,
    m.theatre_name,
    m.total_tickets,
    m.available_tickets,
    (m.total_tickets - m.available_tickets) as tickets_sold,
    ROUND(((m.total_tickets - m.available_tickets) * 100.0 / m.total_tickets), 2) as occupancy_percentage,
    m.status,
    m.genre,
    m.language,
    m.rating,
    m.ticket_price,
    COUNT(DISTINCT t.id) as total_bookings,
    COALESCE(SUM(t.total_amount), 0) as total_revenue
FROM movies m
LEFT JOIN tickets t ON m.movie_name = t.movie_name AND m.theatre_name = t.theatre_name
GROUP BY m.movie_name, m.theatre_name;

-- 7.2 View for user booking summary
CREATE VIEW user_booking_summary AS
SELECT 
    u.id as user_id,
    u.first_name,
    u.last_name,
    u.email,
    u.login_id,
    COUNT(t.id) as total_bookings,
    SUM(t.number_of_tickets) as total_tickets_booked,
    COALESCE(SUM(t.total_amount), 0) as total_spent
FROM users u
LEFT JOIN tickets t ON u.id = t.user_id AND t.status = 'CONFIRMED'
GROUP BY u.id;

-- 7.3 View for daily booking report
CREATE VIEW daily_booking_report AS
SELECT 
    DATE(t.booking_date) as booking_date,
    COUNT(t.id) as total_bookings,
    SUM(t.number_of_tickets) as total_tickets,
    SUM(t.total_amount) as total_revenue,
    COUNT(DISTINCT t.user_id) as unique_customers
FROM tickets t
WHERE t.status = 'CONFIRMED'
GROUP BY DATE(t.booking_date)
ORDER BY booking_date DESC;

-- 8. VERIFICATION QUERIES
-- ========================

-- Display created tables
SHOW TABLES;

-- Verify sample data
SELECT 'Users' as Table_Name, COUNT(*) as Record_Count FROM users
UNION ALL
SELECT 'Movies', COUNT(*) FROM movies
UNION ALL
SELECT 'Movie Show Times', COUNT(*) FROM movie_show_times
UNION ALL
SELECT 'Tickets', COUNT(*) FROM tickets
UNION ALL
SELECT 'Ticket Seat Numbers', COUNT(*) FROM ticket_seat_numbers;

-- Display sample movies with composite keys
SELECT movie_name, theatre_name, available_tickets, status, ticket_price 
FROM movies 
ORDER BY movie_name, theatre_name;

-- Display sample bookings
SELECT t.booking_reference, t.movie_name, t.theatre_name, t.number_of_tickets, 
       u.first_name, u.last_name, t.total_amount
FROM tickets t
JOIN users u ON t.user_id = u.id;

-- =============================================================================
-- DATABASE SETUP COMPLETED SUCCESSFULLY!
-- =============================================================================
-- 
-- Summary of created objects:
-- - 6 Tables: users, movies, movie_show_times, tickets, ticket_seat_numbers, spring_session tables
-- - Multiple indexes for performance optimization
-- - Sample data: 4 users, 4 movies (2 movies in 2 theatres), show times, and sample bookings
-- - 3 Stored procedures for common operations
-- - 2 Triggers for data validation and status updates
-- - 3 Views for reporting and analytics
-- 
-- The database is now ready for the Movie Booking Application!
-- =============================================================================
