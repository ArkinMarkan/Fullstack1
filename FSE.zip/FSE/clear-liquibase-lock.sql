-- Clear Liquibase locks and reset if needed
-- Run this script if you encounter Liquibase lock issues

-- Delete lock records
DELETE FROM moviebookingdb.databasechangeloglock;

-- Mark problematic changesets as executed if they were partially run
-- This prevents re-execution of changesets that may have partially succeeded

-- Show current changelog entries
SELECT * FROM moviebookingdb.databasechangelog;

-- Optional: If you need to mark the sample data changeset as executed 
-- (only run this if the data actually exists but Liquibase thinks it hasn't been executed)
-- INSERT INTO moviebookingdb.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, EXECTYPE, MD5SUM, DESCRIPTION, COMMENTS, TAG, LIQUIBASE, CONTEXTS, LABELS, DEPLOYMENT_ID)
-- VALUES ('002-insert-sample-data', 'moviebookingapp', 'db/changelog/002-insert-sample-data.sql', NOW(), 2, 'EXECUTED', '8:some-hash', 'Insert sample data for testing', '', NULL, '4.24.0', NULL, NULL, '1234567890');
