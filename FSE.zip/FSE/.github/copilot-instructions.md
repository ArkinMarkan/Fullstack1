# Movie Booking Application - Copilot Instructions

<!-- Use this file to provide workspace-specific custom instructions to Copilot. For more details, visit https://code.visualstudio.com/docs/copilot/copilot-customization#_use-a-githubcopilotinstructionsmd-file -->

## Project Overview
This is a full-stack Movie Booking Application with the following stack:
- **Backend**: Spring Boot 3.x with Java 17+, MongoDB, Spring Security with JWT
- **Frontend**: React 18+ with TypeScript, Material-UI, Axios
- **Testing**: JUnit 5, Mockito, Jest, React Testing Library
- **Build**: Maven for backend, npm/yarn for frontend
- **Containerization**: Docker and Docker Compose

## Architecture Guidelines
- Follow RESTful API design principles
- Implement role-based authentication (USER, ADMIN)
- Use Repository pattern for data access
- Follow clean architecture principles
- Implement proper error handling and logging

## Code Standards
- Use camelCase for Java methods and variables
- Use PascalCase for Java classes
- Use kebab-case for REST endpoint URLs
- Follow Spring Boot naming conventions
- Implement comprehensive unit tests (80%+ coverage)
- Use proper validation annotations
- Implement proper exception handling

## Package Structure
```
com.moviebookingapp
├── controller/     # REST controllers
├── service/        # Business logic
├── repository/     # Data access layer
├── model/          # Entity classes
├── dto/            # Data Transfer Objects
├── config/         # Configuration classes
├── security/       # Authentication & authorization
├── exception/      # Custom exceptions
└── util/           # Utility classes
```

## Key Features to Implement
- User registration and login
- JWT-based authentication
- Movie CRUD operations
- Ticket booking system
- Admin dashboard
- Search functionality
- Cache management
- Session management
