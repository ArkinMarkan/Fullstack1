# Database Setup Guide

## Quick Setup (Recommended)

1. **Start MySQL Server**
   ```powershell
   # If MySQL is installed as a service
   net start mysql
   
   # Or if using XAMPP/WAMP
   # Start MySQL through the control panel
   ```

2. **Run the Clean Setup Script**
   ```powershell
   mysql -u root -p < database-setup-clean.sql
   ```

3. **Verify Setup**
   ```powershell
   mysql -u root -p -e "USE movie_booking_app; SHOW TABLES;"
   ```

## Manual Setup

If you prefer to run the script manually:

1. **Connect to MySQL**
   ```powershell
   mysql -u root -p
   ```

2. **Run the script**
   ```sql
   source C:\Users\2268594\Downloads\FSE\database-setup-clean.sql
   ```

## Verification

After running the setup, verify that everything is created correctly:

```sql
USE movie_booking_app;

-- Check tables
SHOW TABLES;

-- Check sample data
SELECT COUNT(*) as user_count FROM users;
SELECT COUNT(*) as movie_count FROM movies;
SELECT COUNT(*) as ticket_count FROM tickets;

-- View movies with composite keys
SELECT movie_name, theatre_name, available_tickets, status 
FROM movies;
```

## Connection Details for Application

Update your `application-mysql.properties` with:
```properties
spring.datasource.url=jdbc:mysql://localhost:3306/movie_booking_app
spring.datasource.username=root
spring.datasource.password=your_mysql_password
spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver
```

## Sample Login Credentials

After setup, you can test with these accounts:

**Regular Users:**
- Login ID: `johndoe` | Password: `password123`
- Login ID: `janesmith` | Password: `password123`
- Login ID: `mikejohnson` | Password: `password123`

**Admin User:**
- Login ID: `admin` | Password: `admin123`

## Troubleshooting

### If you get "Access denied" error:
```powershell
mysql -u root -p --default-character-set=utf8mb4 < database-setup-clean.sql
```

### If you get "Unknown database" error:
The script creates the database, so this should not happen. If it does, run:
```sql
CREATE DATABASE movie_booking_app;
```

### If foreign key constraints fail:
Make sure to run the complete script in order, as it creates tables in the correct dependency order.
