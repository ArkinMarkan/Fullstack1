# Maven Dependencies Fix Guide

## 🚨 Problem: "Archive cannot be read or is not a valid zip file"

This error typically occurs due to corrupted Maven dependencies, cache issues, or IDE configuration problems.

## 🔧 **Quick Fix (Recommended)**

### **Windows:**
```powershell
# Run the fix script
fix-maven-dependencies.bat
```

### **Linux/Mac:**
```bash
# Run the fix script
chmod +x fix-maven-dependencies.sh
./fix-maven-dependencies.sh
```

## 🛠️ **Manual Fix Steps**

### **Step 1: Clean Maven Project**
```powershell
cd backend
mvn clean
```

### **Step 2: Clear Maven Cache**
```powershell
# Windows
rmdir /s /q "%USERPROFILE%\.m2\repository\com\mysql"
rmdir /s /q "%USERPROFILE%\.m2\repository\io\jsonwebtoken"

# Linux/Mac
rm -rf ~/.m2/repository/com/mysql
rm -rf ~/.m2/repository/io/jsonwebtoken
```

### **Step 3: Force Refresh Dependencies**
```powershell
mvn dependency:purge-local-repository
mvn dependency:resolve -U
mvn dependency:resolve-sources
```

### **Step 4: Recompile**
```powershell
mvn clean compile
```

## 🔍 **IDE-Specific Fixes**

### **IntelliJ IDEA:**
1. **File → Invalidate Caches and Restart**
2. **File → Settings → Build Tools → Maven → Refresh**
3. **Right-click on project → Maven → Reload project**
4. **File → Project Structure → Check Java SDK is set to 17**

### **VS Code:**
1. **Ctrl+Shift+P → Java: Refresh Projects**
2. **Ctrl+Shift+P → Java: Rebuild Projects**
3. **Check Java extension is installed and updated**

### **Eclipse:**
1. **Right-click project → Maven → Update Project**
2. **Project → Clean → Clean all projects**
3. **Check Build Path → Libraries → Check Maven Dependencies**

## ⚙️ **Configuration Verification**

### **Check Java Version:**
```powershell
java -version
# Should show Java 17.x.x
```

### **Check Maven Version:**
```powershell
mvn -version
# Should show Maven 3.6+ and Java 17
```

### **Check Environment Variables:**
```powershell
# Windows
echo %JAVA_HOME%
echo %MAVEN_HOME%

# Linux/Mac
echo $JAVA_HOME
echo $MAVEN_HOME
```

## 🚀 **Alternative Solutions**

### **Solution 1: Fresh Maven Repository**
```powershell
# Backup your settings
# Windows
move "%USERPROFILE%\.m2\settings.xml" "%USERPROFILE%\.m2\settings.xml.backup"

# Remove entire repository
rmdir /s /q "%USERPROFILE%\.m2\repository"

# Re-download everything
mvn dependency:resolve
```

### **Solution 2: Use Maven Wrapper**
```powershell
# If mvnw exists in project root
.\mvnw clean compile

# On Linux/Mac
./mvnw clean compile
```

### **Solution 3: Specific Dependency Fix**
Add explicit version management in pom.xml:
```xml
<dependencyManagement>
    <dependencies>
        <dependency>
            <groupId>com.mysql</groupId>
            <artifactId>mysql-connector-j</artifactId>
            <version>8.2.0</version>
        </dependency>
    </dependencies>
</dependencyManagement>
```

## 🔬 **Debugging Steps**

### **Check Dependency Tree:**
```powershell
mvn dependency:tree
mvn dependency:analyze
```

### **Validate Dependencies:**
```powershell
mvn validate
mvn dependency:resolve-sources
```

### **Check for Conflicts:**
```powershell
mvn dependency:resolve -Dverbose
```

## 📋 **Common Causes & Solutions**

| **Cause** | **Solution** |
|-----------|--------------|
| Corrupted .m2 repository | Clear Maven cache |
| IDE cache issues | Invalidate IDE caches |
| Wrong Java version | Set Java 17 in IDE/Environment |
| Network interruption during download | Re-download dependencies |
| Antivirus blocking downloads | Add .m2 folder to exclusions |
| Disk space issues | Free up disk space |
| Maven settings.xml issues | Reset settings.xml |

## 🆘 **If Nothing Works**

### **Nuclear Option:**
```powershell
# 1. Delete entire .m2 repository
rmdir /s /q "%USERPROFILE%\.m2"

# 2. Delete target directories
rmdir /s /q "backend\target"

# 3. Fresh clone/download of project
# 4. Fresh install of Maven
# 5. Fresh install of Java 17
```

### **Check Network/Proxy:**
```powershell
# Test Maven central connectivity
ping repo1.maven.org

# Check proxy settings in ~/.m2/settings.xml if behind corporate firewall
```

## ✅ **Verification**

After fixing, verify everything works:
```powershell
cd backend
mvn clean
mvn compile
mvn test
mvn spring-boot:run
```

The application should start successfully and be available at `http://localhost:8080`

## 🎯 **Prevention**

1. **Regular Cache Cleanup:** Periodically clean Maven cache
2. **Stable Internet:** Ensure stable connection during builds
3. **Antivirus Exclusions:** Add .m2 folder to antivirus exclusions
4. **IDE Updates:** Keep IDE and plugins updated
5. **Java Version:** Stick to one Java version across all tools

This comprehensive fix should resolve the Maven dependencies issue!
