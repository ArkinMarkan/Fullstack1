#!/bin/bash
# Java 17 Environment Setup Script for Movie Booking Application
# This script helps set up Java 17 environment on Windows/Linux/Mac

echo "🚀 Setting up Java 17 Environment for Movie Booking Application"

# Function to check if Java 17 is installed
check_java17() {
    if command -v java &> /dev/null; then
        JAVA_VERSION=$(java -version 2>&1 | head -1 | cut -d'"' -f2 | cut -d'.' -f1)
        if [ "$JAVA_VERSION" = "17" ]; then
            echo "✅ Java 17 is already installed and active"
            java -version
            return 0
        else
            echo "❌ Java $JAVA_VERSION is installed, but Java 17 is required"
            return 1
        fi
    else
        echo "❌ Java is not installed"
        return 1
    fi
}

# Function to check Maven
check_maven() {
    if command -v mvn &> /dev/null; then
        echo "✅ Maven is installed"
        mvn -version
        return 0
    else
        echo "❌ Maven is not installed"
        return 1
    fi
}

# Function to set up project
setup_project() {
    echo "📁 Setting up Movie Booking Application..."
    
    # Navigate to backend directory
    if [ -d "backend" ]; then
        cd backend
        echo "📂 Moved to backend directory"
    else
        echo "❌ Backend directory not found!"
        exit 1
    fi
    
    # Clean and compile
    echo "🧹 Cleaning project..."
    mvn clean
    
    echo "⚡ Compiling with Java 17..."
    mvn compile
    
    # Run tests
    echo "🧪 Running tests..."
    mvn test
    
    echo "✅ Project setup complete!"
}

# Function to verify database setup
verify_database() {
    echo "🗄️  Checking database connectivity..."
    
    # Check if MySQL is running (basic check)
    if command -v mysql &> /dev/null; then
        echo "✅ MySQL client is available"
    else
        echo "⚠️  MySQL client not found. Make sure MySQL is installed."
    fi
}

# Function to start application
start_application() {
    echo "🚀 Starting Movie Booking Application..."
    
    # Set Spring profile
    export SPRING_PROFILES_ACTIVE=mysql
    
    # Start the application
    mvn spring-boot:run -Dspring.profiles.active=mysql
}

# Main execution
echo "============================================"
echo " Movie Booking App - Java 17 Setup Script"
echo "============================================"

# Step 1: Check Java 17
echo "1️⃣ Checking Java 17..."
if ! check_java17; then
    echo ""
    echo "📥 Please install Java 17:"
    echo "   - Windows: Download from https://adoptium.net/"
    echo "   - Linux: sudo apt install openjdk-17-jdk"
    echo "   - Mac: brew install openjdk@17"
    echo ""
    echo "After installation, set JAVA_HOME and update PATH"
    exit 1
fi

echo ""

# Step 2: Check Maven
echo "2️⃣ Checking Maven..."
if ! check_maven; then
    echo ""
    echo "📥 Please install Maven:"
    echo "   - Download from https://maven.apache.org/download.cgi"
    echo "   - Or use package manager (brew install maven, apt install maven)"
    exit 1
fi

echo ""

# Step 3: Setup project
echo "3️⃣ Setting up project..."
setup_project

echo ""

# Step 4: Verify database
echo "4️⃣ Verifying database setup..."
verify_database

echo ""

# Step 5: Ask if user wants to start the application
echo "5️⃣ Ready to start the application!"
echo ""
echo "To start the Movie Booking Application:"
echo "  cd backend"
echo "  mvn spring-boot:run -Dspring.profiles.active=mysql"
echo ""
echo "The application will be available at: http://localhost:8080"
echo ""

read -p "Would you like to start the application now? (y/N): " -r
if [[ $REPLY =~ ^[Yy]$ ]]; then
    start_application
else
    echo "👍 Setup complete! You can start the application manually when ready."
fi

echo ""
echo "🎉 Java 17 setup completed successfully!"
echo "📚 Check JAVA17_SETUP_GUIDE.md for detailed information"
