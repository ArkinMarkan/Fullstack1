# Quick Start Guide for Movie Booking Backend

## Prerequisites Installation

### 1. Java 17+ Installation
```bash
# Download from: https://adoptium.net/temurin/releases/
# Install the MSI package for Windows
# Verify installation: java -version
```

### 2. Maven Installation
```bash
# Download from: https://maven.apache.org/download.cgi
# Extract to C:\apache-maven-3.9.5
# Add C:\apache-maven-3.9.5\bin to system PATH
# Verify installation: mvn --version
```

### 3. MySQL Installation
```bash
# Download MySQL Installer: https://dev.mysql.com/downloads/installer/
# Choose "Developer Default" setup
# Set root password during installation
# Start MySQL service: net start mysql80
```

## Database Setup

```sql
-- Connect to MySQL as root
mysql -u root -p

-- Run the setup commands
CREATE DATABASE moviebookingdb;
CREATE USER 'movieapp'@'localhost' IDENTIFIED BY 'movieapp123';
GRANT ALL PRIVILEGES ON moviebookingdb.* TO 'movieapp'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

## Running the Backend

### Method 1: Using the batch scripts
```cmd
# Setup (one-time)
setup-backend.bat

# Run the application
run-backend.bat
```

### Method 2: Manual commands
```cmd
# Navigate to backend folder
cd c:\Users\2268594\Downloads\FSE\backend

# Build the application
mvn clean install

# Run the application
mvn spring-boot:run

# Or run with MySQL profile
mvn spring-boot:run -Dspring-boot.run.profiles=mysql
```

## Verification

Once the backend starts, verify it's working:

1. **Health Check**: http://localhost:8080/actuator/health
2. **API Documentation**: http://localhost:8080/swagger-ui.html
3. **Get All Movies**: http://localhost:8080/api/v1.0/moviebooking/all

## Default Test Credentials

- **Admin**: `admin` / `admin123`
- **User**: `john_doe` / `password123`

## Common Issues

### Port 8080 already in use:
```cmd
# Kill process using port 8080
netstat -ano | findstr :8080
taskkill /PID <PID_NUMBER> /F
```

### MySQL connection failed:
- Ensure MySQL service is running: `net start mysql80`
- Check if port 3306 is available: `netstat -an | findstr :3306`
- Verify credentials in `application-mysql.properties`

### Build fails:
- Ensure Java 17+ is installed and in PATH
- Ensure Maven is installed and in PATH
- Clear Maven cache: `mvn dependency:purge-local-repository`

## Advanced: Docker Setup (Optional)

If you prefer Docker:

1. **Install Docker Desktop for Windows**
2. **Run with Docker Compose**:
   ```cmd
   docker-compose up -d mysql redis
   docker-compose up backend
   ```

## Logs and Debugging

- Application logs: `backend/logs/movie-booking-app.log`
- Console output shows startup progress
- Debug mode: Add `-Dlogging.level.com.moviebookingapp=DEBUG`
