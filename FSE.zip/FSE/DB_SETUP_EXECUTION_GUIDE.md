# 🗄️ DATABASE SETUP EXECUTION GUIDE
# Movie Booking Application - Step by Step Instructions

## 📋 **Prerequisites Checklist**

Before running the database setup, ensure you have:

- [ ] **MySQL 8.0+** installed and running
- [ ] **MySQL root access** or admin privileges
- [ ] **MySQL Workbench** or command line access
- [ ] **Backend application** configured with correct database credentials

## 🚀 **Step-by-Step Execution**

### **Step 1: Verify MySQL Installation**

```bash
# Check if MySQL is running
mysql --version

# Check if MySQL service is running (Windows)
net start | findstr -i mysql
```

### **Step 2: Connect to MySQL**

**Option A: Using MySQL Workbench**
1. Open MySQL Workbench
2. Connect to Local instance MySQL80 (or your MySQL server)
3. Enter root password

**Option B: Using Command Line**
```bash
mysql -u root -p
```

### **Step 3: Execute Database Setup Script**

**Method 1: Direct Script Execution**
```sql
-- Copy and paste the entire content from dbsetup.txt into MySQL Workbench
-- Or run via command line:
source c:\Users\2268594\Downloads\FSE\dbsetup.txt
```

**Method 2: Step-by-Step Execution**
```sql
-- 1. Create database and user
CREATE DATABASE IF NOT EXISTS moviebookingdb CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS 'movieapp'@'localhost' IDENTIFIED BY 'MovieApp123!';
GRANT ALL PRIVILEGES ON moviebookingdb.* TO 'movieapp'@'localhost';
FLUSH PRIVILEGES;

-- 2. Switch to database
USE moviebookingdb;

-- 3. Continue with table creation (copy from dbsetup.txt)
```

### **Step 4: Verify Setup**

```sql
-- Check if database was created
SHOW DATABASES LIKE 'moviebookingdb';

-- Check tables
USE moviebookingdb;
SHOW TABLES;

-- Verify sample data
SELECT COUNT(*) as movies_count FROM movies;
SELECT COUNT(*) as users_count FROM users;

-- Test composite primary key
SELECT movie_name, theatre_name FROM movies;
```

### **Step 5: Test Application Connection**

```bash
# Navigate to backend folder
cd c:\Users\2268594\Downloads\FSE\backend

# Test database connection (if you have Java/Maven installed)
mvn spring-boot:run -Dspring-boot.run.profiles=mysql
```

## 🔧 **Connection Parameters for Your Backend**

Your `application-mysql.properties` should have:

```properties
spring.datasource.url=jdbc:mysql://localhost:3306/moviebookingdb?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true
spring.datasource.username=movieapp
spring.datasource.password=MovieApp123!
spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver
```

## 📊 **Database Schema Summary**

| Table | Primary Key | Purpose |
|-------|-------------|---------|
| `movies` | (movie_name, theatre_name) | Core movie data with composite PK |
| `users` | id | User authentication and profiles |
| `tickets` | id | Ticket bookings with FK to movies |
| `movie_show_times` | id | Show schedules |

## 🎭 **Sample Data Created**

### **Movies (2 movies × 2 theatres = 4 entries)**
- Avengers Endgame @ PVR Cinemas (100 tickets)
- Avengers Endgame @ INOX Multiplex (150 tickets)
- RRR @ PVR Cinemas (120 tickets)
- RRR @ Cinepolis (80 tickets)

### **Users (3 test accounts)**
- **Admin**: `admin` / `admin123`
- **User 1**: `john_doe` / `password123`
- **User 2**: `jane_smith` / `password123`

## 🛠️ **Troubleshooting**

### **Common Issues & Solutions**

**1. Access Denied Error**
```sql
-- Solution: Grant proper privileges
GRANT ALL PRIVILEGES ON moviebookingdb.* TO 'movieapp'@'localhost';
FLUSH PRIVILEGES;
```

**2. Table Already Exists**
```sql
-- Solution: Drop and recreate
DROP DATABASE IF EXISTS moviebookingdb;
-- Then run setup script again
```

**3. Connection Refused**
```bash
# Solution: Start MySQL service
net start mysql80  # Windows
# or
sudo service mysql start  # Linux/Mac
```

**4. Character Set Issues**
```sql
-- Solution: Set proper character set
ALTER DATABASE moviebookingdb CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

## ✅ **Verification Checklist**

After setup completion, verify:

- [ ] Database `moviebookingdb` exists
- [ ] All 4 tables created successfully
- [ ] User `movieapp` has proper permissions
- [ ] Sample data inserted (4 movies, 3 users)
- [ ] Composite primary key on movies table works
- [ ] Foreign key constraints are active
- [ ] Stored procedures created successfully
- [ ] Triggers are active
- [ ] Views are accessible

## 🎯 **Next Steps**

1. **Test Backend Connection**: Run your Spring Boot application
2. **Verify API Endpoints**: Check http://localhost:8080/actuator/health
3. **Test Frontend**: Start React app and test login with sample users
4. **Run Integration Tests**: Verify all user stories work end-to-end

## 📞 **Database Connection Details**

For tools like MySQL Workbench or other database clients:

- **Host**: localhost
- **Port**: 3306
- **Database**: moviebookingdb
- **Username**: movieapp
- **Password**: MovieApp123!

## 🚀 **Ready to Go!**

Your database is now configured exactly as per the requirements documentation with:
- ✅ Composite primary key (movie_name, theatre_name)
- ✅ Sample data (2 movies × 2 theatres)
- ✅ All required fields and relationships
- ✅ Performance optimizations (indexes, procedures, triggers)
- ✅ Complete user management system

Execute the dbsetup.txt script and your Movie Booking Application database will be fully ready! 🎉
