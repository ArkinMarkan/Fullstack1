// Types for the Movie Booking Application

export interface Movie {
  id?: string;
  movieName: string;
  theatreName: string;
  totalTickets?: number;
  availableSeats: number;
  showTimes?: string[];
  status?: 'BOOK_ASAP' | 'SOLD_OUT';
  description?: string;
  genre?: string;
  language?: string;
  duration?: number;
  posterUrl?: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface User {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  loginId?: string;
  contactNumber: string;
  role: 'USER' | 'ADMIN';
  createdAt?: string;
  updatedAt?: string;
}

export interface Ticket {
  id: string;
  movieName: string;
  theatreName: string;
  numberOfTickets: number;
  seatNumbers: string[];
  userId?: string;
  userEmail?: string;
  userLoginId?: string;
  status: 'CONFIRMED' | 'CANCELLED' | 'EXPIRED' | 'REFUNDED';
  totalPrice?: number;
  bookingReference?: string;
  bookingDate: string;
  showDateTime?: string;
  bookedAt?: string;
  updatedAt?: string;
}

// Registration and Login types
export interface RegisterRequest {
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  contactNumber: string;
}

export interface LoginRequest {
  email: string;
  password: string;
}

export interface JwtResponse {
  token: string;
  user: User;
  refreshToken?: string;
  type?: string;
}

export interface TicketBookingData {
  movieName: string;
  theatreName: string;
  numberOfTickets: number;
  seatNumbers: string[];
}

export interface ApiResponse<T> {
  success: boolean;
  message: string;
  data: T;
  timestamp?: string;
  path?: string;
}

// Auth context types
export interface AuthContextType {
  user: User | null;
  token: string | null;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  register: (userData: RegisterRequest) => Promise<void>;
  isAuthenticated: boolean;
  isAdmin: boolean;
  loading: boolean;
}

// Movie search filters
export interface MovieFilters {
  searchTerm?: string;
  genre?: string;
  language?: string;
  status?: 'BOOK_ASAP' | 'SOLD_OUT' | '';
  theatreName?: string;
}

// Form validation types
export interface ValidationErrors {
  [key: string]: string;
}

// Error response type
export interface ErrorResponse {
  success: false;
  message: string;
  data?: any;
  timestamp?: string;
  path?: string;
}
