// Types for the Movie Booking Application

export interface Movie {
  id?: number;
  movieName: string;
  theatreName: string;
  totalTickets?: number;
  availableTickets: number;
  showTimes?: string[];
  status?: 'BOOK_ASAP' | 'SOLD_OUT';
  description?: string;
  genre?: string;
  language?: string;
  duration?: number;
  rating?: number;
  posterUrl?: string;
  releaseDate?: string;
  createdDate?: string;
  modifiedDate?: string;
}

export interface User {
  id?: number;
  firstName: string;
  lastName: string;
  email: string;
  loginId: string;
  contactNumber: string;
  role: 'USER' | 'ADMIN';
  enabled?: boolean;
  createdDate?: string;
  modifiedDate?: string;
}

export interface Ticket {
  id: number;
  movieName: string;
  theatreName: string;
  numberOfTickets: number;
  seatNumbers: string[];
  userId?: number;
  userLoginId?: string;
  status: 'CONFIRMED' | 'CANCELLED' | 'EXPIRED';
  totalAmount?: number;
  bookingReference?: string;
  bookingDate: string;
  createdDate?: string;
  modifiedDate?: string;
}

// Registration and Login types
export interface RegisterRequest {
  firstName: string;
  lastName: string;
  email: string;
  loginId: string;
  password: string;
  confirmPassword: string;
  contactNumber: string;
}

export interface LoginRequest {
  loginId: string;
  password: string;
}

export interface JwtResponse {
  token: string;
  user: User;
  refreshToken?: string;
  type?: string;
}

export interface TicketBookingData {
  movieName: string;
  theatreName: string;
  numberOfTickets: number;
  seatNumbers: string[];
}

export interface ApiResponse<T> {
  success: boolean;
  message: string;
  data: T;
  timestamp?: string;
  path?: string;
}

// Auth context types
export interface AuthContextType {
  user: User | null;
  token: string | null;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  register: (userData: RegisterRequest) => Promise<void>;
  isAuthenticated: boolean;
  isAdmin: boolean;
  loading: boolean;
}

// Movie search filters
export interface MovieFilters {
  searchTerm?: string;
  genre?: string;
  language?: string;
  status?: 'BOOK_ASAP' | 'SOLD_OUT' | '';
  theatreName?: string;
}

// Form validation types
export interface ValidationErrors {
  [key: string]: string;
}

// Error response type
export interface ErrorResponse {
  success: false;
  message: string;
  data?: any;
  timestamp?: string;
  path?: string;
}
