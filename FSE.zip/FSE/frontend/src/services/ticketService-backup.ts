import apiService from './apiService';
import {
  Ticket,
  TicketBookingData,
  ApiResponse,
  BookingStats,
} from '../types';

class TicketService {
  // Book tickets for a movie
  async bookTicket(
    movieName: string,
    bookingData: TicketBookingData
  ): Promise<ApiResponse<Ticket>> {
    return apiService.post<Ticket>(`/${encodeURIComponent(movieName)}/add`, bookingData);
  }

  // Get user's tickets
  async getUserTickets(): Promise<ApiResponse<Ticket[]>> {
    return apiService.get<Ticket[]>('/tickets/user');
  }

  // Get tickets for a specific movie (Admin only)
  async getMovieTickets(
    movieName: string,
    theatreName: string
  ): Promise<ApiResponse<Ticket[]>> {
    return apiService.get<Ticket[]>(
      `/${encodeURIComponent(movieName)}/tickets?theatreName=${encodeURIComponent(theatreName)}`
    );
  }

  // Get ticket by booking reference
  async getTicketByReference(bookingReference: string): Promise<ApiResponse<Ticket>> {
    return apiService.get<Ticket>(`/tickets/${bookingReference}`);
  }

  // Cancel ticket
  async cancelTicket(bookingReference: string): Promise<ApiResponse<Ticket>> {
    return apiService.delete<Ticket>(`/tickets/${bookingReference}/cancel`);
  }

  // Get all tickets (Admin only)
  async getAllTickets(): Promise<ApiResponse<Ticket[]>> {
    return apiService.get<Ticket[]>('/tickets/all');
  }

  // Get movie booking statistics (Admin only)
  async getMovieBookingStats(): Promise<ApiResponse<BookingStats[]>> {
    return apiService.get<BookingStats[]>('/tickets/stats/movies');
  }

  // Get theatre booking statistics (Admin only)
  async getTheatreBookingStats(): Promise<ApiResponse<BookingStats[]>> {
    return apiService.get<BookingStats[]>('/tickets/stats/theatres');
  }

  // Count tickets for a movie (Admin only)
  async countMovieTickets(
    movieName: string,
    theatreName: string
  ): Promise<ApiResponse<number>> {
    return apiService.get<number>(
      `/${encodeURIComponent(movieName)}/tickets/count?theatreName=${encodeURIComponent(theatreName)}`
    );
  }

  // Generate seat numbers for booking
  generateSeatNumbers(numberOfTickets: number, startingSeat: string = 'A1'): string[] {
    const seats: string[] = [];
    let row = startingSeat.charAt(0);
    let seatNum = parseInt(startingSeat.slice(1));

    for (let i = 0; i < numberOfTickets; i++) {
      seats.push(`${row}${seatNum + i}`);
    }

    return seats;
  }

  // Validate seat selection
  validateSeatSelection(seatNumbers: string[], numberOfTickets: number): boolean {
    // Check if number of seats matches number of tickets
    if (seatNumbers.length !== numberOfTickets) {
      return false;
    }

    // Check for duplicate seats
    const uniqueSeats = new Set(seatNumbers);
    if (uniqueSeats.size !== seatNumbers.length) {
      return false;
    }

    // Check seat format (basic validation)
    const seatPattern = /^[A-Z][0-9]+$/;
    return seatNumbers.every(seat => seatPattern.test(seat));
  }

  // Format booking reference for display
  formatBookingReference(reference: string): string {
    return reference.toUpperCase();
  }

  // Calculate total price (placeholder - implement based on pricing logic)
  calculateTotalPrice(numberOfTickets: number, basePrice: number = 150): number {
    return numberOfTickets * basePrice;
  }

  // Filter tickets by status
  filterTicketsByStatus(tickets: Ticket[], status: string): Ticket[] {
    return tickets.filter(ticket => ticket.status === status);
  }

  // Get ticket statistics
  getTicketStatistics(tickets: Ticket[]) {
    const stats = {
      total: tickets.length,
      confirmed: tickets.filter(t => t.status === 'CONFIRMED').length,
      cancelled: tickets.filter(t => t.status === 'CANCELLED').length,
      expired: tickets.filter(t => t.status === 'EXPIRED').length,
      refunded: tickets.filter(t => t.status === 'REFUNDED').length,
    };

    return stats;
  }

  // Sort tickets by booking date (newest first)
  sortTicketsByDate(tickets: Ticket[]): Ticket[] {
    return [...tickets].sort((a, b) => 
      new Date(b.bookedAt).getTime() - new Date(a.bookedAt).getTime()
    );
  }

  // Group tickets by movie
  groupTicketsByMovie(tickets: Ticket[]): Record<string, Ticket[]> {
    return tickets.reduce((groups, ticket) => {
      const key = `${ticket.movieName} - ${ticket.theatreName}`;
      if (!groups[key]) {
        groups[key] = [];
      }
      groups[key].push(ticket);
      return groups;
    }, {} as Record<string, Ticket[]>);
  }
}

export default new TicketService();
