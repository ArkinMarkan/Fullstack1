import apiService from './apiService';
import { Ticket } from '../types';

interface TicketBookingRequest {
  movieName: string;
  theatreName: string;
  numberOfTickets: number;
  seatNumbers: string[];
}

export const ticketService = {
  bookTicket: async (ticketData: TicketBookingRequest): Promise<Ticket> => {
    const response = await apiService.post<Ticket>('/api/tickets/book', ticketData);
    return response.data;
  },

  getUserTickets: async (): Promise<Ticket[]> => {
    const response = await apiService.get<Ticket[]>('/api/tickets/user');
    return response.data;
  },

  getAllTickets: async (): Promise<Ticket[]> => {
    const response = await apiService.get<Ticket[]>('/api/tickets/all');
    return response.data;
  },

  cancelTicket: async (ticketId: string): Promise<void> => {
    await apiService.delete(`/api/tickets/${ticketId}`);
  },
};
