import { apiClient } from './api';
import { User, LoginRequest, RegisterRequest, JwtResponse } from '../types';

export const authService = {
  login: async (email: string, password: string): Promise<JwtResponse> => {
    const response = await apiClient.post('/auth/login', { email, password });
    return response.data;
  },

  register: async (userData: RegisterRequest): Promise<{ message: string }> => {
    const response = await apiClient.post('/auth/register', userData);
    return response.data;
  },

  logout: (): void => {
    localStorage.removeItem('authToken');
    localStorage.removeItem('user');
  },

  getCurrentUser: (): User | null => {
    const userStr = localStorage.getItem('user');
    return userStr ? JSON.parse(userStr) : null;
  },

  isAuthenticated: (): boolean => {
    const token = localStorage.getItem('authToken');
    return !!token;
  },
};
