import { apiClient } from './api';
import { Movie } from '../types';

export const movieService = {
  getAllMovies: async (): Promise<Movie[]> => {
    const response = await apiClient.get('/all');
    return response.data;
  },

  searchMovies: async (movieName: string): Promise<Movie[]> => {
    const response = await apiClient.get(`/search/${encodeURIComponent(movieName)}`);
    return response.data;
  },

  addMovie: async (movieData: Omit<Movie, 'id'>): Promise<Movie> => {
    const response = await apiClient.post('/admin/add', movieData);
    return response.data;
  },

  updateMovie: async (movieName: string, theatreName: string, movieData: Partial<Movie>): Promise<Movie> => {
    const response = await apiClient.put(`/admin/update/${encodeURIComponent(movieName)}/${encodeURIComponent(theatreName)}`, movieData);
    return response.data;
  },

  deleteMovie: async (movieName: string, theatreName: string): Promise<void> => {
    await apiClient.delete(`/admin/delete/${encodeURIComponent(movieName)}/${encodeURIComponent(theatreName)}`);
  },
};
