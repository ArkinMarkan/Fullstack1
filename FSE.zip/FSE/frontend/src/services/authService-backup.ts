import apiService from './apiService';
import {
  User,
  UserRegistrationData,
  LoginCredentials,
  JwtResponse,
  ApiResponse,
} from '../types';

class AuthService {
  // Register new user
  async register(userData: UserRegistrationData): Promise<ApiResponse<User>> {
    return apiService.post<User>('/register', userData);
  }

  // Login user
  async login(credentials: LoginCredentials): Promise<ApiResponse<JwtResponse>> {
    return apiService.post<JwtResponse>('/login', credentials);
  }

  // Forgot password
  async forgotPassword(username: string): Promise<ApiResponse<string>> {
    return apiService.get<string>(`/${username}/forgot`);
  }

  // Save auth data to localStorage
  saveAuthData(authResponse: JwtResponse): void {
    localStorage.setItem('authToken', authResponse.token);
    localStorage.setItem('refreshToken', authResponse.refreshToken);
    
    const userData = {
      loginId: authResponse.loginId,
      firstName: authResponse.firstName,
      lastName: authResponse.lastName,
      email: authResponse.email,
      role: authResponse.role,
    };
    
    localStorage.setItem('user', JSON.stringify(userData));
    apiService.setAuthToken(authResponse.token);
  }

  // Get current user from localStorage
  getCurrentUser(): User | null {
    const userString = localStorage.getItem('user');
    if (userString) {
      try {
        return JSON.parse(userString);
      } catch (error) {
        console.error('Error parsing user data:', error);
        this.logout();
        return null;
      }
    }
    return null;
  }

  // Get auth token
  getAuthToken(): string | null {
    return localStorage.getItem('authToken');
  }

  // Check if user is authenticated
  isAuthenticated(): boolean {
    const token = this.getAuthToken();
    const user = this.getCurrentUser();
    return !!(token && user);
  }

  // Check if user is admin
  isAdmin(): boolean {
    const user = this.getCurrentUser();
    return user?.role === 'ADMIN';
  }

  // Logout user
  logout(): void {
    localStorage.removeItem('authToken');
    localStorage.removeItem('refreshToken');
    localStorage.removeItem('user');
    apiService.removeAuthToken();
  }

  // Refresh token (placeholder - implement if needed)
  async refreshToken(): Promise<ApiResponse<JwtResponse>> {
    const refreshToken = localStorage.getItem('refreshToken');
    if (!refreshToken) {
      throw new Error('No refresh token available');
    }
    
    // Implementation would depend on backend refresh token endpoint
    // For now, just throw an error to trigger re-login
    throw new Error('Token refresh not implemented');
  }
}

export default new AuthService();
