import { apiClient } from './api.ts';
import { User, RegisterRequest, JwtResponse, ApiResponse } from '../types';

// Backend JWT payload shape
interface BackendJwtResponse {
  token: string;
  refreshToken?: string;
  type?: string;
  loginId: string;
  firstName: string;
  lastName: string;
  email: string;
  role: 'USER' | 'ADMIN' | string;
}

export const authService = {
  login: async (loginId: string, password: string): Promise<JwtResponse> => {
    // Send snake_case keys due to backend SNAKE_CASE config
    const response = await apiClient.post<ApiResponse<BackendJwtResponse>>('/login', { login_id: loginId, password });
    const payload = response.data;

    if (!payload.success || !payload.data?.token) {
      throw new Error(payload.message || 'Authentication failed');
    }

    const jwt = payload.data;

    const user: User = {
      loginId: jwt.loginId,
      firstName: jwt.firstName,
      lastName: jwt.lastName,
      email: jwt.email,
      role: (jwt.role as 'USER' | 'ADMIN') || 'USER',
    } as User;

    localStorage.setItem('authToken', jwt.token);
    localStorage.setItem('user', JSON.stringify(user));

    return { token: jwt.token, user, refreshToken: jwt.refreshToken, type: jwt.type };
  },

  register: async (userData: RegisterRequest): Promise<{ message: string }> => {
    // Transform to snake_case for backend
    const payload = {
      first_name: userData.firstName,
      last_name: userData.lastName,
      email: userData.email,
      login_id: userData.loginId,
      password: userData.password,
      contact_number: userData.contactNumber,
      confirm_password: userData.confirmPassword,
    };
    const response = await apiClient.post('/register', payload);
    return response.data;
  },

  forgotPassword: async (username: string): Promise<{ message: string }> => {
    const response = await apiClient.get(`/${username}/forgot`);
    return response.data;
  },

  logout: (): void => {
    localStorage.removeItem('authToken');
    localStorage.removeItem('user');
  },

  getCurrentUser: (): User | null => {
    const userStr = localStorage.getItem('user');
    return userStr ? JSON.parse(userStr) : null;
  },

  isAuthenticated: (): boolean => {
    const token = localStorage.getItem('authToken');
    return !!token;
  },
};
