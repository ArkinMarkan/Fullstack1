import apiService from './apiService';
import {
  Movie,
  ApiResponse,
  MovieStats,
  MovieFilters,
} from '../types';

class MovieService {
  // Get all movies
  async getAllMovies(): Promise<ApiResponse<Movie[]>> {
    return apiService.get<Movie[]>('/all');
  }

  // Get available movies
  async getAvailableMovies(): Promise<ApiResponse<Movie[]>> {
    return apiService.get<Movie[]>('/available');
  }

  // Search movies by name
  async searchMoviesByName(movieName: string): Promise<ApiResponse<Movie[]>> {
    return apiService.get<Movie[]>(`/movies/search/${encodeURIComponent(movieName)}`);
  }

  // Enhanced search movies
  async searchMovies(query: string): Promise<ApiResponse<Movie[]>> {
    return apiService.get<Movie[]>('/search', { q: query });
  }

  // Update movie ticket status (Admin only)
  async updateTicketStatus(
    movieName: string,
    status: string,
    theatreName: string
  ): Promise<ApiResponse<Movie>> {
    return apiService.put<Movie>(
      `/${encodeURIComponent(movieName)}/update/${status}?theatreName=${encodeURIComponent(theatreName)}`
    );
  }

  // Delete movie (Admin only)
  async deleteMovie(
    movieName: string,
    theatreName: string,
    id: string
  ): Promise<ApiResponse<string>> {
    return apiService.delete<string>(
      `/${encodeURIComponent(movieName)}/delete/${id}?theatreName=${encodeURIComponent(theatreName)}`
    );
  }

  // Get movie statistics (Admin only)
  async getMovieStatistics(): Promise<ApiResponse<MovieStats[]>> {
    return apiService.get<MovieStats[]>('/statistics');
  }

  // Recalculate ticket status (Admin only)
  async recalculateTicketStatus(
    movieName: string,
    theatreName: string
  ): Promise<ApiResponse<Movie>> {
    return apiService.post<Movie>(
      `/${encodeURIComponent(movieName)}/recalculate?theatreName=${encodeURIComponent(theatreName)}`
    );
  }

  // Filter movies based on criteria
  filterMovies(movies: Movie[], filters: MovieFilters): Movie[] {
    return movies.filter((movie) => {
      // Search term filter
      if (filters.searchTerm) {
        const searchTerm = filters.searchTerm.toLowerCase();
        const movieMatch = movie.movieName.toLowerCase().includes(searchTerm);
        const theatreMatch = movie.theatreName.toLowerCase().includes(searchTerm);
        const genreMatch = movie.genre?.toLowerCase().includes(searchTerm) || false;
        const languageMatch = movie.language?.toLowerCase().includes(searchTerm) || false;
        
        if (!(movieMatch || theatreMatch || genreMatch || languageMatch)) {
          return false;
        }
      }

      // Genre filter
      if (filters.genre && movie.genre !== filters.genre) {
        return false;
      }

      // Language filter
      if (filters.language && movie.language !== filters.language) {
        return false;
      }

      // Status filter
      if (filters.status && movie.status !== filters.status) {
        return false;
      }

      // Theatre filter
      if (filters.theatreName && movie.theatreName !== filters.theatreName) {
        return false;
      }

      return true;
    });
  }

  // Get unique genres from movies
  getUniqueGenres(movies: Movie[]): string[] {
    const genres = movies
      .map((movie) => movie.genre)
      .filter((genre): genre is string => !!genre);
    
    return [...new Set(genres)].sort();
  }

  // Get unique languages from movies
  getUniqueLanguages(movies: Movie[]): string[] {
    const languages = movies
      .map((movie) => movie.language)
      .filter((language): language is string => !!language);
    
    return [...new Set(languages)].sort();
  }

  // Get unique theatres from movies
  getUniqueTheatres(movies: Movie[]): string[] {
    const theatres = movies.map((movie) => movie.theatreName);
    return [...new Set(theatres)].sort();
  }
}

export default new MovieService();
