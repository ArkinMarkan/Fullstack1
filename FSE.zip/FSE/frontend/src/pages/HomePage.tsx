import React from 'react';
import {
  Box,
  Typography,
  Container,
  Button,
  Grid,
  Card,
  CardContent,
  CardActions,
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const HomePage: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();

  const features = [
    {
      title: 'Browse Movies',
      description: 'Discover the latest movies and showtimes',
      action: () => navigate('/movies'),
      buttonText: 'View Movies',
    },
    {
      title: 'Book Tickets',
      description: 'Reserve your seats for upcoming shows',
      action: () => navigate('/movies'),
      buttonText: 'Book Now',
    },
    {
      title: 'Manage Bookings',
      description: 'View and manage your ticket bookings',
      action: () => navigate('/my-tickets'),
      buttonText: 'My Tickets',
    },
  ];

  return (
    <Container maxWidth="lg">
      <Box py={8}>
        {/* Hero Section */}
        <Box textAlign="center" mb={8}>
          <Typography
            variant="h2"
            component="h1"
            gutterBottom
            sx={{ fontWeight: 'bold', mb: 2 }}
          >
            Welcome to Movie Booking App
          </Typography>
          <Typography variant="h5" color="text.secondary" paragraph>
            Book your favorite movies with ease
          </Typography>
          {user ? (
            <Typography variant="h6" color="primary" sx={{ mt: 2 }}>
              Hello, {user.firstName}! Ready to book your next movie?
            </Typography>
          ) : (
            <Box mt={4}>
              <Button
                variant="contained"
                size="large"
                onClick={() => navigate('/register')}
                sx={{ mr: 2 }}
              >
                Get Started
              </Button>
              <Button
                variant="outlined"
                size="large"
                onClick={() => navigate('/login')}
              >
                Login
              </Button>
            </Box>
          )}
        </Box>

        {/* Features Section */}
        <Grid container spacing={4}>
          {features.map((feature, index) => (
            <Grid item xs={12} md={4} key={index}>
              <Card
                sx={{
                  height: '100%',
                  display: 'flex',
                  flexDirection: 'column',
                  textAlign: 'center',
                  transition: 'transform 0.2s',
                  '&:hover': {
                    transform: 'translateY(-4px)',
                    boxShadow: 3,
                  },
                }}
              >
                <CardContent sx={{ flexGrow: 1, p: 3 }}>
                  <Typography variant="h5" component="h2" gutterBottom>
                    {feature.title}
                  </Typography>
                  <Typography variant="body1" color="text.secondary">
                    {feature.description}
                  </Typography>
                </CardContent>
                <CardActions sx={{ justifyContent: 'center', pb: 3 }}>
                  <Button
                    variant="contained"
                    onClick={feature.action}
                    disabled={!user && feature.title !== 'Browse Movies'}
                  >
                    {feature.buttonText}
                  </Button>
                </CardActions>
              </Card>
            </Grid>
          ))}
        </Grid>

        {/* Call to Action */}
        {!user && (
          <Box textAlign="center" mt={8} py={6} bgcolor="grey.50" borderRadius={2}>
            <Typography variant="h4" gutterBottom>
              Ready to Start Booking?
            </Typography>
            <Typography variant="body1" color="text.secondary" paragraph>
              Create an account today and start booking your favorite movies!
            </Typography>
            <Button
              variant="contained"
              size="large"
              onClick={() => navigate('/register')}
            >
              Sign Up Now
            </Button>
          </Box>
        )}
      </Box>
    </Container>
  );
};

export default HomePage;
