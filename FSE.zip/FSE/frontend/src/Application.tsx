import React from 'react';

function Application() {
  return (
    <div style={{ 
      padding: '50px', 
      textAlign: 'center', 
      fontFamily: 'Arial, sans-serif' 
    }}>
      <h1>🎬 Movie Booking App</h1>
      <p>Frontend is working!</p>
      <p>Built with React + TypeScript</p>
    </div>
  );
}

export default Application;
