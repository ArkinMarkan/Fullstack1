import React from 'react';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import { Container, Typography, Paper, Box } from '@mui/material';

const theme = createTheme({
  palette: {
    primary: {
      main: '#1976d2',
    },
    secondary: {
      main: '#dc004e',
    },
  },
});

function App() {
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Container maxWidth="lg">
        <Box py={4}>
          <Paper elevation={3} sx={{ p: 4, textAlign: 'center' }}>
            <Typography variant="h3" component="h1" gutterBottom>
              🎬 Movie Booking App
            </Typography>
            <Typography variant="h6" color="text.secondary" paragraph>
              Full-Stack Movie Booking Application
            </Typography>
            <Typography variant="body1" paragraph>
              Frontend: React + TypeScript + Material-UI
            </Typography>
            <Typography variant="body1" paragraph>
              Backend: Spring Boot + MongoDB + JWT Authentication
            </Typography>
            <Typography variant="body1" paragraph>
              Features: User Registration, Movie Browsing, Ticket Booking, Admin Dashboard
            </Typography>
            <Box mt={3}>
              <Typography variant="h6" color="primary">
                🚀 Frontend is running successfully!
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Start the backend server and complete the integration.
              </Typography>
            </Box>
          </Paper>
        </Box>
      </Container>
    </ThemeProvider>
  );
}

export default App;
