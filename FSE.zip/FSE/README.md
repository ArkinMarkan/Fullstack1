# Movie Booking Application

A full-stack movie booking application built with Spring Boot (backend), React (frontend), MongoDB (database), and Redis (caching).

## 🚀 Features

### User Features (US_01, US_02, US_03)
- ✅ User registration and login with JWT authentication
- ✅ Password reset functionality
- ✅ View all movies across different theatres
- ✅ Search movies by name (partial or complete)
- ✅ Book tickets for movies with seat selection
- ✅ View booking history

### Admin Features (US_04)
- ✅ View all booked tickets
- ✅ Update movie ticket status (BOOK_ASAP / SOLD_OUT)
- ✅ Recalculate ticket availability based on bookings
- ✅ Delete movies
- ✅ View booking statistics

### Technical Features
- ✅ RESTful API with proper HTTP methods
- ✅ Role-based authentication (USER, ADMIN)
- ✅ JWT token-based authentication
- ✅ MongoDB with custom queries and aggregations
- ✅ Redis caching and session management
- ✅ Rate limiting to prevent API abuse
- ✅ Comprehensive error handling
- ✅ Logging and monitoring
- ✅ Unit tests with 80%+ code coverage
- ✅ Docker containerization
- ✅ Static code analysis

## 🏗️ Architecture

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   React Frontend│    │  Spring Boot    │    │    MongoDB      │
│   (Port 3000)   │◄──►│   Backend       │◄──►│   Database      │
│                 │    │   (Port 8080)   │    │                 │
└─────────────────┘    └─────────────────┘    └─────────────────┘
                              │
                              ▼
                       ┌─────────────────┐
                       │     Redis       │
                       │   Cache/Session │
                       │                 │
                       └─────────────────┘
```

## 📋 Prerequisites

- Java 17+
- Node.js 18+
- Docker & Docker Compose
- MongoDB (if running locally)
- Redis (if running locally)
- Maven 3.8+

## 🚀 Quick Start with Docker

### 1. Clone the repository
```bash
git clone <repository-url>
cd movie-booking-app
```

### 2. Run with Docker Compose
```bash
docker-compose up -d
```

This will start:
- MongoDB on port 27017
- Redis on port 6379  
- Backend on port 8080
- Frontend on port 3000

### 3. Access the application
- Frontend: http://localhost:3000
- Backend API: http://localhost:8080/api/v1.0/moviebooking
- Swagger UI: http://localhost:8080/swagger-ui.html

### 4. Default credentials
```
Admin: 
- LoginID: admin
- Password: admin123

User:
- LoginID: john_doe  
- Password: password123
```

## 🛠️ Manual Setup

### Backend Setup
```bash
cd backend
mvn clean install
mvn spring-boot:run
```

### Frontend Setup
```bash
cd frontend
npm install
npm start
```

## 📊 Sample Data

The application initializes with sample data:

### Movies
1. **Avengers Endgame**
   - PVR Cinemas: 100 tickets
   - INOX Multiplex: 150 tickets

2. **RRR**
   - PVR Cinemas: 120 tickets
   - Cinepolis: 80 tickets

## 🔗 API Endpoints

### Authentication
- `POST /api/v1.0/moviebooking/register` - Register new user
- `GET /api/v1.0/moviebooking/login` - Login user
- `GET /api/v1.0/moviebooking/{username}/forgot` - Reset password

### Movies
- `GET /api/v1.0/moviebooking/all` - Get all movies
- `GET /api/v1.0/moviebooking/movies/search/{moviename}` - Search movies
- `PUT /api/v1.0/moviebooking/{moviename}/update/{status}` - Update status (Admin)
- `DELETE /api/v1.0/moviebooking/{moviename}/delete/{id}` - Delete movie (Admin)

### Tickets
- `POST /api/v1.0/moviebooking/{moviename}/add` - Book tickets
- `GET /api/v1.0/moviebooking/tickets/user` - Get user tickets
- `GET /api/v1.0/moviebooking/{moviename}/tickets` - Get movie tickets (Admin)

## 🧪 Testing

### Run Backend Tests
```bash
cd backend
mvn test
mvn jacoco:report
```

### Run Frontend Tests
```bash
cd frontend
npm test
npm run test:coverage
```

### Generate Test Reports
```bash
cd backend
mvn surefire-report:report
mvn site
```

Reports will be available in `backend/target/site/`

## 📈 Code Quality & Coverage

### Static Analysis
```bash
cd backend
mvn spotbugs:check
mvn checkstyle:check
```

### Code Coverage Requirements
- Minimum 80% line coverage
- JaCoCo reports generated automatically
- Coverage reports available in `target/site/jacoco/`

## 🐳 Docker Images

### Build Individual Images
```bash
# Backend
docker build -f Dockerfile.backend -t movie-booking-backend .

# Frontend  
docker build -f Dockerfile.frontend -t movie-booking-frontend .
```

### Environment Variables
```bash
# Backend
SPRING_DATA_MONGODB_URI=mongodb://localhost:27017/moviebookingdb
SPRING_REDIS_HOST=localhost
SPRING_REDIS_PORT=6379

# Frontend
REACT_APP_API_BASE_URL=http://localhost:8080/api/v1.0/moviebooking
```

## 📝 Project Structure

```
movie-booking-app/
├── backend/                 # Spring Boot application
│   ├── src/main/java/
│   │   └── com/moviebookingapp/
│   │       ├── controller/  # REST controllers
│   │       ├── service/     # Business logic
│   │       ├── repository/  # Data access
│   │       ├── model/       # Entity classes
│   │       ├── dto/         # Data Transfer Objects
│   │       ├── config/      # Configuration
│   │       ├── security/    # Authentication & authorization
│   │       ├── exception/   # Exception handling
│   │       └── util/        # Utilities
│   ├── src/main/resources/
│   └── src/test/           # Unit tests
├── frontend/               # React application
│   ├── src/
│   │   ├── components/     # Reusable components
│   │   ├── pages/         # Page components
│   │   ├── services/      # API services
│   │   ├── types/         # TypeScript types
│   │   ├── context/       # React context
│   │   └── utils/         # Utility functions
│   └── public/
├── docker-compose.yml      # Docker orchestration
├── Dockerfile.backend     # Backend container
├── Dockerfile.frontend    # Frontend container
└── README.md
```

## 🔒 Security Features

- JWT-based authentication
- Role-based authorization (USER, ADMIN)
- Password encryption with BCrypt
- Rate limiting (100 requests/minute)
- CORS configuration
- SQL injection prevention
- XSS protection headers

## 📊 Performance Features

- Redis caching for frequently accessed data
- Database indexing for optimal queries
- Connection pooling
- Gzip compression
- Static asset caching
- Health checks and monitoring

## 🚀 CI/CD Pipeline (Recommended)

```yaml
# .github/workflows/ci-cd.yml
name: CI/CD Pipeline
on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Setup JDK 17
        uses: actions/setup-java@v2
        with:
          java-version: '17'
      - name: Run tests
        run: |
          cd backend
          mvn clean test
          mvn jacoco:report
      - name: Upload coverage
        uses: codecov/codecov-action@v1
```

## 🐛 Troubleshooting

### Common Issues

1. **MongoDB Connection Error**
   ```bash
   # Check MongoDB is running
   docker logs moviebooking-mongodb
   ```

2. **Port Already in Use**
   ```bash
   # Check running processes
   netstat -tulpn | grep :8080
   ```

3. **Build Failures**
   ```bash
   # Clean and rebuild
   mvn clean install -U
   ```

### Debug Mode
```bash
# Backend with debug
mvn spring-boot:run -Dspring-boot.run.jvmArguments="-Xdebug -Xrunjdwp:transport=dt_socket,server=y,suspend=n,address=5005"

# Frontend with debug
npm start --verbose
```

## 📞 Support

For issues and questions:
1. Check the troubleshooting section
2. Review the logs in `logs/movie-booking-app.log`
3. Check Docker container logs: `docker logs <container-name>`
4. Open an issue in the repository

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests
5. Submit a pull request

## 📈 Monitoring & Metrics

Access the following endpoints for monitoring:
- Health: http://localhost:8080/api/v1.0/moviebooking/actuator/health
- Metrics: http://localhost:8080/api/v1.0/moviebooking/actuator/metrics
- Info: http://localhost:8080/api/v1.0/moviebooking/actuator/info

## 🎯 Future Enhancements

- Payment gateway integration
- Email notifications
- Mobile app (React Native)
- Advanced reporting dashboard
- Movie recommendations
- Social features (reviews, ratings)
- Multi-language support
