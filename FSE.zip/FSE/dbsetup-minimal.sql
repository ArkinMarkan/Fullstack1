-- MINIMAL DATABASE SETUP - NO COMPLEX FEATURES
-- This version removes all potentially problematic features
-- Use this if the main version still has issues

-- Create database and user
CREATE DATABASE IF NOT EXISTS moviebookingdb CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS 'movieapp'@'localhost' IDENTIFIED BY 'MovieApp123!';
GRANT ALL PRIVILEGES ON moviebookingdb.* TO 'movieapp'@'localhost';
FLUSH PRIVILEGES;
USE moviebookingdb;

-- Create tables (no comments to avoid issues)
CREATE TABLE users (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    login_id VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    contact_number VARCHAR(20) NOT NULL,
    role ENUM('USER', 'ADMIN') NOT NULL DEFAULT 'USER',
    account_non_expired BOOLEAN DEFAULT TRUE,
    account_non_locked BOOLEAN DEFAULT TRUE,
    credentials_non_expired BOOLEAN DEFAULT TRUE,
    enabled BOOLEAN DEFAULT TRUE,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    modified_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE movies (
    movie_name VARCHAR(100) NOT NULL,
    theatre_name VARCHAR(100) NOT NULL,
    id BIGINT AUTO_INCREMENT UNIQUE,
    total_tickets INTEGER NOT NULL,
    available_tickets INTEGER NOT NULL,
    status VARCHAR(20) DEFAULT 'BOOK_ASAP',
    description TEXT,
    genre VARCHAR(100),
    language VARCHAR(50),
    duration INTEGER,
    rating DECIMAL(3,1),
    release_date TIMESTAMP,
    ticket_price DECIMAL(10,2) DEFAULT 250.00,
    poster_url VARCHAR(255),
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    modified_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (movie_name, theatre_name)
);

CREATE TABLE tickets (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    movie_name VARCHAR(100) NOT NULL,
    theatre_name VARCHAR(100) NOT NULL,
    number_of_tickets INTEGER NOT NULL,
    seat_numbers JSON,
    user_id BIGINT NOT NULL,
    user_login_id VARCHAR(50) NOT NULL,
    booking_reference VARCHAR(20) UNIQUE NOT NULL,
    status ENUM('CONFIRMED', 'CANCELLED', 'EXPIRED') DEFAULT 'CONFIRMED',
    total_amount DECIMAL(10,2),
    booking_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    modified_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (movie_name, theatre_name) REFERENCES movies(movie_name, theatre_name),
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE movie_show_times (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    movie_name VARCHAR(100) NOT NULL,
    theatre_name VARCHAR(100) NOT NULL,
    show_time TIME NOT NULL,
    show_date DATE NOT NULL,
    screen_number VARCHAR(10),
    FOREIGN KEY (movie_name, theatre_name) REFERENCES movies(movie_name, theatre_name),
    UNIQUE KEY unique_show (movie_name, theatre_name, show_date, show_time)
);

-- Insert sample data
INSERT INTO users (first_name, last_name, email, login_id, password, contact_number, role) VALUES
('System', 'Administrator', 'admin@moviebooking.com', 'admin', 
 '$2a$10$xJrm8VNl3S0Sp7ub.IWj8eaKJjZNHhQD9X3iY6A.9sTsE.T.D5E16',
 '9999999999', 'ADMIN'),
('John', 'Doe', 'john.doe@example.com', 'john_doe', 
 '$2a$10$kKW/U8xBKCv8zJoHhqK2HOTgQ4y6J0Ykl4jE8VxDpJgKQPJNpQhzq',
 '9876543210', 'USER'),
('Jane', 'Smith', 'jane.smith@example.com', 'jane_smith',
 '$2a$10$kKW/U8xBKCv8zJoHhqK2HOTgQ4y6J0Ykl4jE8VxDpJgKQPJNpQhzq',
 '9876543211', 'USER');

INSERT INTO movies (movie_name, theatre_name, total_tickets, available_tickets, status, description, genre, language, duration, rating, ticket_price, poster_url) VALUES
('Avengers Endgame', 'PVR Cinemas', 100, 100, 'BOOK_ASAP', 
 'The final battle against Thanos in the epic conclusion to the Infinity Saga', 
 'Action/Sci-Fi', 'English', 181, 8.4, 350.00, 'https://example.com/avengers-endgame-poster.jpg'),
('Avengers Endgame', 'INOX Multiplex', 150, 150, 'BOOK_ASAP',
 'The final battle against Thanos in the epic conclusion to the Infinity Saga', 
 'Action/Sci-Fi', 'English', 181, 8.4, 400.00, 'https://example.com/avengers-endgame-poster.jpg'),
('RRR', 'PVR Cinemas', 120, 120, 'BOOK_ASAP',
 'A fictional story about two legendary revolutionaries and their journey away from home',
 'Action/Drama', 'Telugu', 187, 8.1, 300.00, 'https://example.com/rrr-poster.jpg'),
('RRR', 'Cinepolis', 80, 80, 'BOOK_ASAP',
 'A fictional story about two legendary revolutionaries and their journey away from home',
 'Action/Drama', 'Telugu', 187, 8.1, 280.00, 'https://example.com/rrr-poster.jpg');

-- Verify setup
SELECT 'Database setup completed successfully!' as Status;
SELECT COUNT(*) as user_count FROM users;
SELECT COUNT(*) as movie_count FROM movies;
SHOW TABLES;
